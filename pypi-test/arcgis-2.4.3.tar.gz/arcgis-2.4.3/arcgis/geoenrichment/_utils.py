"""
Utility functions for GeoEnrichment module.
"""

from __future__ import annotations
import asyncio
from itertools import product
import re
import threading
from typing import Any, Iterable, Optional, Tuple, Union

from arcgis.features import FeatureSet
from arcgis.geometry import Geometry
import numpy as np
import pandas as pd


def get_sanitized_names(names: Union[str, list, tuple, pd.Series]) -> pd.Series:
    """
    Sanitize the column names to be PEP 8 compliant.
    Useful when trying to match up column names from previously enriched data.

    Args:
        names: Iterable (list, tuple, pd.Series) of names to be "sanitized"

    Returns:
        pd.Series of column names
    """
    # if just one name was passed in, make it an iterable
    names = [names] if isinstance(names, str) else names

    # sanititze the column names and drop into a series
    sani_names = pd.Series(map(pep8ify, names))

    return sani_names


def add_proximity_to_enrich_feature_list(
    source,
    feature_list: Iterable,
    travel_mode: str = "straight_line",
    proximity_metric: Optional[str] = None,
    proximity_value: int = 1,
    proximity_area_overlap: bool = True,
) -> list:
    """Add proxmity metrics to a FeatureSet for sending to the enrich REST endpoint."""
    prx_feat_lst = [
        add_proximity_to_enrich_feature(
            source,
            f,
            travel_mode,
            proximity_metric,
            proximity_value,
            proximity_area_overlap,
        )
        for f in feature_list
    ]
    return prx_feat_lst


def add_proximity_to_enrich_feature(
    source,
    feature: dict,
    travel_mode: str = "straight_line",
    proximity_metric: Optional[str] = None,
    proximity_value: int = 1,
    proximity_area_overlap: bool = True,
) -> dict:
    """Add proximity metrics onto a feature in a feature set for sending to the enrich REST endpoint."""
    # alias list to standardize the proximity_metric input
    if proximity_metric is not None:
        trvl_md_aliases = {
            "kilometers": ["kilometer", "km"],
            "miles": ["mile"],
            "minutes": ["min"],
        }

        # ensure lowercase to avoid issues with case
        proximity_metric = proximity_metric.lower()

        # look through the names and aliases to see if we can find one
        for val, alias_lst in trvl_md_aliases.items():
            if proximity_metric == val or proximity_metric in alias_lst:
                proximity_metric = val
                break

    # if just doing a buffer, set the correct area type and set variable for travel mode type
    if travel_mode is None:
        travel_mode = "straight_line"
    if travel_mode == "straight_line":
        feature["areaType"] = (
            "RingBuffer" if proximity_area_overlap else "RingBufferBands"
        )
        trvl_md_typ = "distance"

    # otherwise, doing a network type and need to figure out what the travel mode is
    else:
        feature["areaType"] = "NetworkServiceArea"

        # scrub the travel mode
        travel_mode = validate_network_travel_mode(
            source, travel_mode, proximity_metric
        )

        # pull out the category from the travel modes and set the travel mode flat (temporal or distance)
        source_travel_mode = source.travel_modes[
            source.travel_modes["alias"] == travel_mode
        ]
        trvl_md_typ = source_travel_mode.iloc[0]["impedance_category"]

        feature["travel_mode"] = source_travel_mode.iloc[0]["travel_mode_dict"]

        # tack on polygon area overlap
        if proximity_area_overlap:
            feature["networkOptions"] = {"polygon_overlap_type": "Disks"}
        else:
            feature["networkOptions"] = {"polygon_overlap_type": "Rings"}

    # if no proximity metric provided, provide default based on travel mode, and also validate if provided
    if proximity_metric is None:
        if trvl_md_typ == "distance":
            proximity_metric = "kilometers"
        elif trvl_md_typ == "temporal":
            proximity_metric = "minutes"

    # set the buffer units if now populated
    if proximity_metric is not None:
        feature["bufferUnits"] = proximity_metric

    # if the proximity_value is a single value
    if isinstance(proximity_value, (int, float)):
        proximity_value = [proximity_value]

    # if some other iterable was used for input, make sure a list
    if not isinstance(proximity_value, list):
        proximity_value = proximity_value.split(",")

    # put the scalar proximity value(s) in the payload
    feature["bufferRadii"] = proximity_value

    return feature


def validate_network_travel_mode(
    source, travel_mode: str, proximity_metric: Optional[str]
):
    """Validate the travel_mode string or index."""
    # dictionary of potential aliases for travel modes
    travel_mode_dict = {"walk": "walking", "drive": "driving", "truck": "trucking"}

    # flag for ensuring a travel mode match is found
    travel_mode_match = False

    # if the travel mode was provided as a string, get the correct travel mode alias
    if isinstance(travel_mode, str):
        # switch to all lowercase to mitigate case discrepancies
        travel_mode = travel_mode.lower()

        # if generic given, change to correct generic [Take care of old code for Buffer Study Area]
        if travel_mode in ["driving", "walking", "trucking"]:
            travel_mode_type = "time"
            if proximity_metric:
                proximity_metric = proximity_metric.lower()
                if proximity_metric not in ["seconds", "minutes", "hours", "days"]:
                    travel_mode_type = "distance"
            travel_mode = "{} {}".format(travel_mode, travel_mode_type)

        # if the proximity type is straight line, just make sure in correct format (used for enrich method)
        if travel_mode == "straight_line" or travel_mode == "Straight Line":
            travel_mode = "Straight Line"
            travel_mode_match = True

        # tru to find a transportation travel mode
        else:
            # account for potential differences in descriptions from alias dict by building a list of candidates
            prx_lst = [travel_mode]

            for key, val in travel_mode_dict.items():
                if key in travel_mode and val not in travel_mode:
                    prx_lst.append(travel_mode.replace(key, val))

            # look in the name and alias columns for a match
            for col, prx_mthd in product(["name", "alias"], prx_lst):
                # try to find a match in the column for the proximity method
                tmp_df = source.travel_modes[
                    source.travel_modes[col].str.lower() == prx_mthd
                ]

                # if a match is found, pluck out the alias
                if len(tmp_df):
                    travel_mode = tmp_df.iloc[0]["alias"]
                    travel_mode_match = True
                    break

    # check if potential match by travel mode index
    elif isinstance(travel_mode, int):
        assert travel_mode < len(source.travel_modes.index)
        travel_mode = source.travel_modes.iloc[travel_mode]["alias"]
        travel_mode_match = True

    # ensure a recognized proximity type was found
    assert (
        travel_mode_match
    ), f"The travel mode provided, {travel_mode}, is not recognized as an available travel mode."

    return travel_mode


def get_spatially_enabled_dataframe(
    input_object: Union[
        pd.DataFrame, pd.Series, Geometry, FeatureSet, Iterable, np.ndarray
    ],
    spatial_column: str = "SHAPE",
) -> pd.DataFrame:
    """Garbage disposal taking variety of possible inputs and outputting, if possible, a Pandas Spatially Enabled
    DataFrame."""
    # ensure only one FeatureSet getting passed in if an iterable is passed in
    if isinstance(input_object, Iterable) and not isinstance(
        input_object, pd.DataFrame
    ):
        if is_dict_featureset(input_object[0]) or isinstance(input_object, FeatureSet):
            assert len(input_object) == 1, "Only one FeatureSet can be used for input"

            # pop out the FeatureSet if this is passed in
            if isinstance(input_object[0], FeatureSet):
                input_object = input_object[0]

    # check if is FeatureSet dict and convert to FeatureSet object if it is
    if is_dict_featureset(input_object):
        input_object = FeatureSet(input_object)

    # if a FeatureSet, convert to spatially enabled data frame
    if isinstance(input_object, FeatureSet):
        input_object = input_object.sdf

    # if just a single geometry passed in, we need to get it into a list
    if isinstance(input_object, (Geometry, dict)):
        input_object = [input_object]

    # if any type of iterable other than a series, make into a series
    if isinstance(input_object, (Iterable, np.ndarray)) and not isinstance(
        input_object, pd.DataFrame
    ):
        # Geometry objects may be passed in as an iterable of dicts - convert to Geometry if this is the case
        first_obj = input_object[0]
        if isinstance(first_obj, dict):
            if is_dict_geometry(first_obj):
                input_object = [Geometry(obj) for obj in input_object]

        input_object = pd.Series(input_object)

    # at this juncture, the only real options are either a Series or DataFrame, so if Series, make into DataFrame
    if isinstance(input_object, pd.Series):
        input_object = input_object.to_frame("SHAPE")

    # if the geometry has not been set, take care of it
    if input_object.spatial._name is None:
        assert spatial_column in input_object.columns, (
            f"The spatial column cannot be set to {spatial_column}, "
            f"because it is not a column in the input DataFrame."
        )
        input_object.spatial.set_geometry(spatial_column)

    return input_object


def is_dict_geometry(in_dict: dict) -> bool:
    """Determine if input dictionary is a Geometry object."""
    if (
        ("x" in in_dict.keys() and "y" in in_dict.keys())
        or ("points" in in_dict.keys())
        or ("ringCurves" in in_dict.keys())
        or ("rings" in in_dict.keys())
        or ("paths" in in_dict.keys())
        or ("pathCurves" in in_dict.keys())
    ):
        is_geometry = True
    else:
        is_geometry = False
    return is_geometry


def is_dict_featureset(in_dict: dict) -> bool:
    """Determine if input dictionary is a FeatureSet."""
    if isinstance(in_dict, dict):
        is_featureset = "features" in in_dict.keys() and "fields" in in_dict.keys()
    else:
        is_featureset = False
    return is_featureset


def pep8ify(name):
    """PEP8ify name"""
    if name is None:
        res = None
    else:
        if "." in name:
            name = name[name.rfind(".") + 1 :]
        if name[0].isdigit():
            name = "level_" + name
        name = name.replace(".", "_")
        if "_" in name:
            name = name.lower()
        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        s2 = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
        res = s2.replace(" ", "")
    return res


def extract_from_kwargs(paramater_key: str, kwargs: dict) -> Tuple[Any, dict]:
    """
    Provide ability to unpack value from kwargs in relatively streamlined fashion.
    Args:
        paramater_key: String key of value to be extracted from kwargs.
        kwargs: The dictionary of keyword arguments for the value to be extracted from.
    Returns:
        Tuple of the parameter value proided as input and the kwargs updated to no longer
        include the parameter retrieved.
    """
    if paramater_key in kwargs.keys():
        param_val = kwargs[paramater_key]
        del kwargs[paramater_key]
    else:
        param_val = None
    return param_val, kwargs


# asynchronous function support section - solution located on StackOverflow
# https://stackoverflow.com/questions/55409641/asyncio-run-cannot-be-called-from-a-running-event-loop
class RunThread(threading.Thread):
    def __init__(self, func, args, kwargs):
        self.func = func
        self.args = args
        self.kwargs = kwargs
        self.result = None
        super().__init__()

    def run(self):
        self.result = asyncio.run(self.func(*self.args, **self.kwargs))


def run_async(func, *args, **kwargs):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop and loop.is_running():
        thread = RunThread(func, args, kwargs)
        thread.start()
        thread.join()
        return thread.result
    else:
        return asyncio.run(func(*args, **kwargs))
