from __future__ import annotations

import functools
import uuid
from collections import namedtuple
from pathlib import Path
from typing import Union, Iterable, Optional
from warnings import warn
import pandas as pd

from arcgis.features import GeoAccessor
from arcgis.geometry import Geometry, SpatialReference
from arcgis.gis import GIS
from ._spatial import change_spatial_reference
from ._utils import (
    pro_at_least_version,
    set_local_ba_analysis_source,
    get_network_dataset_path_local,
)

try:
    import arcpy
except ImportError:
    arcpy = None

__all__ = ["BusinessAnalyst", "Country"]

from .._api_provider import ApiProvider
from .._utils import (
    pep8ify,
    validate_network_travel_mode,
    get_spatially_enabled_dataframe,
)


class AOI(object):
    """
    An AOI (area of interest) delineates the area being used for enrichment.
    Currently this is implemented as a Country, but is classed as a parent
    so later areas of interest can be delineated spanning country borders.
    """

    def __init__(self, iso3: str, year: Optional[int] = None, **kwargs):
        # set the enrichment property
        self._ba = self._ba = (
            kwargs["ba"] if "ba" in kwargs else BusinessAnalyst(country=iso3, year=year)
        )

        # set the source
        self.source = "local"

        # placeholder for properties
        self.properties: namedtuple = None

    def __repr__(self):
        repr_str = f"<{type(self).__name__} ({self.source})>"
        return repr_str


class Country(AOI):
    """
    Country enables access to Business Analyst functionality. Business Analyst
    data is available by iso3 using both ``local`` (ArcGIS Pro with the Business
    Analyst extension and local data) and ``GIS`` sources.

    =============================       ====================================================================
    **Parameter**                        **Description**
    -----------------------------       --------------------------------------------------------------------
    iso3                                The country's ISO3 identifier.
    -----------------------------       --------------------------------------------------------------------
    year                                Optional integer explicitly specifying the year to reference.
                                        This is only honored if using local resources and the specified
                                        year is available.
    =============================       ====================================================================

    """

    def __init__(
        self,
        iso3: str,
        year: Optional[int] = None,
        **kwargs,
    ) -> None:
        # invoke the AOI init method - mostly just sets the _ba property
        super().__init__(iso3, year, **kwargs)

        # set the iso3 property based on the iso3
        self.iso3 = self._ba._standardize_country_str(iso3)

        # use the iso3 to filter the available countries to a dataframe of just the country requested.
        sel_df = self._ba.countries[self._ba.countries["iso3"] == self.iso3]

        # if the data source is local, but no year was provided, get the year
        if self.source == "local" and year is None:
            year = sel_df.vintage.max()

        # if the year is provided, validate
        elif self.source == "local" and year is not None:
            # just in case it was accidentally input as a string
            year = int(year) if isinstance(year, str) else year

            # get list of valid values for this country
            lcl_yr_vals = list(
                self._ba.countries[self._ba.countries["iso3"] == self.iso3]["vintage"]
            )

            # validate year is available for given country
            assert year in lcl_yr_vals, (
                f'The year you provided, "{year}" is not among the available '
                f'years ({", ".join([str(v) for v in lcl_yr_vals])}) for "{self.iso3.upper()}".'
            )

        # if source is GIS and year is provided, warn will be ignored
        elif isinstance(self.source, GIS) and year is not None:
            warn(
                "Explicitly specifying a year (vintage) is not supported when using a GIS instance as the source."
            )

        # get the first row from the selected dataframe, filtering based on year if local, for the properties
        properties = sel_df[sel_df.vintage == year].iloc[0]

        # if local, set a few more properties unique to local
        if self.source == "local":
            # to avoid confusion, add year as alias to vintage
            properties["year"] = properties["vintage"]

            # set the path to the network dataset
            properties["network_path"] = get_network_dataset_path_local(properties)

            # ensure analysis uses correct data source
            set_local_ba_analysis_source(properties)

        # convert the properties to a namedtuple and set as property of object
        self.properties = namedtuple("properties", properties.index)(*properties)

    def __repr__(self):
        repr_str = f"<{type(self).__name__} - {self.iso3}"

        if self.source == "local":
            repr_str = f"{repr_str} {self.properties.vintage} (local)>"
        else:
            repr_str = f"{repr_str} ({self.source})>"

        return repr_str

    @functools.cached_property
    def geography_levels(self) -> pd.DataFrame:
        """Local implementation of geography_levels."""

        # ensure using correct data sources
        set_local_ba_analysis_source(self.properties)

        # get a dataframe of level properties for the country
        geo_lvl_df = pd.DataFrame.from_records(
            [
                lvl.__dict__
                for lvl in arcpy._ba.ListGeographyLevels(self.properties.country_id)
            ]
        )

        # reverse sorting order so smallest is at the top
        geo_lvl_df = geo_lvl_df.iloc[::-1].reset_index(drop=True)

        # calculate a field for use in the accessor
        geo_lvl_df.insert(
            0,
            "level_name",
            geo_lvl_df["LevelID"].apply(lambda val: pep8ify(val.split(".")[1])),
        )

        # purge columns and include AdminLevel if present (added in Pro 2.9)
        out_col_lst = [
            "level_name",
            "SingularName",
            "PluralName",
            "LevelName",
            "LayerID",
            "IDField",
            "NameField",
        ]
        if "AdminLevel" in list(geo_lvl_df.columns):
            out_col_lst = out_col_lst + ["AdminLevel"]
        geo_lvl_df.drop(
            columns=[c for c in geo_lvl_df.columns if c not in out_col_lst],
            inplace=True,
        )

        # rename fields for consistency
        out_rename_dict = {
            "SingularName": "singular_name",
            "PluralName": "plural_name",
            "LevelName": "alias",
            "LayerID": "level_id",
            "IDField": "id_field",
            "NameField": "name_field",
            "AdminLevel": "admin_level",
        }
        geo_lvl_df.rename(columns=out_rename_dict, inplace=True, errors="ignore")

        return geo_lvl_df


class BusinessAnalyst(ApiProvider):
    """
    The BusinessAnalyst object enables access to Business Analyst functionality.

    =============================       ====================================================================
    **Parameter**                        **Description**
    -----------------------------       --------------------------------------------------------------------
    country                             Optional string. The country name, two letter code or
                                        three letter ISO3 code identifying the country.
    ------------------                  --------------------------------------------------------------------
    year                                Optional string. Explicitly specifying the year (vintage)
                                        to query in the case of multiple years data being available.
    =============================       ====================================================================

    """

    def __init__(
        self,
        country: Optional[str] = None,
        year: Optional[int] = None,
    ) -> None:
        super().__init__("local")

        if country:
            iso3 = self._standardize_country_str(country)
            self.country = Country(iso3, year=year, ba=self)

    def __repr__(self):
        repr_str = f"<{type(self).__name__} ({self.source})>"
        return repr_str

    @functools.cached_property
    def properties(self):
        """Local properties implementation."""
        return self.country.properties

    @functools.cached_property
    def countries(self) -> pd.DataFrame:
        """Local countries implementation."""

        # get a generator of dataset objects
        ds_lst = list(arcpy._ba.ListDatasets())

        # throw error if no local datasets are available
        assert len(ds_lst), (
            "No datasets are available locally. If you want to locate available countries on a "
            "Web GIS, please provide a GIS object instance for the source parameter when creating "
            "the BusinessAnalyst object."
        )

        # organize all the iso3 dataset properties
        cntry_lst = [
            (
                ds.CountryInfo.Name,
                ds.Version,
                ds.CountryInfo.ISO2,
                ds.CountryInfo.ISO3,
                ds.DataSourceID,
                ds.ID,
            )
            for ds in ds_lst
        ]

        # create a dataframe of the iso3 properties
        cntry_df = pd.DataFrame(
            cntry_lst,
            columns=[
                "name",
                "vintage",
                "iso2",
                "iso3",
                "data_source_id",
                "country_id",
            ],
        )

        # convert the vintage years to integer
        cntry_df["vintage"] = cntry_df["vintage"].astype("int64")

        # ensure the values are in order by iso3 and year
        cntry_df.sort_values(["iso3", "vintage"], inplace=True)

        # organize the columns
        cntry_df = cntry_df[
            [
                "iso2",
                "iso3",
                "name",
                "vintage",
                "country_id",
                "data_source_id",
            ]
        ]

        return cntry_df

    @functools.cached_property
    def hierarchies(self):
        ValueError(
            "`hierarchies` property is not supported when working with local data."
        )

    # TODO: deprecated method, need to remove
    def get_country(
        self,
        iso3: str,
        year: Optional[int] = None,
    ) -> BusinessAnalyst:
        """
        DEPRECATED METHOD - use public Country object instead
        Get a BusinessAnalyst object instance configured with a specific country.
        =============================       ====================================================================
        **Parameter**                        **Description**
        -----------------------------       --------------------------------------------------------------------
        iso3                                Required String. The country's ISO3 identifier.
        -----------------------------       --------------------------------------------------------------------
        year                                Optional integer explicitly specifying the year to reference.
                                            This is only honored if using local resources and the specified
                                            year is available.
        =============================       ====================================================================

        A BusinessAnalyst object instance can be created to work with Business Analyst data installed
        either locally with ArcGIS Pro.

        .. code-block:: python

            from business_analyst import BusinessAnalyst
            ba = BusinessAnalyst('local')  # using ArcGIS Pro with Business Analyst
            usa = ba.get_country('USA')  # USA with most current data installed on machine

        .. code-block:: python

            from business_analyst import BusinessAnalyst
            ba = BusinessAnalyst('local')
            usa = ba.get_country('USA', year=2019)  # explicitly specifying the year with local data

        .. code-block:: python

            from arcgis.gis import GIS
            from business_analyst import BusinessAnalyst
            gis = GIS(username='my_username', password='$up3r$3cr3tP@$$w0rd')
            ba = BusinessAnalyst(gis)  # using ArcGIS Online
            usa = ba.get_country('USA')

        Once instantiated, available enrichment enrich_variables can be discovered and used for
        geoenrichment.

        .. code-block:: python

            # get the enrichment enrich_variables as a Pandas DataFrame
            evars = usa.enrich_variables

            # filter to just current year key enrich_variables
            kvars = [
                (evars.name.str.endswith('CY'))
                & (evars.data_collection.str.startswith('Key')
            ]
        """
        ba = BusinessAnalyst(iso3, year=year)

        return ba

    @functools.cached_property
    def enrich_variables(self) -> pd.DataFrame:
        """Local implementation of enrich_variables property and only available by iso3 currently."""
        # ensure using correct data sources
        set_local_ba_analysis_source(self.country.properties)

        # pull out the iso3 dataframe to a variable for clarity
        cntry_df = self.countries

        # create a filter to select the right iso3 and year dataset
        dataset_fltr = (cntry_df["iso3"] == self.country.iso3) & (
            cntry_df["vintage"] == int(self.country.properties.vintage)
        )

        # get the iso3 identifier needed for listing enrich_variables
        ba_id = cntry_df[dataset_fltr].iloc[0]["country_id"]

        # retrieve variable objects
        var_gen = arcpy._ba.ListVariables(ba_id)

        # use a list comprehension to unpack the properties of the enrich_variables into a dataframe
        var_df = pd.DataFrame(
            (
                (v.Name, v.Alias, v.DataCollectionID, v.FullName, v.OutputFieldName)
                for v in var_gen
            ),
            columns=[
                "name",
                "alias",
                "data_collection",
                "enrich_name",
                "enrich_field_name",
            ],
        )

        return var_df

    @functools.cached_property
    def data_collections(self):
        """Local implementation for data_collections"""
        # get the variables and reorganize the dataframe to be as similar as possible to the existing online response
        col_map = {
            "data_collection": "dataCollectionID",
            "enrich_name": "analysisVariable",
        }
        dc_df = self.enrich_variables.rename(columns=col_map).set_index(
            "dataCollectionID"
        )
        dc_df = dc_df[["analysisVariable", "alias"]].copy()
        return dc_df

    @functools.cached_property
    def geography_levels(self) -> pd.DataFrame:
        return self.country.geography_levels

    @functools.cached_property
    def travel_modes(self) -> pd.DataFrame:
        """Local implementation of travel modes."""
        # ensure using correct data sources
        set_local_ba_analysis_source(self.country.properties)

        # get a list of useful information about each travel mode
        mode_lst = [
            [
                mode.name,
                mode.description,
                mode.type,
                mode.impedance,
                mode.timeAttributeName,
                mode.distanceAttributeName,
            ]
            for mode in self._travel_modes_dict_local.values()
        ]

        # create a dataframe of the travel modes
        mode_df = pd.DataFrame(
            mode_lst,
            columns=[
                "alias",
                "description",
                "type",
                "impedance",
                "time_attribute_name",
                "distance_attribute_name",
            ],
        )

        # add a pep8tified name for each travel mode
        mode_name = mode_df["alias"].apply(lambda val: pep8ify(val))
        mode_df.insert(0, "name", mode_name)

        # calculate impedance category
        imped_cat = mode_df["impedance"].apply(
            lambda val: "temporal" if val.lower().endswith("time") else "distance"
        )
        insert_idx = mode_df.columns.get_loc("impedance") + 1
        mode_df.insert(insert_idx, "impedance_category", imped_cat)

        return mode_df

    @functools.cached_property
    def _travel_modes_dict_local(self) -> dict:
        """Since looking up the travel modes is time consuming, use a lazy property to cache it."""

        return arcpy.nax.GetTravelModes(self.country.properties.network_path)

    def _can_use_arrow(self, geo) -> bool:
        if not isinstance(geo, pd.DataFrame):
            return False  # not a DataFrame

        if not geo.spatial.validate():
            return False  # not a valid SeDF

        if len(geo.spatial.geometry_type) != 1:
            return False  # more than one geometry type

        if geo.spatial.geometry_type[0] != "polygon":
            return False  # only polygonal DF are supported at this point

        return True

    def _enrich_using_arrow(self, in_sedf, variables) -> pd.DataFrame:
        # create a data frame with two columns: object id and shape in WKB
        input_shape_series = in_sedf.loc[:, in_sedf.spatial.name]
        df_input = pd.DataFrame({in_sedf.spatial.name: input_shape_series})
        df_input.spatial.set_geometry(in_sedf.spatial.name)

        # come up with index field that doesn't exist yet
        orig_index_field = str(uuid.uuid4())
        # enrichArrowTable returns records in arbitrary order, ORIG_INDEX is in the original order
        # ORIG_INDEX starts with 0
        df_input[orig_index_field] = range(0, len(in_sedf))

        geo_accessor = GeoAccessor(df_input)
        arrow_table = geo_accessor.to_arrow()

        output_table = arcpy._ba.enrichArrowTable(arrow_table, variables, False)

        enrich_result_df = output_table.to_pandas()

        input_copy_df = in_sedf.copy()
        input_copy_df[orig_index_field] = range(0, len(in_sedf))

        # we need to rename that field to avoid clashes
        enrich_result_df.rename(columns={"ORIG_INDEX": orig_index_field}, inplace=True)

        if "ORIG_OID" in enrich_result_df:
            enrich_result_df.drop(["ORIG_OID"], axis=1, inplace=True)

        # join based on objectid
        merged_df = input_copy_df.merge(enrich_result_df, on=orig_index_field)
        merged_df.drop([orig_index_field], axis=1, inplace=True)

        # rearrange columns to move SHAPE to the last one
        orig_cols = merged_df.columns.tolist()
        new_cols = [c for c in orig_cols if c != in_sedf.spatial.name] + [
            in_sedf.spatial.name
        ]
        final_df = merged_df[new_cols]

        # return new SeDF based on final_df; shape column name is the same as before
        final_df.spatial.set_geometry(in_sedf.spatial.name)
        return final_df

    def _enrich(
        self,
        study_areas: Union[pd.DataFrame, Geometry, Iterable, Path],
        enrich_variables: pd.DataFrame,
        standard_geography_level: Optional[Union[int, str]] = None,
        proximity_type: str = "straight_line",
        proximity_value: Union[float, int] = 1,
        proximity_metric: str = "Kilometers",
        return_geometry: bool = True,
        output_spatial_reference: Union[int, dict, SpatialReference] = 4326,
        estimate_credits: bool = False,
        **kwargs,
    ) -> pd.DataFrame:
        """Local enrich implementation."""
        assert estimate_credits is False, (
            "Cannot estimate credits for local analysis since using a local source does "
            "not use credits."
        )

        # if unsupported local analysis parameters provided, error
        unsupported_params = [
            "comparison_levels",
            "add_derivative_variables",
            "intersecting_geographies",
        ]
        invalid_params = [k for k in kwargs.keys() if k in unsupported_params]
        if len(invalid_params):
            raise ValueError(
                f"{', '.join(invalid_params)} input parameters are not supported with local analysis."
            )

        set_local_ba_analysis_source(self.country.properties)

        # also, raw json input is also not supported
        if isinstance(study_areas, (Iterable, pd.Series)) and not isinstance(
            study_areas, pd.DataFrame
        ):
            if not isinstance(study_areas[0], Geometry) and isinstance(
                study_areas[0], dict
            ):
                raise ValueError(
                    "Raw JSON is not supported as input for geoenrichment when using a 'local' source."
                )

        # ensure no conflicts with intermediate datasets
        arcpy.env.overwriteOutput = True

        # get the variables property formatted for the Enrich Layer tool
        evars = self._enrich_variable_preprocessing(enrich_variables)

        # if the standard geographies were provided
        if standard_geography_level is not None:
            # if input is a dataframe, ensure correctly set up
            if isinstance(study_areas, pd.DataFrame):
                std_geo_in = get_spatially_enabled_dataframe(
                    study_areas
                ).spatial.to_featureclass("memory/tmp_in_geo")

            # if input is any other iterable or Series, convert to comma separated string
            elif isinstance(study_areas, (Iterable, pd.Series)):
                std_geo_in = ", ".join(list(study_areas))

            # convert the standard geography to the correct string for use in later geoprocessing
            standard_geography_level = self.geography_levels.iloc[
                standard_geography_level
            ]["level_id"]

            # retrieve the standard geographies based on the identifiers
            study_areas = arcpy.ba.StandardGeographyTA(
                geography_level=standard_geography_level,
                out_feature_class="memory/tmp_std_geo",
                input_type="LIST",
                ids_list=std_geo_in,
            )[0]

            # convert to spatially enabled dataframe
            study_areas = GeoAccessor.from_featureclass(study_areas)

        # otherwise, make sure input in consistent format
        else:
            study_areas = get_spatially_enabled_dataframe(study_areas)

            # if z-enabled, de-enable so enrich can work...conversion does not work with z-enabled features
            if study_areas[study_areas.spatial.name].iloc[0].has_z:
                study_areas[study_areas.spatial.name] = study_areas[
                    study_areas.spatial.name
                ].apply(lambda geom: Geometry(geom.__geo_interface__))

        # if a proximity type is provided, validate
        if proximity_type is not None:
            proximity_type = validate_network_travel_mode(
                self, proximity_type, proximity_metric
            )

            # provide defaults if nothing provided for any of the proximity metrics
            proximity_type = (
                "Straight Line" if proximity_type is None else proximity_type
            )
            proximity_metric = (
                "kilometers" if proximity_metric is None else proximity_metric
            )
            proximity_value = 1 if proximity_value == 1 else proximity_value

            # ensure if the geometry is lines, the proximity_type is not a network travel mode
            if (
                study_areas.spatial.geometry_type[0] == "polyline"
                and proximity_type is not None
            ):
                assert (
                    proximity_type == "Straight Line"
                ), 'Only "Straight Line" proximity_type can be used with line geometry.'

        # handle pre 2.9
        in_geo = (
            study_areas
            if pro_at_least_version("2.9")
            else study_areas.spatial.to_featureclass(
                f"memory/geo_in_{uuid.uuid4().hex}"
            )
        )

        # now, actually perform enrichment
        use_arrow = pro_at_least_version("3.1") and self._can_use_arrow(in_geo)

        if use_arrow:
            enrich_res = self._enrich_using_arrow(in_sedf=in_geo, variables=evars)
        else:
            enrich_res = arcpy.ba.EnrichLayer(
                in_features=in_geo,
                out_feature_class=f"memory/tmp_enrich_{uuid.uuid4().hex}",
                variables=evars,
                buffer_type=proximity_type,
                distance=proximity_value,
                unit=proximity_metric,
            )

        # handle differences in pre 2.9
        if not pro_at_least_version("2.9"):
            arcpy.management.Delete(in_geo)
            enrich_res = enrich_res[0]

        # cache output depending on what the input was
        enrich_res = (
            enrich_res if isinstance(study_areas, pd.DataFrame) else enrich_res[0]
        )

        # convert the output to a spatially enabled dataframe if necessary (in 3.1 it's done in
        enrich_df = (
            enrich_res if use_arrow else GeoAccessor.from_featureclass(enrich_res)
        )

        if not use_arrow:
            # in some cases from_featureclass returns a data frame that doesn't pass SEDF validation (enrich_df.spatial.validate)
            enrich_df.spatial.set_geometry("SHAPE")

        # standardize columns to ensure results are as expected
        enrich_df.columns = [
            self._standardize_enrich_column_name(c) for c in enrich_df.columns
        ]

        column_candidates_to_remove = ["Shape_Area", "Shape_Length"]
        # default value set to True to keep backward compatibility
        sanitize_columns = kwargs.pop("sanitize_columns", True)
        if sanitize_columns:
            enrich_df.columns = [
                pep8ify(c) for c in enrich_df.columns if c != "SHAPE"
            ] + ["SHAPE"]
            column_candidates_to_remove = [
                pep8ify(c) for c in column_candidates_to_remove
            ]

        # start creating a list of columns to remove - beginning with the OBJECTID field
        drop_cols = [c for c in enrich_df.columns if c in column_candidates_to_remove]

        if not use_arrow:
            if sanitize_columns:
                drop_cols.append(pep8ify(arcpy.Describe(enrich_res).OIDFieldName))
            else:
                drop_cols.append(arcpy.Describe(enrich_res).OIDFieldName)

        if not use_arrow:
            # get rid of the temporary output to save memory
            arcpy.management.Delete(enrich_res)

        # if returning geometry
        if return_geometry:
            # ensure the spatial reference is correct

            if output_spatial_reference:
                enrich_df = change_spatial_reference(
                    enrich_df, output_spatial_reference
                )

            # removing unneeded columns - using inplace to preserve all spatial namespace properties
            enrich_df.drop(columns=drop_cols, inplace=True)

        # if not returning geometry, drop the geometry column
        else:
            drop_cols.append(enrich_df.spatial.name)

            # remove unneeded columns - not doing inplace to ensure no 'spatial' namespace remnants
            enrich_df = enrich_df.drop(columns=drop_cols)

        return enrich_df
