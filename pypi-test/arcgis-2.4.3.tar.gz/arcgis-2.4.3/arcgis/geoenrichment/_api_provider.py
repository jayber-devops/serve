from __future__ import annotations

import functools
import json
from abc import ABC, abstractmethod
from typing import Iterable, Union, Optional
from warnings import warn
from pathlib import Path
import pandas as pd
from functools import lru_cache
from arcgis.features import FeatureSet
from arcgis.geometry import Geometry, SpatialReference
from arcgis.gis import GIS

from ._utils import (
    get_sanitized_names,
    is_dict_geometry,
    is_dict_featureset,
)


class ApiProvider(ABC):
    """
    Common interface for both implementations - Online and local data
    """

    def __init__(self, source):
        self.source = source

    @functools.cached_property
    @abstractmethod
    def properties(self):
        pass

    @functools.cached_property
    @abstractmethod
    def countries(self) -> pd.DataFrame:
        """DataFrame of available countries with relevant metadata columns."""
        pass

    @functools.cached_property
    @abstractmethod
    def hierarchies(self) -> pd.DataFrame:
        pass

    @functools.cached_property
    @abstractmethod
    def enrich_variables(self):
        pass

    @functools.cached_property
    @abstractmethod
    def data_collections(self):
        """
        Returns the supported data collections and analysis variables as a Pandas dataframe.

        The dataframe is indexed by the data collection id(``dataCollectionID``) and
        contains columns for analysis variables(``analysisVariable``).
        """
        pass

    @functools.cached_property
    @abstractmethod
    def geography_levels(self) -> pd.DataFrame:
        pass

    @functools.cached_property
    @abstractmethod
    def travel_modes(self) -> pd.DataFrame:
        """Dataframe of available travel modes."""
        pass

    @abstractmethod
    def _enrich(
        self,
        study_areas: Union[pd.DataFrame, Iterable, Path],
        enrich_variables: Union[pd.DataFrame, Iterable],
        return_geometry: bool = True,
        standard_geography_level: Optional[Union[int, str]] = None,
        standard_geography_id_column: Optional[str] = None,
        proximity_type: Optional[str] = None,
        proximity_value: Optional[Union[float, int]] = None,
        proximity_metric: Optional[str] = None,
        output_spatial_reference: Union[int, dict, SpatialReference] = None,
        estimate_credits: bool = False,
        **kwargs,
    ) -> Union[pd.DataFrame, Path, float]:
        """
        Get demographic data apportioned to the input geographies based on population density
        weighting. Input geographies can be polygons or points. If providing point geographies,
        an area surrounding every point will be used to determine the area for enrichment.

        .. note::

            By default, point area is typically a buffered straight-line distance. However,
            if a transportation network is available, more accurate proximity metrics may be
            available, such as drive distance or drive time. This is the case if using ``local``
            (ArcGIS Pro with Business Analyst and local data) or a ``GIS`` object connected to ArcGIS
            Online, and very well may also the be the case if using an instance of ArcGIS Enterprise.

        =============================       ====================================================================
        **Parameter**                        **Description**
        -----------------------------       --------------------------------------------------------------------
        study_areas                         Required geographic areas or points to be enriched.
                                            enrich_variables: Enrichment enrich_variables to be used,
                                            typically discovered using the "enrich_variables" property.
        -----------------------------       --------------------------------------------------------------------
        return_geometry                     Optional boolean indicating if geometry is desired in the output.
                                            Default is True.
        -----------------------------       --------------------------------------------------------------------
        standard_geography_level            If the input geographies are a standard geography level,
                                            it can be specified using either the standard geography index or the standard
                                            geography identifier retrieved using the Country.geography_levels property.
        -----------------------------       --------------------------------------------------------------------
        standard_geography_id_column        Column with values uniquely identifying the input
                                            geographies using a standard level of geography. For example, in the United
                                            States, typically block groups are used for analysis if possible, and these
                                            block groups all have a unique identifier, typically referred to as the FIPS.
                                            If you have this value in a column of your data, it will *dramatically* speed
                                            up the enrichment process if you specify it in this parameter.
        -----------------------------       --------------------------------------------------------------------
        proximity_type                      Type of area to create around each point.
        -----------------------------       --------------------------------------------------------------------
        proximity_value                     Scalar value representing the proximity around each point to
                                            be used for creating an area for enrichment. For instance, if using 1.2 km,
                                            the input for this parameter is 1.2. The default is 1.
        -----------------------------       --------------------------------------------------------------------
        proximity_metric                    Scalar metric defining the proximity_value. Again, if
                                            1.2 km, the input for this metric will be kilometers. The default is
                                            ``kilometers``.
        -----------------------------       --------------------------------------------------------------------
        output_spatial_reference            Desired spatial reference for returned data. This can be
                                            a spatial reference WKID as an integer, a dictionary representing the spatial
                                            reference, or a Spatial Reference object. The default is WGS84 (WKID 4326).
        -----------------------------       --------------------------------------------------------------------
        estimate_credits                    While only useful for ArcGIS Online, enables populating the
                                            parameters just as you would for enriching using ArcGIS Online, and getting an
                                            estimate of the number of credits, which will be consumed if the enrich
                                            operation is performed. If this parameter is populated, the function will *not*
                                            perform the enrich operation or consume credits. Rather, it will *only* provide
                                            a credit consumption estimate.
        =============================       ====================================================================

        Returns:
            Pandas DataFrame, path to the output Feature Class or table, or float of predicted
            credit consumption.
        """
        pass

    def enrich(
        self,
        study_areas: Union[pd.DataFrame, Geometry, Iterable, Path],
        enrich_variables: Union[pd.DataFrame, Iterable],
        standard_geography_level: Optional[Union[int, str]] = None,
        standard_geography_id_column: Optional[str] = None,
        proximity_type: Optional[str] = None,
        proximity_value: Optional[Union[float, int]] = None,
        proximity_metric: Optional[str] = None,
        return_geometry: bool = True,
        output_spatial_reference: Union[int, dict, SpatialReference] = None,
        estimate_credits: bool = False,
        **kwargs,
    ) -> pd.DataFrame:
        from arcgis.geoenrichment.enrichment import NamedArea

        # if the geographies input is just a single geometry, convert to list to work with
        if isinstance(study_areas, Geometry):
            study_areas = [study_areas]

        # if a dict is passed directly in, check if it is Geometry or a FeatureSet
        if isinstance(study_areas, dict):
            if is_dict_geometry(study_areas):
                study_areas = Geometry(study_areas)
            elif is_dict_featureset(study_areas):
                study_areas = FeatureSet(study_areas)
            # dict of named areas
            elif isinstance(list(study_areas.values())[0], NamedArea):
                named_areas = list(study_areas.values())
                study_areas = [named_area.geometry for named_area in named_areas]

        if isinstance(study_areas, Iterable) and not isinstance(
            study_areas, pd.DataFrame
        ):
            # if a list of geometries is passed in dict form, convert to Geometry objects
            if isinstance(study_areas[0], dict):
                if is_dict_geometry(study_areas[0]):
                    study_areas = [Geometry(g_dict) for g_dict in study_areas]

        # if a FeatureSet, convert to spatially enabled data frame
        if isinstance(study_areas, FeatureSet):
            study_areas = study_areas.sdf

        # flag if a dataframe
        geo_is_df = isinstance(study_areas, pd.DataFrame)

        # flag if is list of dictionaries, which allowed through untouched
        geo_is_dict = False
        if isinstance(study_areas, Iterable):
            first_geo = (
                study_areas.iloc[0]
                if isinstance(study_areas, pd.DataFrame)
                else study_areas[0]
            )
            if isinstance(first_geo, dict):
                geo_is_dict = True

        if geo_is_df and output_spatial_reference is None:
            output_spatial_reference = study_areas.spatial.sr

        # check if a spatially enabled dataframe, if standard geography identifiers are not provided
        if geo_is_df and standard_geography_id_column is None and not geo_is_dict:
            assert study_areas.spatial.validate(), (
                "If providing a Pandas DataFrame for enrichment, you must either "
                "ensure it is a valid spatially enabled dataframe or provide a "
                "column containing standard geography identifiers."
            )

        # if a dataframe and the geography id column is provided, pluck out the standard geography identifiers
        elif geo_is_df and standard_geography_id_column and not geo_is_dict:
            study_areas = study_areas[standard_geography_id_column]

        elif geo_is_dict and output_spatial_reference is None:
            if "spatialReference" in first_geo:
                output_spatial_reference = first_geo["spatialReference"]
        # ensure if specifying a standard geography id column, the standard geography level is also provided
        if standard_geography_id_column is not None:
            assert standard_geography_level is not None, (
                "If providing a standard_geography_id_column, you also need "
                "to provide a standard_geography_level."
            )

        # make sure the standard geography level is either an integer index or recognized string
        if isinstance(standard_geography_level, int):
            msg_cntry_idx = (
                "If providing an integer index for the standard_geography_level, it must be within "
                "the available range."
            )
            assert (
                standard_geography_level in self.geography_levels.index
            ), msg_cntry_idx

        elif isinstance(standard_geography_level, str):
            # crawl through all the available columns looking for a match and retrieve the index
            lvl_mtch = False
            for c in self.geography_levels.columns:
                std_geo_lwr = standard_geography_level.lower()
                mtch_srs = (
                    self.geography_levels[c].str.lower().str.contains(std_geo_lwr)
                )
                if mtch_srs.any():
                    lvl_mtch = True
                    standard_geography_level = self.geography_levels[mtch_srs].index[0]
                    break

            # make sure the geography level was found
            assert lvl_mtch, (
                "If providing a standard_geography_level, it must match one of the available "
                "geography levels."
            )

        # if the geographies is not a path and not a dataframe, convert the iterable to a list for consistency later
        if not isinstance(study_areas, (pd.DataFrame, Path)) and not isinstance(
            study_areas, str
        ):
            study_areas = list(study_areas)

        # get enrichment variables to validate against depending on the enrichment variable source
        ev_df = self.enrich_variables

        # if no variables submitted, provide defaults flexibly based on the parent
        if enrich_variables is None:
            # pluck out enrich variables into a shorter variable
            ev = self.enrich_variables

            # get the current year key variables
            enrich_variables = (
                ev[
                    (ev.name.str.lower().str.contains("cy"))
                    & (ev.data_collection.str.lower().str.contains("key"))
                ]
                .drop_duplicates("name")
                .reset_index(drop=True)
            )

            # ensure something is found, dropping current year if nothing found
            if len(enrich_variables.index) == 0:
                enrich_variables = (
                    ev[(ev.data_collection.str.lower().str.contains("key"))]
                    .drop_duplicates("name")
                    .reset_index(drop=True)
                )

        # if a list of enrichment variables was provided, ensure they are valid
        if not isinstance(enrich_variables, pd.DataFrame):
            # iteratively go through all the columns and try to find matching variables
            for c in ev_df:
                enrich_vars = [v.lower() for v in enrich_variables]
                e_df = ev_df[ev_df[c].str.lower().isin(enrich_vars)].reset_index(
                    drop=True
                )
                if len(e_df.index):
                    break

            # pitch a fit if no variables were found
            if len(e_df.index) == 0:
                raise ValueError(
                    "None of the provided enrich_variables appear to be available."
                )

            # provide a message if not all enrich_variables were found
            if len(enrich_variables) > len(e_df.index):
                warn(
                    f"Not all input enrich_variables were matched ({len(e_df.index):,}/{len(enrich_variables):,})"
                )

        # set the default proximity metric if none provided
        if proximity_metric is None:
            proximity_metric = "kilometers"

        e_df = self._enrich(
            study_areas=study_areas,
            enrich_variables=enrich_variables,
            standard_geography_level=standard_geography_level,
            standard_geography_id_column=standard_geography_id_column,
            proximity_type=proximity_type,
            proximity_value=proximity_value,
            proximity_metric=proximity_metric,
            return_geometry=return_geometry,
            output_spatial_reference=output_spatial_reference,
            estimate_credits=estimate_credits,
            **kwargs,
        )

        return e_df

    def _enrich_variable_preprocessing(
        self, enrich_variables: Union[Iterable, pd.DataFrame], **kwargs
    ) -> str:
        """Provide flexibility for enrich variable preprocessing by enabling enrich enrich_variables
        to be specified in a variety of iterables, but always provide a standardized variable
        DataFrame as output.

        =============================       ====================================================================
        **Parameter**                        **Description**
        -----------------------------       --------------------------------------------------------------------
        enrich_variables                    Iterable (normally a list) or pd.DataFrame
                                            of enrich_variables correlating to
                                            enrichment enrich_variables. These variable names can be simply the name, the
                                            name prefixed by the collection separated by a dot, or the output from
                                            enrichment in ArcGIS Pro with the field name modified to fit field naming
                                            and length constraints.
        =============================       ====================================================================

        Returns:
            Pandas DataFrame of enrich enrich_variables.
        """
        # enrich variable dataframe column name
        enrich_str_col = "enrich_name"
        enrich_nm_col = "name"

        # if just a single variable is provided pipe it into a pandas series
        if isinstance(enrich_variables, str):
            enrich_variables = pd.Series([enrich_variables])

        # toss the enrich_variables into a pandas Series if an iterable was passed in
        elif isinstance(enrich_variables, Iterable) and not isinstance(
            enrich_variables, pd.DataFrame
        ):
            enrich_variables = pd.Series(enrich_variables)

        # if the enrich dataframe is passed in, check to make sure it has what we need, the right columns
        if isinstance(enrich_variables, pd.DataFrame):
            assert enrich_str_col in enrich_variables.columns, (
                f"It appears the dataframe used for enrichment does"
                f" not have the column with enrich string names "
                f"({enrich_str_col})."
            )
            assert enrich_nm_col in enrich_variables.columns, (
                f"It appears the dataframe used for enrichment does "
                f"not have the column with the enrich enrich_variables names "
                f"({enrich_nm_col})."
            )
            enrich_vars_df = enrich_variables

        # otherwise, create an enrich enrich_variables dataframe from the enrich series for a few more checks
        else:
            # get the enrich enrich_variables dataframe
            enrich_vars_df = self.get_enrich_variables_from_iterable(
                enrich_variables, **kwargs
            )

        # now, drop any duplicates so we're not getting the same variable twice from different data collections
        enrich_vars_df = enrich_vars_df.drop_duplicates("name").reset_index(drop=True)

        # note any enrich_variables submitted, but not found
        if len(enrich_variables) > len(enrich_vars_df.index):
            missing_count = len(enrich_variables) - len(enrich_vars_df.index)
            warn(
                "Some of the enrich_variables provided are not available for enrichment "
                f"(missing count: {missing_count:,}).",
                UserWarning,
            )

        # check to make sure there are enrich_variables for enrichment
        if len(enrich_vars_df.index) == 0:
            raise Exception(
                "There appear to be no enrich_variables selected for enrichment."
            )

        # get the string names needed in a list
        ev_lst = list(enrich_vars_df[enrich_str_col])

        # format output based on enrichment source
        enrich_vars = (
            json.dumps(ev_lst) if isinstance(self.source, GIS) else ";".join(ev_lst)
        )

        return enrich_vars

    def get_enrich_variables_from_iterable(
        self, enrich_variables: Union[Iterable, pd.Series], **kwargs
    ) -> pd.DataFrame:
        """
        Get a dataframe of enrich enrich_variables associated with the list of enrich_variables
        passed in. This is especially useful when needing aliases (*human readable
        names*), or are interested in enriching more data using previously enriched
        data as a template.

        =============================       ====================================================================
        **Parameter**                        **Description**
        -----------------------------       --------------------------------------------------------------------
        enrich_variables                    Iterable (normally a list) of enrich_variables correlating to
                                            enrichment enrich_variables. These variable names can be simply the name, the
                                            name prefixed by the collection separated by a dot, or the output from
                                            enrichment in ArcGIS Pro with the field name modified to fit field naming
                                            and length constraints.
        =============================       ====================================================================

        Returns:
            Pandas DataFrame of enrich enrich_variables with the different available aliases.

        .. code-block:: python

            from pathlib import Path

            import arcpy
            from arcgis.apps.ba import BusinessAnalyst

            # paths
            gdb = Path(r'C:/path/to/geodatabase.gdb')
            enriched_fc_pth = gdb/'enriched_data'
            features_to_be_enriched = gdb/'block_groups_pdx'
            new_fc_pth = gdb/'block_groups_pdx_enriched'

            # ArcGIS Online credentials
            usr = 'username'
            pswd = 'P@$$w0rd!'

            # create a business analyst instance
            gis = GIS(username=usr, password=pswd)
            ba = BusinessAnalyst(gis)

            # get a list of column names from previously enriched data
            attr_lst = [c.name for c in arcpy.ListFields(str(enriched_fc_pth))

            # get dataframe of enrich_variables used for previously enriched data
            enrich_vars = cntry.get_enrich_variables_from_name_list(attr_lst)

            # enrich block groups in new area of interest using the same enrich_variables
            bg_df = pd.DataFrame.spatial.from_featureclass(features_to_be_enriched)
            enrich_df = cntry.enrich(bg_df)

            # save the enriched data
            enrich_df.spatial.to_featureclass(new_fc_pth)
        """
        # validate the series input
        ev_msg = "Only an list or list-like object can be used as input as the enrich_variables input."
        ev_valid = not isinstance(enrich_variables, pd.DataFrame) and isinstance(
            enrich_variables, (Iterable, pd.Series)
        )
        assert ev_valid, ev_msg

        ev = self.enrich_variables
        # if the input is not a series, make it so
        if isinstance(enrich_variables, Iterable):
            enrich_variables = pd.Series(enrich_variables)

        # make the enrich variables lowercase to address potential missed matches due simply to case
        enrich_variables = enrich_variables.str.lower()

        # columns from enrich variables dataframe to search for matches in
        match_cols = ["enrich_name", "enrich_field_name", "name", "alias"]

        # iteratively check for matches and if matches found, bingo out
        for col in match_cols:
            sel_vars = (
                ev[ev[col].str.lower().isin(enrich_variables)]
                .drop_duplicates(col)
                .reset_index(drop=True)
            )
            if len(sel_vars):
                break

        # if no matches found, try sanitizing the names and see if this works
        if len(sel_vars) == 0:
            enrich_variables = get_sanitized_names(enrich_variables)
            for col in match_cols:
                sel_vars = (
                    ev[ev[col].str.lower().isin(enrich_variables)]
                    .drop_duplicates(col)
                    .reset_index(drop=True)
                )
                if len(sel_vars):
                    break

        # make sure something was found, but don't break the runtime
        if "suppress_warn" not in kwargs.keys() and len(sel_vars) == 0:
            warn(f"It appears none of the input enrich enrich_variables were found.")

        return sel_vars

    def _standardize_country_str(self, country_string: str) -> str:
        """Internal helper method to standardize the input for iso3 identifier strings to ISO3."""
        # cast to lowercase to sidestep any issues with case
        cntry_str = country_string.lower()

        # filter functions for getting the iso3 value
        iso3_fltr = self.countries["iso3"].str.lower() == cntry_str
        iso2_fltr = self.countries["iso2"].str.lower() == cntry_str
        name_fltr = self.countries["name"].str.lower() == cntry_str

        # construct the filter, using alias if working online
        cntry_fltr = iso3_fltr | iso2_fltr | name_fltr
        if isinstance(self.source, GIS):
            alias_fltr = self.countries["alt_name"].str.lower() == cntry_str
            cntry_fltr = cntry_fltr | alias_fltr

        # query available countries to see if the requested iso3 is available
        fltr_df = self.countries[cntry_fltr]

        if len(fltr_df.index) > 0:
            iso3_str = fltr_df.iloc[0]["iso3"]
        else:
            raise ValueError(
                f'The provided iso3 code, "{country_string}" does not appear to be available. Please '
                f"choose from the available country iso3 codes discovered using the countries property."
            )

        return iso3_str

    @lru_cache(maxsize=255)
    def _standardize_enrich_column_name(self, column_name: str):
        """Helper function to standardize the output column names so is the same no matter the source."""
        col_nm = self.get_enrich_variables_from_iterable(
            column_name, suppress_warn=True
        )
        col_nm = col_nm.iloc[0]["name"] if len(col_nm.index) > 0 else column_name
        return col_nm
