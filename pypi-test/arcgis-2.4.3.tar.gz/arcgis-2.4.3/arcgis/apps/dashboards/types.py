from __future__ import annotations
from typing import List, Optional, Union
from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic.alias_generators import to_camel


# -----------------
# Dependency Mapping Models
# -----------------


class FieldMapping(BaseModel):
    """
    Describes how to map one field to another.

    """

    source_name: str = Field(..., description="The source field name.")
    target_name: str = Field(..., description="The target field name.")

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class LayerMapping(BaseModel):
    """
    Describes how to map one layer to another.
    """

    source_layer_id: Optional[Union[int, str, None]] = Field(
        ..., description="The source layer's id."
    )
    target_layer_id: Optional[Union[int, str, None]] = Field(
        ..., description="The target layer's id."
    )
    source_sublayer_id: Optional[int] = Field(
        None,
        description="The source sublayer's id - only applicable for sublayer data sources.",
    )
    target_sublayer_id: Optional[int] = Field(
        None,
        description="The target sublayer's id - only applicable for sublayer data sources.",
    )
    field_mappings: Optional[List[FieldMapping]] = Field(
        None,
        description="""A list of :class:`field mapping <arcgis.apps.dashboards.FieldMapping>` objects
                    to map source field names to target field names. **Only** required when field
                    names differ between the source and target layers.

                    .. note::
                        Only supported for Dashboard versions >= '4.30.0'.
                    """,
    )

    @model_validator(mode="after")
    def validate_sublayer_pairs(self):  # type: ignore[override]
        if (self.source_sublayer_id is None) ^ (self.target_sublayer_id is None):
            raise ValueError(
                "source_sublayer_id and target_sublayer_id must either both be provided or both be omitted"
            )
        return self

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class ItemMapping(BaseModel):
    """
    Describes how to map one item to another.
    """

    source_item_id: str = Field(..., description="The source portal item id.")
    target_item_id: str = Field(..., description="The target portal item id.")
    layer_mappings: Optional[List[LayerMapping]] = Field(
        None,
        description="Collection of :class:`layer mappings <arcgis.apps.dashboards.LayerMapping>` where each *layer mapping* describes how to map one layer to another.",
    )

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


# -----------------
# Dependency Options
# -----------------


class DependencyOptions(BaseModel):
    """
    Provides ability to set options for the dependency result. Can be used to
    specify whether to include layers and fields in the result.
    """

    include_layers: bool = Field(
        False, description="Whether to include layers in the result."
    )
    include_fields: bool = Field(
        False,
        description="Whether to include fields in the result. If `include_layers` is false, this option is ignored (fields will not be included).",
    )

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


# -----------------
# Tracker Result Models
# -----------------


class FieldResult(BaseModel):
    """
    Result of the get or replace operation for a field.
    """

    name: str = Field(..., description="The field name.")


class LayerResult(BaseModel):
    """
    Result of the find or replace operation for a layer.
    """

    id: int | str | None = Field(..., description="The layer id.")
    sublayer_id: Optional[int] = Field(
        None, description="The sublayer id - only applicable for sublayer data sources."
    )
    fields: Optional[List[FieldResult]] = Field(
        None, description="Collection of processed fields."
    )

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class ItemResult(BaseModel):
    """
    Result of the find or replace operation for an item.
    """

    item_id: str = Field(..., description="The portal item id.")
    source: Optional[str] = Field(
        None,
        description="Optionally indicates the source of the itemId. For example, an itemId may be sourced from a URL.",
    )
    layers: Optional[List[LayerResult]] = Field(
        None, description="Collection of found layers."
    )

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


__all__ = [
    # Mapping
    "FieldMapping",
    "LayerMapping",
    "ItemMapping",
    # Options/Results
    "DependencyOptions",
    "FieldResult",
    "LayerResult",
    "ItemResult",
]
