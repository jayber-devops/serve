from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional, Type, TypeVar, Any, Dict, Union

import arcgis

from arcgis.gis import GIS
from arcgis.env import active_gis

from .rest_types import (
    UpgradeDashboardRequest,
    DashboardPortalItemBase,
    FindAllDependenciesRequest,
    ReplaceAllDependenciesRequest,
    FindAllDependenciesResult,
    ReplaceAllDependenciesResult,
)

# -----------------
# Error Types
# -----------------


class UtilitiesError(Exception):
    def __init__(self, message: str, details: Optional[list[str]] = None):
        super().__init__(message)
        self.details = details or []


T = TypeVar("T")


@dataclass
class _DashboardUtils:
    """Typed client for ArcGIS Dashboards REST endpoints."""

    _gis: GIS
    _base_url: str

    def __init__(
        self,
        gis: GIS | None = active_gis,
    ) -> None:
        self._gis = gis
        self._base_url: str = self._get_dashboard_utilities_service_url()

    # -- low-level helpers ---
    def _get_dashboard_utilities_service_url(self) -> Optional[str]:
        try:
            portal_props = getattr(self._gis, "properties", None)
            if portal_props:
                return (
                    portal_props.get("helperServices", {})
                    .get("dashboardsUtility", {})
                    .get("url")
                )
        except Exception:  # pragma: no cover - defensive
            raise UtilitiesError("This operation is not supported in this portal")
        return None

    def _request(
        self, method: str, path: str, *, json_body: Optional[dict] = None
    ) -> Any:
        url = self._base_url.rstrip("/") + path
        method = (method or "POST").upper()
        request_fn = getattr(self._gis._con, method.lower(), None)
        if request_fn is None:
            request_fn = self._gis._con.post

        resp = request_fn(
            url,
            json_body,
            add_headers={"Content-Type": "application/json"},
            json_encode=False,
            post_json=True,
            return_raw_response=True,
        )
        # Server returns 200 even on logical errors; attempt to parse JSON always.
        try:
            data = resp.json()
        except json.JSONDecodeError:
            resp.raise_for_status()
            raise UtilitiesError(f"Non-JSON response from {url}: {resp.text[:200]}")

        if isinstance(data, dict) and "code" in data:
            if data["code"] == 400:
                raise UtilitiesError(
                    data.get("message"),
                    data.get("details"),
                )
            if data["code"] == 500:
                raise UtilitiesError(f"HTTP 500 calling {url}", [data.get("message")])

        # Raise on HTTP status codes outside success range (after parsing error object)
        if not resp.ok:
            raise UtilitiesError(
                f"HTTP {resp.status_code} calling {url}", [str(data)[:500]]
            )
        return data

    def _post_model(
        self, path: str, model_in, model_out: Optional[Type[T]] = None
    ) -> Union[T, Any]:
        payload = model_in.dict() if hasattr(model_in, "dict") else model_in
        data = self._request("POST", path, json_body=payload)
        if model_out is not None:
            return model_out.model_validate(data)  # type: ignore[attr-defined]
        return data

    # --- public API methods ---
    def upgrade_dashboard(
        self, req: UpgradeDashboardRequest
    ) -> DashboardPortalItemBase:
        return self._post_model("/upgrade", req, DashboardPortalItemBase)

    def find_all_dependencies(
        self, req: FindAllDependenciesRequest
    ) -> FindAllDependenciesResult:
        return self._post_model("/findAllDependencies", req, FindAllDependenciesResult)

    def replace_all_dependencies(
        self, req: ReplaceAllDependenciesRequest
    ) -> ReplaceAllDependenciesResult:
        return self._post_model(
            "/replaceAllDependencies", req, ReplaceAllDependenciesResult
        )

    def health(self) -> bool:
        try:
            data = self._request("GET", "/internal/healthz")
            # Return True if no exception is raised, regardless of response content
            return True
        except UtilitiesError:
            return False

    def build_info(self) -> Dict[str, Any]:
        return self._request("GET", "/build.json")
