from __future__ import annotations
from typing import List, Optional, Union, Dict
from pydantic import BaseModel, ConfigDict

from arcgis.apps.dashboards.types import DependencyOptions, ItemMapping, ItemResult


# -----------------
# Portal Item Minimal Models
# -----------------


class DashboardPortalItemDataBase(BaseModel):
    version: Union[int, str]
    # Accept arbitrary extra keys (the dashboard schema is large)

    model_config = ConfigDict(extra="allow")


class DashboardPortalItemBase(BaseModel):
    data: DashboardPortalItemDataBase
    resources: Optional[List[Dict[str, Union[str, int, float, dict, list, None]]]] = (
        None
    )


# -----------------
# Operation Parameters & Results
# -----------------


class FindAllDependenciesParams(BaseModel):
    item: DashboardPortalItemBase
    options: Optional[DependencyOptions] = None


class ReplaceAllDependenciesParams(FindAllDependenciesParams):
    mappings: List[ItemMapping]


class FindAllDependenciesResult(BaseModel):
    results: List[ItemResult]


class ReplaceAllDependenciesResult(FindAllDependenciesResult):
    item: DashboardPortalItemBase


class UpgradeDashboardRequest(BaseModel):
    item: DashboardPortalItemBase


class FindAllDependenciesRequest(FindAllDependenciesParams):
    pass


class ReplaceAllDependenciesRequest(ReplaceAllDependenciesParams):
    pass


__all__ = [
    # Options
    "FindAllDependenciesParams",
    "ReplaceAllDependenciesParams",
    "FindAllDependenciesResult",
    "ReplaceAllDependenciesResult",
    # Portal Items
    "DashboardPortalItemDataBase",
    "DashboardPortalItemBase",
    # Operations
    "UpgradeDashboardRequest",
    "FindAllDependenciesRequest",
    "ReplaceAllDependenciesRequest",
]
