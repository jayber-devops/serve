from __future__ import annotations
import json
import os
from typing import Dict, List, Optional, Union
from arcgis.gis import GIS, Item
from arcgis.env import active_gis

from .utils import _DashboardUtils
from .rest_types import DashboardPortalItemBase, UpgradeDashboardRequest
from .types import ItemMapping, ItemResult, DependencyOptions
from packaging.version import Version


class DashboardManager(object):
    """
    Helps work with Dashboard :class:`items <arcgis.gis.Item>` and their
    associated data and resources. Provides methods to manipulate, upgrade,
    and copy dashboards, as well as manage their dependencies.

    ===============     ====================================================================
    **Parameter**       **Description**
    ---------------     --------------------------------------------------------------------
    item                Required String or :class:`~arcgis.gis.Item`. The string for an item
                        id or an item of type 'Dashboard'.
    ---------------     --------------------------------------------------------------------
    gis                 Optional instance of :class:`~arcgis.gis.GIS`. If none provided the
                        active gis is used.
    ===============     ====================================================================
    """

    _item: Item = None
    _dashboard_item_data: DashboardPortalItemBase = None
    _source_gis: GIS = None
    _utils: _DashboardUtils = None

    def __init__(
        self,
        item: Item | str,
        gis: GIS | None = active_gis,
    ) -> None:
        self._setup_gis(gis)
        self._setup_dashboard(item)

    # ==========================
    # Region: Public Methods
    # ==========================

    def get_dependencies(
        self, options: Optional[DependencyOptions] = None
    ) -> list[ItemResult]:
        """
        Returns a Dashboard item's dependencies.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        options             Optional :class:`~arcgis.apps.dashboards.DependencyOptions` object.
                            Set parameters to customize dependency retrieval.
        ===============     ====================================================================

        :return:
            A list of dependencies for the Dashboard item.
        """

        req: DashboardPortalItemBase = {
            "item": self._dashboard_item_data.model_dump(mode="json"),
            "options": self._options_to_dict(options),
        }
        result = self._utils.find_all_dependencies(req)
        return result.results or []

    def replace_dependencies(
        self,
        item_mapping: list[ItemMapping],
        options: Optional[DependencyOptions] = None,
    ) -> Item:
        """
        Replaces the dependencies of a *Dashboard* :class:`~arcgis.gis.Item`,
        modifying the existing *item* to reflect the changes incorporated
        from the *target_item_id*.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        item_mapping        Required list of :class:`~arcgis.apps.dashboards.ItemMapping`
                            object(s) outlining the new dependencies to set.
        ---------------     --------------------------------------------------------------------
        options             Optional :class:`~arcgis.apps.dashboards.DependencyOptions` object.
                            Set parameters to customize dependency replacement.
        ===============     ====================================================================

        :return:
            The *Dashboard* :class:`~arcgis.gis.Item` with updated dependencies.

        .. code-block:: python

            # Usage example : item_mapping parameter structure

            from arcgis.gis import GIS
            from arcgis.apps.dashboards import (
                DashboardManager,
                ItemMapping,
                LayerMapping,
                FieldMapping
            )

            gis = GIS(profile="your_organization_profile")
            dashboard_item = gis.content.get("<dashboard_item_id>")

            item_mapping = ItemMapping(
                                source_item_id="95640b5bddf4470b8c729e75fa77a134",
                                target_item_id="138e01276ed942b9a3a15051b8202505",
                                layer_mappings=[
                                   LayerMapping(
                                      source_layer_id='18c643060d3-layer-1',
                                      target_layer_id='18c643060d3-layer-2',
                                      field_mappings=[
                                         FieldMapping(source_name="OBJECTID", target_name="FID"),
                                         FieldMapping(source_name="Winery_Name", target_name="Winery_Name_new"),
                                         FieldMapping(source_name="Address", target_name="Address_new"),
                                      ]
                                   )
                                ]
                        )
            manager = DashboardManager(item=dashboard_item, gis=gis)

            # Replace dependencies
            manager.replace_dependencies(item_mapping=[item_mapping])
        """

        req: DashboardPortalItemBase = {
            "item": self._dashboard_item_data.model_dump(mode="json"),
            "mappings": [
                (
                    dep.model_dump(mode="json", by_alias=True)
                    if hasattr(dep, "model_dump")
                    else dep
                )
                for dep in item_mapping
            ],
            "options": self._options_to_dict(options),
        }

        replaced_item = self._utils.replace_all_dependencies(req)
        self._update_dashboard_item(new_data=replaced_item.item)

        return self._item

    def upgrade(self) -> Item:
        """
        Upgrades a Dashboard :class:`~arcgis.gis.Item` to the latest schema
        version, modifying the existing item to reflect the changes.

        :return:
            The upgraded Dashboard :class:`~arcgis.gis.Item`

        .. note::
            Method updates the original *item* **in place**. A new *item* is not
            created.
        """

        req: UpgradeDashboardRequest = {
            "item": self._dashboard_item_data.model_dump(mode="json")
        }
        result = self._utils.upgrade_dashboard(req)
        self._update_dashboard_item(result)

        return self._item

    def copy(
        self,
        title: Optional[str] = None,
        tags: Optional[Union[list[str], str]] = None,
        folder: Optional[str] = None,
        item_mapping: Optional[list[ItemMapping]] = None,
    ) -> Item:
        """
        Creates a copy of the Dashboard item.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        title               Optional string. The title of the destination Dashboard
                            :class:`~arcgis.gis.Item`. If not specified, title of the original
                            *Dashboard item* is used.
        ---------------     --------------------------------------------------------------------
        tags                Optional List of Strings. New set of tags (comma separated) for the
                            destination *Dashboard item*.
        ---------------     --------------------------------------------------------------------
        folder              Optional string or :class:`~arcgis.gis.Folder` object in the
                            target :class:`~arcgis.gis.GIS` where the copied item will be stored.
        ---------------     --------------------------------------------------------------------
        item_mapping        Optional list of :class:`~arcgis.apps.dashboards.ItemMapping` objects
                            used to associate an *item*, *layer*, or *field* in the source *GIS*
                            to a corresponding *item*, *layer*, or *field* in the target *GIS*.
        ===============     ====================================================================

        :return:
            A new Dashboard :class:`~arcgis.gis.Item`.
        """

        # copy the item first, applying basic metadata changes and remapping item IDs if requested
        new_item: Item = self._item.copy_item(
            title=title,
            tags=tags,
            folder=folder,
            include_resources=True,
            include_private=True,
        )

        # Instantiate a temporary manager per new item to apply dependency replacement
        if item_mapping:
            try:
                mgr = DashboardManager(item=new_item, gis=self._source_gis)
                mgr.replace_dependencies(item_mapping=item_mapping, options=None)
            except Exception:
                # if anything fails during dependency replacement, delete the copied item to avoid orphaned items
                try:
                    new_item.delete()
                except Exception:
                    pass
                raise  # re-raise original exception

        return new_item

    # ==========================
    # Region: Private Methods
    # ==========================

    def _setup_gis(self, gis: GIS | None) -> None:
        self._source_gis = gis or active_gis

        if not (self._source_gis and self._source_gis._portal.is_logged_in):
            raise ValueError("Must be logged into a Portal Account")

    def _setup_dashboard(self, item: Item | str) -> None:
        if isinstance(item, str):
            item_id = item
            item = self._source_gis.content.get(item_id)
            if item is None:
                raise ValueError(
                    f"Cannot find Dashboard associated with item ID '{item_id}'."
                )

        if getattr(item, "type", None) != "Dashboard":
            raise ValueError(
                f"Item is not a Dashboard (type: {getattr(item, 'type', 'Unknown')})."
            )

        if item._gis != self._source_gis:
            raise ValueError("Item does not belong to the specified GIS.")

        self._item = item
        self._dashboard_item_data = self._get_dashboard_data()
        self._utils = _DashboardUtils(gis=self._source_gis)

    def _get_dashboard_data(self) -> DashboardPortalItemBase:
        resources: Optional[
            List[Dict[str, Union[str, int, float, dict, list, None]]]
        ] = []
        for res in self._item.resources.list():
            r_path = res["resource"]
            r_folder, r_name = os.path.splitext(r_path)[0].split("/")
            r_type = r_folder.rstrip("s")  # remove plural 's'
            res_dict = {
                "type": r_type,
                "name": r_name,
                "data": self._item.resources.get(r_path),
            }
            resources.append(res_dict)

        return DashboardPortalItemBase(data=self._item.get_data(), resources=resources)

    def _options_to_dict(self, options: Optional[DependencyOptions]) -> dict:
        """Helper to convert DependencyOptions to dict or return empty dict."""
        return options.model_dump(mode="json", by_alias=True) if options else {}

    def _update_dashboard_item(self, new_data: DashboardPortalItemBase) -> Item:
        """Helper to update the Dashboard item with new data and resources."""
        self._item.update(data=new_data.data.model_dump(mode="json"))

        # Update resources
        resource_paths: list[str] = [
            res["resource"] for res in self._item.resources.list()
        ]
        for res in new_data.resources:
            r_folder_name = res["type"] + "s"  # add plural 's'
            r_file_name = res["name"] + ".json"
            res_dict = {
                "folder_name": r_folder_name,
                "file_name": r_file_name,
                "text": json.dumps(res["data"]),
            }

            # must check if resource exists already to decide between update/add
            # important when a Dashboard is upgraded from a version lower than 4.30.0, as the Dashboard
            # does not have any resources in those versions - the upgrade function will create them.
            r_path = f"{r_folder_name}/{r_file_name}"
            if r_path in resource_paths:
                self._item.resources.update(**res_dict)
            else:
                self._item.resources.add(**res_dict)

        self._dashboard_item_data = new_data

        return self._item
