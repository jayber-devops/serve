from __future__ import annotations
import warnings
import tempfile
import uuid

import puremagic
import requests
from arcgis.auth.tools import LazyLoader
import re

arcgis = LazyLoader("arcgis")
Content = LazyLoader("arcgis.apps.storymap.story_content")
collection = LazyLoader("arcgis.apps.storymap.collection")
storymap = LazyLoader("arcgis.apps.storymap.story")
briefing = LazyLoader("arcgis.apps.storymap.briefing")
json = LazyLoader("json")
time = LazyLoader("time")
sharing = LazyLoader("gis._impl._content_manager_sharing.api")
_dt = LazyLoader("datetime")

# ======================================================================
# Templates
# ======================================================================
_TEMPLATES = {
    "storymap_2": {
        "root": "n-4xkUEe",
        "nodes": {
            "n-4xkUEe": {
                "type": "story",
                "data": {"storyTheme": "r-vlc4Kp"},
                "config": {"coverDate": "first-published"},
                "children": ["n-aTn8ak", "n-1AItUD", "n-cOeTah"],
            },
            "n-aTn8ak": {
                "type": "storycover",
                "data": {
                    "type": "minimal",
                    "title": "",
                    "summary": "",
                    "byline": "",
                    "titlePanelPosition": "start",
                },
            },
            "n-1AItUD": {
                "type": "navigation",
                "data": {"links": []},
                "config": {"isHidden": True},
            },
            "n-cOeTah": {"type": "credits"},
        },
        "resources": {
            "r-vlc4Kp": {
                "type": "story-theme",
                "data": {
                    "themeId": "summit",
                    "themeBaseVariableOverrides": {},
                },
            }
        },
    },
    "briefing": {
        "root": "n-k23c2p",
        "nodes": {
            "n-XK0GeP": {"type": "briefing-ui", "children": ["n-11SuEF"]},
            "n-11SuEF": {
                "type": "briefing-slide",
                "data": {"layout": "cover"},
                "children": ["n-3r3mhh"],
            },
            "n-3r3mhh": {
                "type": "storycover",
                "data": {
                    "type": "sidebyside",
                    "title": "",
                    "summary": "",
                    "byline": "",
                    "titlePanelPosition": "start",
                },
                "children": [],
            },
            "n-k23c2p": {
                "type": "briefing",
                "data": {"storyTheme": "r-vlc4Kp"},
                "children": ["n-XK0GeP"],
            },
        },
        "resources": {
            "r-vlc4Kp": {
                "type": "story-theme",
                "data": {
                    "themeId": "summit",
                    "themeBaseVariableOverrides": {},
                },
            }
        },
    },
    "collection": {
        "root": "n-vCW523",
        "nodes": {
            "n-vCW523": {
                "type": "collection",
                "data": {"storyTheme": "r-QvId58"},
                "children": ["n-eERiZz"],
            },
            "n-eERiZz": {
                "type": "collection-ui",
                "data": {"items": []},
                "children": ["n-U3Ou63", "n-JTJJo2"],
            },
            "n-U3Ou63": {
                "type": "collection-cover",
                "data": {
                    "title": "",
                    "summary": "",
                    "byline": "",
                    "type": "tiles",
                },
            },
            "n-JTJJo2": {
                "type": "collection-nav",
                "data": {"type": "compact"},
            },
        },
        "resources": {
            "r-QvId58": {
                "type": "story-theme",
                "data": {
                    "themeId": "summit",
                    "themeBaseVariableOverrides": {},
                },
            }
        },
    },
}


# ======================================================================
# Helper methods
# ======================================================================
def set_logo(story, logo: str, link: str | None = None, alt_text: str | None = None):
    """
    Set the logo image, link, and/or alt text.
    """
    root = story._properties["root"]
    if logo or logo == "":
        # If empty string is passed in then remove the logo
        # This wipes out everything
        if logo == "":
            if "storyLogoResource" in story._properties["nodes"][root]["data"]:
                del story._properties["nodes"][root]["data"]["storyLogoResource"]
            if "storyLogoLink" in story._properties["nodes"][root]["data"]:
                del story._properties["nodes"][root]["data"]["storyLogoLink"]
            if "storyLogoAltText" in story._properties["nodes"][root]["data"]:
                del story._properties["nodes"][root]["data"]["storyLogoAltText"]
        elif logo:
            # check the logo is a path to an image and not a url
            if "http" in logo:
                raise ValueError("Please provide a path to an image not a url.")
            # create unique resource name
            name = "logo_" + _dt.datetime.now().strftime("%Y%m%d%H%M%S")
            # add the image type to end of name
            if logo.endswith(".png"):
                name = name + ".png"
            elif logo.endswith(".jpg"):
                name = name + ".jpg"
            elif logo.endswith(".jpeg"):
                name = name + ".jpeg"

            # add the logo to the story item resources
            add_resource(story, file=logo, resource_name=name)
            # create resource node id
            resource_node = "r-" + uuid.uuid4().hex[0:6]
            # add the resource node to the story properties
            story._properties["resources"][resource_node] = {
                "type": "image",
                "data": {
                    "resourceId": name,
                    "provider": "item-resource",
                    "height": 2304,
                    "width": 1536,
                },
            }
            # set the logo to the story properties
            story._properties["nodes"][root]["data"][
                "storyLogoResource"
            ] = resource_node
        else:
            raise ValueError("Please provide a path to an image for the logo.")

    # if link is empty string then remove
    if link == "":
        if "storyLogoLink" in story._properties["nodes"][root]["data"]:
            del story._properties["nodes"][root]["data"]["storyLogoLink"]
    elif link:
        story._properties["nodes"][root]["data"]["storyLogoLink"] = link

    # if alt text is empty string then remove
    if alt_text == "":
        if "storyLogoAltText" in story._properties["nodes"][root]["data"]:
            del story._properties["nodes"][root]["data"]["storyLogoAltText"]
    elif alt_text:
        story._properties["nodes"][root]["data"]["storyLogoAltText"] = alt_text
    return True


def get_thumbnail(gis) -> str:
    """
    Private method to get the default thumbnail path dependent on whether the
    user is Online or on Enterprise.
    """
    if gis._is_arcgisonline:
        return "https://storymaps.arcgis.com/static/images/item-default-thumbnails/item.jpg"
    else:
        return (
            gis._url + "/apps/storymaps/static/images/item-default-thumbnails/item.jpg"
        )


# ----------------------------------------------------------------------
def show(item, width: int | None = None, height: int | None = None):
    """
    Show a preview. The default is a width of 700 and height of 300.
    """
    try:
        if item:
            width = 700 if width is None else width
            height = 350 if height is None else height
            from IPython.display import IFrame

            return IFrame(
                src=item.url,
                width=width,
                height=height,
                params="title=" + item.title,
            )
    except Exception:
        return item.url


# ----------------------------------------------------------------------
def cover(
    story,
    title: str | None = None,
    type: str | None = None,
    summary: str | None = None,
    by_line: str | None = None,
    media: Content.Image | Content.Video | None = None,
):
    """
    A cover is the first slide/node.
    This method allows the cover to be edited by updating the title, byline, image, and more.
    Changing one part of the briefing cover will not change the rest of the cover. If just the
    image is passed in then only the image will change.
    """
    if isinstance(story, briefing.Briefing) or isinstance(story, collection.Collection):
        ui = story._properties["nodes"][story._properties["root"]]["children"][0]
        story_cover_slide = story._properties["nodes"][ui]["children"][0]
        if isinstance(story, briefing.Briefing):
            story_cover_node = story._properties["nodes"][story_cover_slide][
                "children"
            ][0]
        else:
            # for collection, the cover is the first node in ui
            story_cover_node = story_cover_slide
    else:
        story_cover_node = story._properties["nodes"][story._properties["root"]][
            "children"
        ][0]

    # get original data of story cover
    orig_data = story._properties["nodes"][story_cover_node]["data"]

    # set the new values, if any
    story._properties["nodes"][story_cover_node] = {
        "type": "storycover",
        "data": {
            "type": orig_data["type"] if type is None else type,
            "title": orig_data["title"] if title is None else title,
            "summary": orig_data["summary"] if summary is None else summary,
            "byline": orig_data["byline"] if by_line is None else by_line,
            "titlePanelPosition": (
                orig_data["titlePanelPosition"]
                if by_line is None and "titlePanelPosition" in orig_data
                else "start"
            ),
        },
    }

    # set the cover media
    if media is not None:
        if isinstance(media, str):
            media = Content.Image(media)
        if not isinstance(media, Content.Image) and not isinstance(
            media, Content.Video
        ):
            raise ValueError(
                "Media must be an image or video object. This was not updated"
            )
        if media._node not in story._properties["nodes"]:
            # must be added to story resources
            media._add_to_story(story=story)
        story._properties["nodes"][story_cover_node]["children"] = [media._node]
    else:
        # get original image
        if "children" in story._properties["nodes"][story_cover_node]:
            media = story._properties["nodes"][story_cover_node]["children"][0]
            story._properties["nodes"][story_cover_node]["children"] = [media]

    return story._properties["nodes"][story_cover_node]


def get_theme(story):
    resources = story._properties.get("resources", {})

    for _, node in resources.items():
        if node.get("type") == "story-theme":
            data = node.get("data", {})
            return data.get("themeId") or data.get("themeItemId")

    return None


# ----------------------------------------------------------------------
def theme(
    story: storymap.StoryMap | briefing.Briefing,
    theme: storymap.Themes | str | None = None,
):
    """
    Update the theme of a StoryMap or Briefing.

    - If `theme` is a `Themes` enum, update the themeId.
    - If `theme` is a string, treat it as a theme item ID and update themeItemId.
      (Typically the item ID of a Story Map Theme).
    - If theme is None or no theme node is found, return theme unchanged.
    """

    resources = story._properties.get("resources", {})

    # Find the node that represents the story theme
    theme_node = None
    for node_id, node_info in resources.items():
        if node_info.get("type") == "story-theme":
            theme_node = node_id
            break

    if theme_node is None:
        # No theme node found — nothing to update
        return theme

    data = resources[theme_node].setdefault("data", {})

    # Update based on type
    if isinstance(theme, storymap.Themes):
        data["themeId"] = theme.value
    elif isinstance(theme, str):
        data["themeItemId"] = theme

    return theme


# ----------------------------------------------------------------------
def get_version(story) -> str:
    """
    Get the story, briefing, or collection version. All same version.
    This version is used when saving by adding it to the type keywords.
    """
    try:
        sm_version = story._gis._con.get("https://storymaps.arcgis.com/version")[
            "version"
        ]
    except Exception:
        # When behind firewall or using enterprise, the version is not available
        sm_mapping = {
            "[10, 3]": "22.49",  # Enterprise 11.1
            "[2023, 2]": "23.32",  # Enterprise 11.2
            "[2024, 1]": "24.12",  # Enterprise 11.3
            "[2024, 2]": "24.36",  # Enterprise 11.4
            "default": "24.12",
        }
        gis_version = str(story._gis.version[:2])
        sm_version = sm_mapping.get(gis_version, sm_mapping["default"])
    return sm_version


def publish_story(story, access, item_properties):
    """
    We need to manually update the item properties and resources.
    """
    # Remove old publish item
    for resource in story._resources:
        if (
            "publish_data" in resource["resource"]
            or "published_data" in resource["resource"]
            or "publish" in resource["resource"]
        ):
            remove_resource(story, file=resource["resource"])
    # Add new publish
    add_resource(
        story,
        resource_name="published_data.json",
        text=json.dumps(story._properties),
    )

    # add to item properties
    item_properties["text"] = json.dumps(story._properties)
    item_properties["url"] = story._url
    sharing = access or story._item.access
    item_properties["access"] = sharing

    # Update the item and invoke share to have correct access
    story._item.update(item_properties=item_properties)

    if sharing == "private":
        story._item.sharing.sharing_level = "PRIVATE"
    elif sharing == "org":
        story._item.sharing.sharing_level = "ORGANIZATION"
    elif sharing == "public":
        story._item.sharing.sharing_level = "EVERYONE"

    if story._gis._session.auth and story._gis._session.auth.token is not None:
        # Make a call to the StoryMaps publish endpoint
        story._gis._session.post(
            url=story._url + "/publish",
            data={
                "f": "json",
                "token": story._gis._session.auth.token,
            },
        )


def prepare_story_for_save(
    story, publish, make_copyable, no_seo, title, tags, sm_version
):
    """
    Remove old resource and add new draft resource that is the story._properties.
    """
    for resource in story._resources:
        if re.match("draft_[0-9]{13}.json", resource["resource"]) or re.match(
            "draft.json", resource["resource"]
        ):
            remove_resource(story, file=resource["resource"])

    # Add new draft with time in milliseconds
    draft = "draft_" + str(int(time.time() * 1000)) + ".json"

    # # Add a new empty json draft
    # add_resource(story, resource_name=draft, text="{}", access="private")

    # Create a temporary file to write the story._properties
    with tempfile.NamedTemporaryFile(
        mode="w+", suffix=".json", delete=False, encoding="utf-8"
    ) as temp:
        json.dump(story._properties, temp, ensure_ascii=False)
        temp.seek(0)

        # update the draft with the story._properties
        add_resource(story, file=temp.name, resource_name=draft, access="private")

    item_properties = prepare_item_properties_for_save(
        story, publish, make_copyable, no_seo, title, tags, sm_version, draft
    )
    return item_properties


def prepare_item_properties_for_save(
    story, publish, make_copyable, no_seo, title, tags, sm_version, draft
):
    # Find type keywords to use based on whether to publish or not
    if publish:
        keywords = story._item.typeKeywords
        if "smstatusunpublishedchanges" in keywords:
            # changing to publish after
            idx = keywords.index("smstatusunpublishedchanges")
            del keywords[idx]
        if "smstatusdraft" in keywords:
            idx = keywords.index("smstatusdraft")
            del keywords[idx]
        for keyword in keywords:
            # iterate through since only know part of keyword we want to remove
            if (
                "smdraftresourceid"
                or "smpublisheddate"
                or "smstatusdraft"
                or "smpublisherapp"
            ) in keyword:
                keywords.remove(keyword)
        new_keywords = [
            "smstatuspublished",
            "smversiondraft:" + sm_version,
            "smversionpublished:" + sm_version,
            "python-api",
            "smpublisherapp:python-api-" + arcgis.__version__,
            "smdraftresourceid:" + draft,
            "smpublisheddate:" + str(int(time.time() * 1000)),
        ]
        # publish keywords
        if make_copyable is True:
            new_keywords.append("Viewer Copyable")
        if no_seo is False:
            new_keywords.append("smsharingnoseo")
    else:
        # Set the type keywords
        keywords = story._item.typeKeywords
        previously_published = False
        for keyword in keywords:
            if "smpublisheddate" in keyword:
                # Update the date in new keywords
                previously_published = True
                keywords.remove(keyword)
            elif (
                "smstatuspublished" in keyword
                or "smstatusdraft" in keyword
                or "smdraftresourceid" in keyword
                or "smeditorapp" in keyword
                or "Copy Item" in keyword
            ):
                # Remove old keywords and will be replaced in new keywords
                keywords.remove(keyword)
        if previously_published is True:
            # Unpublished changes mode
            new_keywords = [
                "smstatusunpublishedchanges",
                "smversiondraft:" + sm_version,
                "python-api",
                "smeditorapp:python-api-" + arcgis.__version__,
                "smdraftresourceid:" + draft,
                "smversionpublished:" + sm_version,
                "smpublisheddate:" + str(int(time.time() * 1000)),
            ]
        if previously_published is False:
            # Draft mode
            new_keywords = [
                "smstatusdraft",
                "smversiondraft:" + sm_version,
                "python-api",
                "smeditorapp:python-api-" + arcgis.__version__,
                "smdraftresourceid:" + draft,
            ]

    # Add extra keywords
    if isinstance(story, briefing.Briefing):
        new_keywords = new_keywords + ["alphabriefing", "storymapbriefing"]
    elif isinstance(story, collection.Collection):
        new_keywords = new_keywords + ["storymapcollection"]

    new_keywords = list(set(keywords + new_keywords))

    p = {"typeKeywords": new_keywords}
    if title:
        p["title"] = title
    if tags:
        p["tags"] = tags
    return p


# ----------------------------------------------------------------------
def save(
    story,
    title: str | None = None,
    tags: list | None = None,
    access: str = None,
    publish: bool = False,
    make_copyable: bool = None,
    no_seo: bool = None,
):
    """
    This method will save your StoryMap or Briefing to your active GIS. The story will be saved
    with unpublished changes unless publish parameter is specified to True.

    The title only needs to be specified if a change is wanted, otherwise existing title
    is used.
    """
    # Add meta settings and change push meta so title doesn't get overwritten on publish at any point.
    if title:
        root = story._properties["root"]
        if "metaSettings" not in story._properties["nodes"][root]["data"]:
            story._properties["nodes"][root]["data"]["metaSettings"] = {"title": None}
        story._properties["nodes"][root]["data"]["metaSettings"]["title"] = title
        if "config" not in story._properties["nodes"][root]:
            story._properties["nodes"][root]["config"] = {}
        story._properties["nodes"][root]["config"][
            "shouldPushMetaToAGOItemDetails"
        ] = False

    # get the story map version from endpoint
    sm_version = get_version(story)

    # No endpoint, do manually
    item_properties = prepare_story_for_save(
        story, publish, make_copyable, no_seo, title, tags, sm_version
    )

    if publish:
        publish_story(story, access, item_properties)
    else:
        # access does not change when only saving
        item_properties["access"] = story._item.access
        story._item.update(item_properties=item_properties)

    story._item = story._gis.content.get(story._itemid)
    return story._item


# ----------------------------------------------------------------------
def delete_item(story):
    """
    Deletes the item.
    """
    # Check if item id exists
    item = story._gis.content.get(story._itemid)
    return item.delete(permanent=True)


# ----------------------------------------------------------------------
def duplicate(story, title: str | None = None):
    """
    Duplicate the story. All items will be duplicated as they are. This allows you to create
    a briefing template and duplicate it when you want to work with it.
    """
    # get the item to copy
    item = story._gis.content.get(story._itemid)
    # set the title
    title = title if title is not None else item.title + " Copy"
    # copy the story item
    copy = item.copy_item(title=title, include_resources=True, include_private=True)

    # remove the type keywords that are not needed
    keywords = story._item.typeKeywords
    for keyword in keywords:
        if "smeditorapp" in keyword or "Copy Item" in keyword:
            # Remove old keywords and will be replaced in new keywords
            keywords.remove(keyword)

    copy.update({"typeKeywords": keywords})

    # make a resources call
    copy.resources.list()
    return copy


# ----------------------------------------------------------------------
def get(story, node: str | None = None, type: str | None = None):
    """
    Get node(s) by type or by their id. Using this function will help grab a specific node
    from the story if a node id is provided. Set this to a variable and this way edits can be
    made on the node in the story.

    """
    spec_type = []
    node_id = node
    if node_id and node_id not in story._properties["nodes"]:
        raise ValueError(
            "This node value is not in the story. "
            + "Please check that you have entered the correct node id. "
            + "To see all main nodes and their ids use the nodes property."
        )
    if type is None and node_id is None:
        # return all nodes in order
        return story.nodes
    elif node_id is not None:
        # check first if it's an action
        all_actions = story.actions
        for action in all_actions:
            id = list(action.keys())[0]
            if node_id == id:
                return list(action.values())[0]
        # return a specific node
        all_nodes = create_node_dict(story)
        # find the node in the list and return it
        for node in all_nodes:
            id = list(node.keys())[0]
            if node_id == id:
                return list(node.values())[0]
    else:
        # return all nodes of a certain type
        all_nodes = create_node_dict(story)
        for node in all_nodes:
            keyword = str(list(node.values())[0]).lower()
            if isinstance(keyword, str):
                # Not a type of story content (i.e. navigation)
                if type.lower() in keyword:
                    spec_type.append(node)
            else:
                # Find all story content instances (i.e. Text)
                # Map types are uppercase and have spaces so handle
                if type.lower() in keyword._type.lower().replace(" ", ""):
                    spec_type.append(node)
        return spec_type


# ----------------------------------------------------------------------
def populate_resource_dict(story, resource, complete_resource_dict, resource_files):
    if isinstance(resource, str):
        # check if value is a resource
        if "r-" in resource:
            # get the resource dict
            resource_dict = story._properties["resources"][resource]
            complete_resource_dict[resource] = resource_dict
            if "resourceId" in resource_dict["data"]:
                # some nodes keep the resource under resourceId key
                name = resource_dict["data"]["resourceId"]
                # get the resource file to add to new story
                resource_file = story._item.resources.get(name)
                resource_files[name] = resource_file
            elif "itemId" in resource_dict["data"]:
                name = resource_dict["data"]["itemId"]
                # express map keeps resource under itemId key
                if name.endswith(".json"):
                    # need to add draft_ in front to be one-to-one with builder
                    name = "draft_" + resource_dict["data"]["itemId"]
                    # get the json file draft
                    resource_file = story._item.resources.get(name)
                    if resource_file and "error" in resource_file:
                        # if resource returns 403, skip and add warning
                        warnings.warn(
                            f"{name}: Resource is not accessible, the content placeholder will be copied but resource will have to be added manually."
                        )
                        return complete_resource_dict, resource_files
                    resource_files[name] = resource_file
    return complete_resource_dict, resource_files


# ----------------------------------------------------------------------
def populate_dicts(
    story,
    content: str,
    complete_node_dict: dict,
    complete_resource_dict: dict,
    resource_files: dict,
):
    content_dict = story._properties["nodes"][content]
    complete_node_dict[content] = content_dict
    # find the resource node to add associated with node. Text nodes have data but no resources
    if "data" in content_dict and content_dict["type"] != "text":
        for _, value in content_dict["data"].items():
            if not isinstance(value, list):
                value = [value]
            for val in value:
                # express maps keep their images in a list
                complete_resource_dict, resource_files = populate_resource_dict(
                    story, val, complete_resource_dict, resource_files
                )
    return complete_node_dict, complete_resource_dict, resource_files


# ----------------------------------------------------------------------
def copy_content(
    source: briefing.Briefing | storymap.StoryMap,
    target: briefing.Briefing | storymap.StoryMap,
    contents: list[str | object],
) -> bool:
    """
    Copy content from one story or briefing to another.

    For StoryMaps:
        - `contents` can be:
            * a list of node ids (str), or
            * a list of content objects exposing `_node`

    For Briefings:
        - `contents` can be:
            * a list of slide node ids (str), or
            * a list of `BriefingSlide` objects exposing `_node`

    Traverses the `_properties["nodes"]` / `["resources"]` structure to copy the
    entire node subtree and all dependent resources.

    After copying, the target is saved automatically.

    :return: True if all content was successfully copied.
    """
    # ------------------------------------------------------------------
    # 0. Sanity + type checks
    # ------------------------------------------------------------------
    if isinstance(source, storymap.StoryMap) and not isinstance(
        target, storymap.StoryMap
    ):
        raise TypeError("Cannot copy StoryMap content into a Briefing.")

    if isinstance(source, briefing.Briefing) and not isinstance(
        target, briefing.Briefing
    ):
        raise TypeError("Cannot copy Briefing content into a StoryMap.")

    # ------------------------------------------------------------------
    # 1. Normalize contents → list of node_ids
    # ------------------------------------------------------------------
    node_ids: list[str] = []

    for item in contents:
        if isinstance(item, str):
            node_ids.append(item)
        else:
            node_id = getattr(item, "_node", None)
            if not node_id:
                raise TypeError(
                    "All items must be node ids (str) or BriefingSlide for Briefing or content objects for StoryMap."
                )
            node_ids.append(node_id)

    original_nodes = list(node_ids)

    # ------------------------------------------------------------------
    # 2. Validate nodes belong to source
    # ------------------------------------------------------------------
    if isinstance(source, briefing.Briefing):
        root_id = source._properties["root"]
        ui_node = source._properties["nodes"][root_id]["children"][0]
        source_children = source._properties["nodes"][ui_node]["children"]
    else:
        root_id = source._properties["root"]
        source_children = source._properties["nodes"][root_id]["children"]

    if not all(node in source_children for node in node_ids):
        raise ValueError("The content must be part of the source story/briefing.")

    # ------------------------------------------------------------------
    # 3. Traverse the graph → gather all nodes + resources
    # ------------------------------------------------------------------
    processing_queue = list(node_ids)

    complete_node_list: list[str] = []
    complete_node_dict: dict = {}
    complete_resource_dict: dict = {}
    resource_files: dict = {}

    while processing_queue:
        # Gor through the current queue and
        # find any associated children that also need to be copied
        child_node_queue = []

        for node in processing_queue:
            if node not in complete_node_list:
                complete_node_list.append(node)

            (
                complete_node_dict,
                complete_resource_dict,
                resource_files,
            ) = populate_dicts(
                source,
                node,
                complete_node_dict,
                complete_resource_dict,
                resource_files,
            )

            children = has_children(source, node)
            if children:
                for child in children:
                    if child not in complete_node_list:
                        child_node_queue.append(child)

        # process children in next iteration
        processing_queue = child_node_queue

    # ------------------------------------------------------------------
    # 4. Handle node id collisions
    # ------------------------------------------------------------------
    target_nodes = list(target._properties["nodes"].keys())
    remap: dict[str, str] = {}  # old → new

    if any(n in target_nodes for n in complete_node_list):
        # if node already in target, create new unique ids
        for old_node in list(complete_node_list):
            if old_node in target_nodes:
                new_node = create_unique_id()

                remap[old_node] = new_node

                # update list of all nodes we plan to add
                idx = complete_node_list.index(old_node)
                complete_node_list[idx] = new_node

                # update root list if needed
                original_nodes = [
                    new_node if n == old_node else n for n in original_nodes
                ]

                # update node definitions
                updated = {}
                for key, val in complete_node_dict.items():
                    if key == old_node:
                        updated[new_node] = val
                    else:
                        updated[key] = val
                complete_node_dict = updated

                # update children inside node dict
                for key, val in complete_node_dict.items():
                    if "children" in val:
                        val["children"] = [
                            (new_node if c == old_node else c) for c in val["children"]
                        ]

    # ------------------------------------------------------------------
    # 4B. Rewrite references INSIDE node bodies now that remap is final
    # ------------------------------------------------------------------
    if remap:
        # rewrite node references inside every node definition
        for k in list(complete_node_dict.keys()):
            complete_node_dict[k] = rewrite_node_ids(complete_node_dict[k], remap)

        # rewrite references inside resources as well
        for k in list(complete_resource_dict.keys()):
            complete_resource_dict[k] = rewrite_node_ids(
                complete_resource_dict[k], remap
            )

        # rewrite root-level nodes
        original_nodes = [remap.get(n, n) for n in original_nodes]

    # ------------------------------------------------------------------
    # 5. Copy nodes + resources into target
    # ------------------------------------------------------------------
    for key, val in complete_node_dict.items():
        target._properties["nodes"][key] = val

    for key, val in complete_resource_dict.items():
        target._properties["resources"][key] = val

    # add resource files to item
    for key, val in resource_files.items():
        try:
            add_resource(target, file=val, resource_name=key)
        except Exception:
            text = json.dumps(val)
            add_resource(target, resource_name=key, text=text)

    # ------------------------------------------------------------------
    # 6. Attach the copied root nodes
    # ------------------------------------------------------------------
    for node in original_nodes:
        add_child(target, node)

    # ------------------------------------------------------------------
    # 7. Save
    # ------------------------------------------------------------------
    target.save()
    return True


# ----------------------------------------------------------------------
def rewrite_node_ids(obj, remap):
    """
    Recursively rewrite all node-id references inside a node/resource body.
    """
    if isinstance(obj, dict):
        for k, v in obj.items():
            obj[k] = rewrite_node_ids(v, remap)
        return obj

    if isinstance(obj, list):
        return [rewrite_node_ids(i, remap) for i in obj]

    if isinstance(obj, str):
        return remap.get(obj, obj)

    return obj


# ----------------------------------------------------------------------
def has_children(story, node) -> list | None:
    """
    Determine children of a node using node graph + class inspection.
    """
    node_class = assign_node_class(story, node)

    # StoryMap / Sidecar / Gallery / Timeline
    if isinstance(node_class, (Content.Sidecar, Content.Gallery, Content.Timeline)):
        return story._properties["nodes"][node].get("children", None)

    # Swipe
    if isinstance(node_class, Content.Swipe):
        c = story._properties["nodes"][node]["data"].get("contents", {})
        return list(c.values())

    # BriefingSlide
    if isinstance(node_class, Content.BriefingSlide):
        children: list[str] = []

        # 1) From block objects (existing behavior)
        for block in getattr(node_class, "blocks", []) or []:
            content_list = getattr(block, "content", None)
            if not content_list:
                continue

            for obj in content_list:
                nid = getattr(obj, "_node", None)
                if nid:
                    children.append(nid)

        # 2) From title object (existing, object-based case)
        title_obj = getattr(node_class, "title", None) or getattr(
            node_class, "_title", None
        )
        if title_obj is not None:
            nid = getattr(title_obj, "_node", None)
            if nid:
                children.append(nid)

        # 3) Fallback: inspect the raw node dict for string node-ids
        node_dict = story._properties["nodes"].get(node, {})
        data = node_dict.get("data", {})

        # title stored as a node-id string (e.g. "n-9fafe6")
        title_id = data.get("title")
        if isinstance(title_id, str) and title_id in story._properties["nodes"]:
            children.append(title_id)

        # (Optional but robust) walk contents for any direct node-id strings
        contents = data.get("contents")
        if isinstance(contents, dict):
            for v in contents.values():
                if isinstance(v, str) and v in story._properties["nodes"]:
                    children.append(v)

        # de-duplicate while preserving order
        if children:
            seen = set()
            ordered = []
            for c in children:
                if c not in seen:
                    seen.add(c)
                    ordered.append(c)
            return ordered

        return None

    # MapTour
    if isinstance(node_class, Content.MapTour):
        mt = get(story, node)
        return getattr(mt, "_children", None)

    # ExpressMap dependents
    if isinstance(node_class, Content.ExpressMap):
        deps = story._properties["nodes"][node].get("dependents", {}).get("media", None)
        return deps

    # string-type immersive nodes etc.
    if isinstance(node_class, str):
        lower = node_class.lower()
        if any(key in lower for key in ("immersive", "credits", "event", "carousel")):
            return story._properties["nodes"][node].get("children")

    return None


# ----------------------------------------------------------------------
def delete(story, node_id):
    # Check if node is in story
    if node_id not in story._properties["nodes"]:
        return False

    # Get list of nodes in the story
    root_id = story._properties["root"]
    children = story._properties["nodes"][root_id]["children"]

    # Remove from children of story
    if node_id in children:
        story._properties["nodes"][root_id]["children"].remove(node_id)
    # Remove from nodes dictionary
    del story._properties["nodes"][node_id]
    # Remove node from any immersive nodes.
    # A node can belong to an immersive narrative panel or an immersive slide
    for node in story._properties["nodes"]:
        if (
            "immersive" in story._properties["nodes"][node]["type"]
            and "children" in story._properties["nodes"][node]
        ):
            for child in story._properties["nodes"][node]["children"]:
                # iterate through children to see if node is part of it
                if child == node_id:
                    story._properties["nodes"][node]["children"].remove(node_id)

    return True


# ----------------------------------------------------------------------
def add_child(story, node_id, position=None):
    """
    A story node has children. Children is a list of item nodes that are in
    the story. The order of the list determines the order that the nodes
    appear in the story. First and last nodes are reserved for story_cover
    and credits. The second node is always navigation. If visible is not set
    to True is simply won't be seen but stays in position 2.
    """
    # Get list of children in story
    root_id = story._properties["root"]

    if isinstance(story, briefing.Briefing):
        # for briefings, the only child is the ui
        # the ui node has the slides
        principal_id = story._properties["nodes"][root_id]["children"][0]
        last = len(story._properties["nodes"][principal_id]["children"])
    else:
        # for storymap the children are the root
        principal_id = root_id
        # find the last position. If only one node then the last position is 1
        last = len(story._properties["nodes"][principal_id]["children"]) - 1

    if last == 0:
        # briefings only have cover when you start
        last = 1

    if position and position < last and position != 0 and position != 1:
        # If the position adheres to rules then add node
        story._properties["nodes"][principal_id]["children"].insert(position, node_id)
    elif position and (position == 0 or position == 1):
        # First and second node reserved for story cover and navigation
        # Add as third node if user specified position 0 or 1
        story._properties["nodes"][principal_id]["children"].insert(2, node_id)
    else:
        # Last node is reserved for credits so add before this if user wanted last position
        story._properties["nodes"][principal_id]["children"].insert(last, node_id)


# ----------------------------------------------------------------------
def add_resource(story, file=None, resource_name=None, text=None, access="inherit"):
    """
    See :class:`~arcgis.gis.ResourceManager`
    """
    resource_manager = arcgis.gis.ResourceManager(story._item, story._gis)
    is_present = False
    if file:
        for resource in story._resources:
            if resource["resource"] in file:
                is_present = True
                resp = True
    properties = {
        "editInfo": {
            "editor": story._gis._username,
            "modified": str(int(time.time() * 1000)),
            "id": uuid.uuid4().hex[0:21],
            "app": "python-api",
        }
    }

    # access is inherited from item upon add, except for json where always private
    if is_present is False:
        resp = resource_manager.add(
            file=file,
            file_name=resource_name,
            text=text,
            access=access,
            properties=properties,
        )

    story._resources = story._item.resources.list()
    return resp


# ----------------------------------------------------------------------
def remove_resource(story, file=None):
    """
    See :class:`~arcgis.gis.ResourceManager`
    """
    try:
        resource_manager = arcgis.gis.ResourceManager(story._item, story._gis)
        resp = resource_manager.remove(file=file)
        story._resources = story._item.resources.list()
        return resp
    except Exception:
        # Resource cannot be found. Should not throw error
        return True


# ----------------------------------------------------------------------
def assign_node_class(story, node_id):
    NODE_TYPE_CLASS_MAP = {
        "separator": Content.Separator,
        "briefing-slide": Content.BriefingSlide,
        "code": Content.Code,
        "image": Content.Image,
        "image360": Content.Image360,
        "video": Content.Video,
        "audio": Content.Audio,
        "embed": {
            "video": Content.Video,
            "link": Content.Embed,
            "app": Content.App,
        },
        "webmap": Content.Map,
        "text": Content.Text,
        "button": Content.Button,
        "swipe": Content.Swipe,
        "gallery": Content.Gallery,
        "timeline": Content.Timeline,
        "tour": Content.MapTour,
        "table": Content.Table,
        "immersive": {
            "sidecar": Content.Sidecar,
            # Add more subtypes as needed
        },
        "action-button": Content.MediaAction,
        "expressmap": Content.ExpressMap,
        "navigation": Content.Navigation,
        "large-number": Content.Infographic,
        "storycover": Content.Cover,
        "collection-cover": Content.Cover,
        "collection-nav": Content.CollectionNavigation,
    }

    node_properties = story._properties["nodes"][node_id]
    node_type = node_properties["type"]

    if node_type in NODE_TYPE_CLASS_MAP:
        node_class_or_subtype = NODE_TYPE_CLASS_MAP[node_type]

        if isinstance(node_class_or_subtype, dict):
            # Handle subtypes
            if "sidecar" in node_class_or_subtype:
                # Immersive sidecar has subtypes
                subtype_key = node_properties["data"].get("type")
            else:
                subtype_key = node_properties["data"].get(
                    "embedType"
                )  # Adjust based on actual subtype key
                if subtype_key == "link":
                    # a link can be an embed or an arcgis app
                    # only app has a resource associated
                    if node_properties["data"].get("embedResourceId"):
                        subtype_key = "app"
            node_class = node_class_or_subtype.get(subtype_key, node_type.capitalize())
        else:
            # No subtypes, use the class directly
            node_class = node_class_or_subtype
    else:
        # Unknown type, return the type name capitalized
        node_class = node_type.capitalize()

    if isinstance(node_class, str):
        return node_class
    else:
        return node_class(story=story, node_id=node_id)


# ----------------------------------------------------------------------
def create_node_dict(story):
    """
    Method called by the nodes property and the get method. However, the nodes
    property will transform the keys whereas the get method needs they keys
    to be class instances.
    """
    # get rood node id since it is story node id
    root_id = story._properties["root"]
    # get list of children from story node
    if isinstance(story, briefing.Briefing):
        ui = story._properties["nodes"][root_id]["children"]
        children = story._properties["nodes"][ui[0]]["children"]
    else:
        children = story._properties["nodes"][root_id]["children"]
    nodes = story._properties["nodes"]

    node_order = []
    # for each node assign correct class type to be accessed if needed by user
    for child in children:
        # get only the main nodes and not the subnodes to be returned
        if child in nodes:
            node = assign_node_class(story, child)
            node_order.append({child: node})
    return node_order


def create_unique_id(resource=False):
    prefix = "r-" if resource else "n-"
    return prefix + uuid.uuid4().hex[0:6]


def get_avif_dimensions(data):
    i = 0
    data_len = len(data)

    # ISO Base Media File Format — box structure:
    # [4-byte size][4-byte type][payload...]
    while i + 8 <= data_len:
        size = int.from_bytes(data[i : i + 4], "big")
        box_type = data[i + 4 : i + 8]

        if size == 0:  # box extends to end
            size = data_len - i

        if box_type == b"ispe":  # Image Spatial Extent box
            # ispe payload: [version(1), flags(3), width(4), height(4)]
            width = int.from_bytes(data[i + 8 + 4 : i + 8 + 8], "big")
            height = int.from_bytes(data[i + 8 + 8 : i + 8 + 12], "big")
            return width, height

        i += size

    return None


def get_jpeg_dimensions(data):
    # JPEG must start with FF D8
    if data[0:2] != b"\xff\xd8":
        return None

    i = 2
    data_len = len(data)

    while i < data_len - 1:
        if data[i] != 0xFF:
            i += 1
            continue

        marker = data[i + 1]

        # SOF0 / SOF2 contain real dimensions
        if marker in (0xC0, 0xC2):
            block_size = int.from_bytes(data[i + 2 : i + 4], "big")
            height = int.from_bytes(data[i + 5 : i + 7], "big")
            width = int.from_bytes(data[i + 7 : i + 9], "big")
            return width, height

        # Skip this block
        block_size = int.from_bytes(data[i + 2 : i + 4], "big")
        i += 2 + block_size

    return None


def get_png_dimensions(data):
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        width = int.from_bytes(data[16:20], "big")
        height = int.from_bytes(data[20:24], "big")
        return width, height
    return None


def get_image_dimensions(image_source):
    # Load bytes from URL or path
    if image_source.startswith("http://") or image_source.startswith("https://"):
        response = requests.get(image_source)
        if response.status_code != 200:
            return None
        image_data = response.content
    else:
        with open(image_source, "rb") as f:
            image_data = f.read()

    # Detect MIME using puremagic
    mime_info = puremagic.magic_string(image_data)[0]
    mime = mime_info.mime_type

    # PNG
    if mime == "image/png":
        dims = get_png_dimensions(image_data)
        if dims:
            return dims

    # JPEG
    if mime in ("image/jpeg", "image/jpg"):
        dims = get_jpeg_dimensions(image_data)
        if dims:
            return dims

    # AVIF
    if mime == "image/avif":
        dims = get_avif_dimensions(image_data)
        if dims:
            return dims

    # Fallback (unsupported)
    return None
