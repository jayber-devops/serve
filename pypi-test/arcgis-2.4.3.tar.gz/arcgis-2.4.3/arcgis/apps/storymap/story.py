from __future__ import annotations
import uuid
from enum import Enum

from arcgis._impl.common._deprecate import deprecated
from arcgis.auth.tools import LazyLoader

# Lazy load imports
re = LazyLoader("re")
copy = LazyLoader("copy")
arcgis = LazyLoader("arcgis")
story_content = LazyLoader("arcgis.apps.storymap.story_content")
json = LazyLoader("json")
time = LazyLoader("time")
utils = LazyLoader("arcgis.apps.storymap._utils")


# --------------------------------------------------------------------------------------
# Enumerations
# --------------------------------------------------------------------------------------
class Themes(Enum):
    """
    Represents the Supported Theme Type Enumerations.
    Example: story_map.theme(Themes.Slate)
    """

    SUMMIT = "summit"
    OBSIDIAN = "obsidian"
    RIDGELINE = "ridgeline"
    MESA = "mesa"
    TIDAL = "tidal"
    SLATE = "slate"


# --------------------------------------------------------------------------------------
# StoryMap Class
# --------------------------------------------------------------------------------------
class StoryMap(object):
    """
    A Story Map is a web map that has been thoughtfully created, given context, and provided
    with supporting information so it becomes a stand-alone resource. It integrates maps, legends,
    text, photos, and video and provides functionality, such as swipe, pop-ups, and time sliders,
    that helps users explore this content.

    ArcGIS StoryMaps is the next-generation storytelling tool in ArcGIS, and story authors are
    encouraged to use this tool to create stories. The Python API can help you create and edit
    your stories.

    Create a Story Map object to make edits to a story. Can be created from an item of type 'Story Map',
    an item id for that type of item, or if .nothing is passed, a new story is created from a generic draft.

    If an Item or item_id is passed in, only published changes or new drafts are taken from the Story Map.
    If you have a story with unpublished changes, they will not appear when you construct your story with the API.
    If you start to work on your Story that has unpublished changes and save from the Python API, your
    unpublished changes on the GUI will be overwritten with your work from the API.

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    item                Optional String or Item. The string for an item id or an item of type
                        'Story Map'. If no item is passed, a new story is created and saved to
                        your active portal.
    ---------------     --------------------------------------------------------------------
    gis                 Optional instance of :class:`~arcgis.gis.GIS` . If none provided the active gis is used.
    ===============     ====================================================================
    """

    _properties = None
    _gis = None
    _itemid = None
    _item = None
    _resources = None

    def __init__(
        self,
        item: arcgis.gis.Item | str | None = None,
        gis: arcgis.gis.GIS | None = None,
    ) -> None:
        # Section: Set up gis
        self._setup_gis(gis)
        self._setup_storymap(item)

    # ======================================================================
    # Setup and initialization helpers
    # ======================================================================
    def _setup_gis(self, gis: arcgis.gis.GIS | None) -> None:
        self._gis = gis or arcgis.env.active_gis

        if not self._gis._portal.is_logged_in:
            raise ValueError("Must be logged into a Portal Account")

        self._session = self._gis._con._session

    def _setup_storymap(self, item):
        if item and isinstance(item, str):
            # Get item using the item id
            item = self._gis.content.get(item)
            if item is None:
                # Error with storymap in current gis
                raise ValueError("Cannot find storymap associated with this item id.")
        if item and isinstance(item, arcgis.gis.Item) and item.type == "StoryMap":
            self._setup_existing_storymap(item)
        elif (
            item
            and isinstance(item, arcgis.gis.Item)
            and "StoryMap" not in item.typeKeywords
        ):
            # Throw error if item is not of type Story Map
            raise ValueError("Item is not a Story Map")
        else:
            # If no item was provided create a new story map
            self._create_new_storymap()
        # Get the story url
        self._url = self._get_url()

        #  Assign resources to item
        self._resources = self._item.resources.list()

    def _setup_existing_storymap(self, item: arcgis.gis.Item) -> None:
        saved_drafts = [
            resource["resource"]
            for resource in item.resources.list()
            if StoryMap._is_draft(resource["resource"])
        ]

        if saved_drafts:
            current_draft = StoryMap._get_most_recent_draft(saved_drafts)
            self._properties = item.resources.get(current_draft, try_json=True)
        else:
            self._properties = item.resources.get("published_data.json", try_json=True)
        self._item = item
        self._itemid = item.itemid

    @staticmethod
    def _is_draft(resource: str) -> object:
        return re.match(r"draft_[0-9]{13}\.json|draft\.json", resource)

    @staticmethod
    def _get_most_recent_draft(drafts: list[str]) -> str | None:
        drafts.remove("draft.json") if "draft.json" in drafts else None
        return max(drafts, key=lambda x: x[6:19]) if drafts else None

    def _create_new_storymap(self) -> None:
        # Step 1: Get template from _ref folder
        template = self._get_storymap_template()

        # Step 2: Customize template
        self._customize_template(template)

        # Step 3: Create a unique story node id
        self._create_unique_story_node(template)

        # Step 4: Set properties for the story
        self._properties = template

        # Step 5: Create a temporary title
        title = f"StoryMap via Python {uuid.uuid4().hex[:10]}"

        # Step 6: Create draft resource name
        draft = f"draft_{int(time.time() * 1000)}.json"

        # Step 7: Set keywords
        keywords = self._get_keywords(draft)

        # Step 8: Get default thumbnail for a new item
        thumbnail = self._get_thumbnail()

        # Step 9: Set the item properties
        item_properties = {
            "title": title,
            "typeKeywords": keywords,
            "type": "StoryMap",
        }

        # Step 10: Add item to active GIS and set properties
        if thumbnail:
            item_properties["thumbnail"] = thumbnail

        folder = self._gis.content.folders.get()
        self._item = folder.add(item_properties, text=" ").result()

        self._itemid = self._item.itemid

        # Step 11: Make a resource call with the template to create json draft needed
        utils.add_resource(
            self,
            resource_name=draft,
            text=json.dumps(template),
            access="private",
        )

    def _get_storymap_template(self) -> object:
        return copy.deepcopy(utils._TEMPLATES["storymap_2"])

    def _customize_template(self, template: object) -> None:
        template["nodes"]["n-aTn8ak"]["data"]["byline"] = self._gis._username
        template["nodes"]["n-4xkUEe"]["config"]["storyLocale"] = (
            self._gis.users.me.culture or "en-US"
        )

    def _create_unique_story_node(self, template: object) -> None:
        story_node = "n-" + uuid.uuid4().hex[:6]
        template["root"] = story_node
        template["nodes"][story_node] = template["nodes"]["n-4xkUEe"]
        del template["nodes"]["n-4xkUEe"]

    def _get_keywords(self, draft):
        sm_version = self._session.get(
            "https://storymaps.arcgis.com/version", params={"f": "json"}
        ).json()["version"]
        return ",".join(
            [
                "arcgis-storymaps",
                "StoryMap",
                "Web Application",
                "smstatusdraft",
                f"smversiondraft:{sm_version}",
                "python-api",
                f"smeditorapp:python-api-{arcgis.__version__}",
                f"smdraftresourceid:{draft}",
            ]
        )

    # ======================================================================
    # Representation methods
    # ======================================================================
    def _repr_html_(self) -> str:
        """
        HTML Representation for IPython Notebook
        """
        return self._item._repr_html_()

    def __str__(self) -> str:
        """Return the url of the storymap"""
        return self._url

    def __repr__(self) -> str:
        return self.__str__()

    # ======================================================================
    # Private utility methods
    # ======================================================================
    def _refresh(self) -> None:
        """Load the latest data from the item"""
        if self._item:
            self._properties = json.loads(self._item.get_data())

    def _get_url(self) -> str:
        """
        Private method to determine what the story url is. This is used to publish
        and have the correct path set.
        """
        if self._gis._is_arcgisonline:
            # Online
            self._url = "https://storymaps.arcgis.com/stories/{storyid}".format(
                storyid=self._itemid
            )
        else:
            # Enterprise
            self._url = "{portal}/apps/storymaps/stories/{storyid}".format(
                portal=self._gis.url.rstrip("/"), storyid=self._itemid
            )
        return self._url

    def _get_thumbnail(self) -> str:
        """
        Private method to get the default thumbnail path dependent on whether the
        user is Online or on Enterprise.
        """
        return utils.get_thumbnail(self._gis)

    # ======================================================================
    # Property Accessors
    # ======================================================================
    @property
    def story_locale(self) -> str:
        """
        Get/Set the locale and language of the story.

        If your story was created with the Python API then the default is "en-US"
        """
        # story_locale is found in story node (i.e. root node id)
        root = self._properties["root"]
        return (
            self._properties["nodes"][root]["config"]["storyLocale"]
            if "storyLocale" in self._properties["nodes"][root]["config"]
            else "en-US"
        )

    @story_locale.setter
    def story_locale(self, locale: str) -> str:
        """
        See story_locale property above
        """
        # cover date is found in story node (i.e. root node id)
        root = self._properties["root"]
        self._properties["nodes"][root]["config"]["storyLocale"] = locale
        return self.story_locale

    @deprecated(deprecated_in="2.4.2", removed_in="3.0.0")
    @property
    def properties(self) -> dict:
        """This property returns the storymap's JSON."""
        return self._properties

    @property
    @deprecated(
        deprecated_in="2.4.2",
        removed_in="3.0.0",
        details="Use content property instead.",
    )
    def content_list(self):
        """
        Get a list of all the content instances in order of appearance in the story.
        This returns a list of class instances for the content in the story.
        """
        return self.contents

    @property
    def contents(self):
        """
        Get a list of all the content instances in order of appearance in the story.
        This returns a list of class instances for the content in the story.
        """
        contents = []
        # get the values from the nodes list and return only these
        nodes = utils.create_node_dict(self)
        for node in nodes:
            content = list(node.values())[0]
            contents.append(content)
        return contents

    @property
    def actions(self) -> list:
        """
        Get list of action nodes.
        """
        actions = []
        if "actions" in self._properties:
            for action in self._properties["actions"]:
                node = utils.assign_node_class(self, action["origin"])
                actions.append(node)
        return actions

    @property
    @deprecated(
        deprecated_in="2.4.2",
        removed_in="3.0.0",
        details="Use Navigation class found in the content list instead.",
    )
    def navigation_list(self):
        """
        Get a list of the nodes that are linked in the navigation.
        """
        # navigation item has list of links corresponding to the text nodes in the navigation
        nav = utils.get(story=self, type="navigation")[0]
        for key, value in nav.items():
            node_id = key
        try:
            links = self._properties["nodes"][node_id]["data"]["links"]
            node_ids = []
            for link in links:
                for key, value in link.items():
                    # Only return list of node_ids this way easier for navigation method
                    if key == "nodeId":
                        node_ids.append(value)
            return node_ids
        except Exception:
            return None

    # ======================================================================
    # Public interface methods
    # ======================================================================
    def show(self, width: int | None = None, height: int | None = None) -> object:
        """
        Show a preview of the story. The default is a width of 700 and height of 300.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        width               Optional integer. The desired width to show the preview.
        ---------------     --------------------------------------------------------------------
        height              Optional integer. The desired height to show the preview.
        ===============     ====================================================================

        :return:
            An Iframe display of the story map if possible, else the item url is returned to be
            clicked on.
        """
        return utils.show(self._item, width, height)

    def get_logo(self) -> object:
        """
        Get the logo image for the story. The logo is seen in the header of the story.
        """
        # logo is found in story node (i.e. root node id)
        root = self._properties["root"]
        logo_resource = self._properties["nodes"][root]["data"]["storyLogoResource"]
        resource = self._properties["resources"][logo_resource]["data"]["resourceId"]

        return self._item.resources.get(resource)

    def set_logo(
        self,
        image: str | None = None,
        link: str | None = None,
        alt_text: str | None = None,
    ) -> bool:
        """
        Set the logo for the story. The logo is seen in the header of the story.

        .. note::
            To remove the logo, link, or alt text, pass in an empty string. If they are None, nothing
            will be changed for that parameter. For example if you only want to update the link but leave
            the image and alt text as is, pass in None for the image and alt text. Pass in the new link
            for the link parameter.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        image               Required string. The file path to the image to be used as the
                            logo.
        ---------------     --------------------------------------------------------------------
        link                Optional string. The url to link to when the logo is clicked.
        ---------------     --------------------------------------------------------------------
        alt_text            Optional string. The alt text to be used for screen readers.
        ===============     ====================================================================

        :return: True if successful.

        .. code-block:: python

            story = StoryMap("<story item>")
            story.set_logo("<image-path>.jpg/jpeg/png/gif")
        """
        # call method to update logo
        return utils.set_logo(self, image, link, alt_text)

    def get_theme(self) -> str | None:
        """
        Get the theme ID or theme item ID used in the story.
        """
        return utils.get_theme(self)

    def theme(self, theme: Themes | str | None = None) -> bool:
        """
        Each story has a theme node in its resources. This method can be used to change the theme.
        To add a custom theme to your story, pass in the item_id for the item of type Story Map Theme.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        theme               Required Themes Style or custom theme item id.
                            The theme to set the story to.

                            Values: `SUMMIT` | `TIDAL` | `MESA` | `RIDGELINE` | `SLATE` | `OBSIDIAN` | `<item_id>`
        ===============     ====================================================================

        .. code-block:: python

            >>> from arcgis.apps.storymap import Themes

            >>> story = StoryMap()
            >>> story.theme(Themes.TIDAL)
        """
        # call method to update theme
        return utils.theme(self, theme)

    # ======================================================================
    # Credits handling
    # ======================================================================
    def credits(
        self,
        content: str | None = None,
        attribution: str | None = None,
        heading: str | None = None,
        description: str | None = None,
    ) -> list:
        """
        Credits are found at the end of the story and thus are always the last node.

        To create a credit, add the text that should be shown on each side of the divider.
        content represents the text seen on the left side and attribution is in line with content
        on the right side of the divider. (i.e. 'content' | 'attribution')

        Adding ``content`` and ``attribution`` will add a new line to the credits and will not change previous
        credits.

        Adding ``heading`` and ``description`` will change what is currently in place.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        content             Optional String. The content to be added. (Seen on the left side of
                            the credits.)

                            Make sure text has '<strong> </strong>' tags.
                            Adds to the existing credits.
        ---------------     --------------------------------------------------------------------
        attribution         Optional String. The attribution to be added. (Seen on right side of
                            the credits.)
                            Adds to the existing credits.
        ---------------     --------------------------------------------------------------------
        heading             Optional String. Replace current heading for credits.
        ---------------     --------------------------------------------------------------------
        description         Optional String. Replace current description for credits.
        ===============     ====================================================================

        :return:
            A list of strings that are the node ids for the text nodes that belong to credits.

        .. code-block:: python

            #Example
            >>> story = StoryMap()
            >>> story.credits("Python Dev" , "Python API Team", "Thank You", "A big thank you to those who contributed")
        """
        # Validate parameters
        if (heading is None and description is not None) or (
            heading is not None and description is None
        ):
            raise ValueError(
                "Both heading and description should be provided if one is provided."
            )

        # Find credit node
        credits_node_id = self._get_credits_node_id()

        # Get existing children or initialize an empty list
        children = self._properties["nodes"][credits_node_id].get("children", [])

        # Add content and attribution if provided
        nodes = self._add_content_and_attribution(content, attribution)

        # Update or add heading
        self._update_or_add_heading(heading, children)

        # Update or add description
        self._update_or_add_description(description, children)

        # Add nodes to children of credits
        if "children" not in self._properties["nodes"][credits_node_id]:
            self._properties["nodes"][credits_node_id]["children"] = []
        self._properties["nodes"][credits_node_id]["children"].extend(nodes)
        return self._properties["nodes"][credits_node_id]["children"]

    def _get_credits_node_id(self):
        # get the node_id for the node of type credits
        for node_id, node in self._properties["nodes"].items():
            if node["type"] == "credits":
                return node_id

    def _generate_unique_node_id(self) -> str:
        return "n-" + uuid.uuid4().hex[:6]

    def _add_content_and_attribution(
        self, content: str | None, attribution: str | None
    ) -> list:
        nodes = []
        if content or attribution:
            # Create new content node
            node_id = self._generate_unique_node_id()
            self._properties["nodes"][node_id] = {
                "type": "attribution",
                "data": {"attribution": attribution, "content": content},
            }
            nodes.append(node_id)
        return nodes

    def _update_or_add_heading(self, heading, children):
        # Create new heading and remove old one
        if heading:
            # Create new content node
            # Create new heading node
            node_id = self._generate_unique_node_id()
            self._properties["nodes"][node_id] = {
                "type": "text",
                "data": {"text": heading, "type": "h4"},
            }
            children = self._update_or_remove_node(children, "text", "h4")

    def _update_or_add_description(self, description, children):
        if description:
            # Create new description node
            node_id = self._generate_unique_node_id()
            self._properties["nodes"][node_id] = {
                "type": "text",
                "data": {"text": description, "type": "paragraph"},
            }
            children = self._update_or_remove_node(children, "text", "paragraph")

    def _credit_child_exists(self, child: str, node_type: str, data_type: str) -> bool:
        if (
            self._properties["nodes"][child]["type"] == node_type
            and self._properties["nodes"][child]["data"]["type"] == data_type
        ):
            return True
        return False

    def _update_or_remove_node(self, children, node_type, data_type):
        for child in children:
            if self._credit_child_exists(child, node_type, data_type):
                del self._properties["nodes"][child]
                children.remove(child)
        return children

    # ======================================================================
    # Content management methods
    # ======================================================================
    def add(
        self,
        content: (
            story_content.Image
            | story_content.Image360
            | story_content.Video
            | story_content.Audio
            | story_content.Embed
            | story_content.Map
            | story_content.Button
            | story_content.Text
            | story_content.Gallery
            | story_content.Timeline
            | story_content.Sidecar
            | story_content.Code
            | story_content.Swipe
            | story_content.Separator
            | story_content.Table
            | story_content.App
            | story_content.Infographic
            | list
            | None
        ) = None,
        caption: str | None = None,
        alt_text: str | None = None,
        position: int | None = None,
    ) -> bool:
        """
        Use this method to add content to your StoryMap. content can be of various class types and when
        you add this content you can specify a caption, alt_text, display style, and the position
        at which it will be in your story.
        Not passing in any content means a separator will be added.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        content             Required content of type:
                            :class:`~arcgis.apps.storymap.story_content.Image`,
                            :class:`~arcgis.apps.storymap.story_content.Image360`,
                            :class:`~arcgis.apps.storymap.story_content.Gallery`,
                            :class:`~arcgis.apps.storymap.story_content.Video`,
                            :class:`~arcgis.apps.storymap.story_content.Audio`,
                            :class:`~arcgis.apps.storymap.story_content.Embed`,
                            :class:`~arcgis.apps.storymap.story_content.Map`,
                            :class:`~arcgis.apps.storymap.story_content.Text`,
                            :class:`~arcgis.apps.storymap.story_content.Button`,
                            :class:`~arcgis.apps.storymap.story_content.Timeline`,
                            :class:`~arcgis.apps.storymap.story_content.Sidecar`
                            :class:`~arcgis.apps.storymap.story_content.Swipe`,
                            :class:`~arcgis.apps.storymap.story_content.Separator`,
                            :class:`~arcgis.apps.storymap.story_content.Code`,
                            :class:`~arcgis.apps.storymap.story_content.Table`,
                            :class:`~arcgis.apps.storymap.story_content.App`
                            :class:`~arcgis.apps.storymap.story_content.Infographic`

                            If a list of content is passed, cannot specify other parameters.
        ---------------     --------------------------------------------------------------------
        caption             Optional string. The caption for the content.
        ---------------     --------------------------------------------------------------------
        alt_text            Optional string. The alt text for the content.
        ---------------     --------------------------------------------------------------------
        position            Optional Integer. Indicates the position in which the content will be
                            added. To see all node positions use the ``node`` property.
        ===============     ====================================================================

        :return: True if content was successfully added.

        .. code-block:: python

            new_story = StoryMap()

            # Example with Image
            >>> image1 = Image("<image-path>.jpg/jpeg/png/gif ")
            >>> new_node = new_story.add(image1, position = 2)

            # Example with Map
            >>> my_map = Map(<item-id of type webmap>)
            >>> new_node = new_story.add(my_map, "A map caption", "A new map alt-text")

            # Example to add a Separator
            >>> new_node = new_story.add()

            >>> print(new_story.nodes)
        """
        if not isinstance(content, list):
            content = [content]

        for content in content:
            if content and content._node in self._properties["nodes"]:
                # need to give unique node id if the same item is added more than once
                content._node = utils.create_unique_id()

            content._add_to_story(story=self, caption=caption, alt_text=alt_text)

            # Add to story children
            utils.add_child(self, node_id=content._node, position=position)
        return True

    def save(
        self,
        title: str | None = None,
        tags: list | None = None,
        access: str | None = None,
        publish: bool = False,
        make_copyable: bool | None = None,
        no_seo: bool | None = None,
    ) -> object:
        """
        This method will save your Story Map to your active GIS. The story will be saved
        with unpublished changes unless `publish` parameter is specified to True.

        The title only needs to be specified if a change is wanted, otherwise existing title
        is used.

        .. warning::
            Publishing your story through the Python API means it will not go through the Story Map
            issue checker. It is recommended to publish through the Story Maps builder if you
            want your story to go through the issue checker.

        .. warning::
            Changes to the published story may not be visible for up to one hour. You can open
            the story in the story builder to force changes to appear immediately and perform
            other optimizations, such as updating the story's social/SEO metadata.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        title               Optional string. The title of the StoryMap.
        ---------------     --------------------------------------------------------------------
        tags                Optional string. The tags of the StoryMap.
        ---------------     --------------------------------------------------------------------
        access              Optional string. The access of the StoryMap. If none is specified, the
                            current access is kept. This is used when `publish` parameter is set
                            to True.

                            Values: `private` | `org` | `public`
        ---------------     --------------------------------------------------------------------
        publish             Optional boolean. If True, the story is saved and also published.
                            Default is false so story is saved with unpublished changes.
        ---------------     --------------------------------------------------------------------
        make_copyable       Optional boolean. If True, the story is saved as copyable for users.
        ---------------     --------------------------------------------------------------------
        no_seo              Optional boolean. If True, the story is saved without SEO metadata.
        ===============     ====================================================================


        :return: The Item that was saved to your active GIS.

        """
        # call the save method in common utils module
        return utils.save(self, title, tags, access, publish, make_copyable, no_seo)

    def delete_story(self) -> bool:
        """
        Deletes the story item.
        """
        # Check if item id exists
        # deletes the item
        return utils.delete_item(self)

    def duplicate(self, title: str | None = None) -> object:
        """
        Duplicate the story. All items will be duplicated as they are. This allows you to create
        a story template and duplicate it when you want to work with it.

        It is highly recommended that once the duplicate is created, open it in Story Maps
        builder to ensure the issue checker finds any issues before editing.

        .. note::
            Can be used with ArcGIS Online or with ArcGIS Enterprise starting 10.8.1

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        title               Optional string. The title of the duplicated story. Only available for
                            ArcGISOnline.
        ===============     ====================================================================

        :return:
            The Item that was created.

        .. code-block:: python

            # Example for ArcGIS Online
            >>> story = StoryMap(<story item>)
            >>> story.duplicate("A Story Copy")

            # Example for ArcGIS Enterprise
            >>> story = StoryMap(<story item>)
            >>> story.duplicate()
        """
        # call the duplicate (clones the item)
        return utils.duplicate(self, title)

    def copy_content(self, target_story: StoryMap, node_list: list) -> bool:
        """
        Copy the content from one story to another. This will copy the content
        indicated to the target story in the order they are provided. To change the
        order once the nodes are copied, use the `move()` method on the target story.

        .. note::
            Do not forget to save the target story once you are done copying and making
            any further edits.

        .. note::
            This method can take time depending on the number of resources. Each resource coming
            from a file must be copied over and heavy files, such as videos or audio, can be time
            consuming.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        target_story        Required StoryMap instance. The target story that the content will be
                            copied to.
        ---------------     --------------------------------------------------------------------
        node_list           Required list of content. The list of content
                            that will be copied to the target story. You can get the list of contents
                            for the story using the `content` property.
        ===============     ====================================================================

        :return:
            True if all content have been successfully copied over.

        """
        return utils.copy_content(self, target_story, node_list)
