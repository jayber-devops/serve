from __future__ import annotations
import json
from arcgis.auth.tools import LazyLoader
from arcgis._impl.common._utils import _date_handler

_arcgis = LazyLoader("arcgis")

__all__ = ["_format_payload"]


def _format_payload(params: dict) -> dict:
    for k, v in params.items():
        if isinstance(v, (dict, list, tuple, bool)):
            params[k] = json.dumps(v, default=_date_handler)
        elif isinstance(v, _arcgis._impl.common._mixins.PropertyMap):
            params[k] = json.dumps(dict(v), default=_date_handler)
        elif isinstance(v, _arcgis._impl.common._isd.InsensitiveDict):
            params[k] = v.json
    return params
