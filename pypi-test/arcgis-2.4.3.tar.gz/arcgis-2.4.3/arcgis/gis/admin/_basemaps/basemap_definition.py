basemap_dict = {
    "satellite": [
        {
            "id": "satellite-base-layer",
            "url": "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Imagery",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        }
    ],
    "hybrid": [
        {
            "id": "hybrid-base-layer",
            "url": "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Imagery",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "hybrid-reference-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/30d6b8271e1849cd9c3042060001f425/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "Hybrid Reference Layer",
            "isReference": True,
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
    ],
    "terrain": [
        {
            "id": "terrain-base-layer",
            "url": "https://services.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Terrain Base",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "terrain-reference-layer",
            "url": "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Reference_Overlay/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Reference Overlay",
            "isReference": True,
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
    ],
    "oceans": [
        {
            "id": "oceans-base-layer",
            "url": "https://services.arcgisonline.com/arcgis/rest/services/Ocean/World_Ocean_Base/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Ocean Base",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "oceans-reference-layer",
            "url": "https://services.arcgisonline.com/arcgis/rest/services/Ocean/World_Ocean_Reference/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Ocean Reference",
            "isReference": True,
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
    ],
    "osm": [
        {
            "id": "osm-base-layer",
            "layerType": "OpenStreetMap",
            "title": "Open Street Map",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        }
    ],
    "dark-gray-vector": [
        {
            "id": "dark-gray-base-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/5e9b3685f4c24d8781073dd928ebda50/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "Dark Gray Base",
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "dark-gray-reference-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/747cb7a5329c478cbe6981076cc879c5/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "Dark Gray Reference",
            "isReference": True,
            "visibility": True,
            "opacity": 1,
        },
    ],
    "gray-vector": [
        {
            "id": "gray-base-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/291da5eab3a0412593b66d384379f89f/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "Light Gray Base",
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "gray-reference-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/1768e8369a214dfab4e2167d5c5f2454/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "Light Gray Reference",
            "isReference": True,
            "visibility": True,
            "opacity": 1,
        },
    ],
    "streets-vector": [
        {
            "id": "streets-vector-base-layer",
            "styleUrl": "##cdn.arcgis.com/sharing/rest/content/items/de26a3cf4cc9451298ea173c4b324736/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "World Streets",
            "visibility": True,
            "opacity": 1,
        }
    ],
    "topo-vector": [
        {
            "id": "world-hillshade-layer",
            "url": "https://services.arcgisonline.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Hillshade",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "topo-vector-base-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/7dc6cea0b1764a1f9af2e679f642f0f5/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "World Topo",
            "visibility": True,
            "opacity": 1,
        },
    ],
    "streets-night-vector": [
        {
            "id": "streets-night-vector-base-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/86f556a2d1fd468181855a35e344567f/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "World Streets Night",
            "visibility": True,
            "opacity": 1,
        }
    ],
    "streets-relief-vector": [
        {
            "id": "world-hillshade-layer",
            "url": "https://services.arcgisonline.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
            "layerType": "ArcGISTiledMapServiceLayer",
            "title": "World Hillshade",
            "showLegend": False,
            "visibility": True,
            "opacity": 1,
        },
        {
            "id": "streets-relief-vector-base-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/b266e6d17fc345b498345613930fbd76/resources/styles/root.json",
            "title": "World Streets Relief",
            "layerType": "VectorTileLayer",
            "visibility": True,
            "opacity": 1,
        },
    ],
    "streets-navigation-vector": [
        {
            "id": "streets-navigation-vector-base-layer",
            "styleUrl": "https://www.arcgis.com/sharing/rest/content/items/63c47b7177f946b49902c24129b87252/resources/styles/root.json",
            "layerType": "VectorTileLayer",
            "title": "World Streets Navigation",
            "visibility": True,
            "opacity": 1,
        }
    ],
    "arcgis-imagery": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Imagery",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/World_Imagery/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Imagery:Labels",
            "title": "Hybrid Reference Layer",
            "isReference": True,
        },
    ],
    "arcgis-imagery-standard": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Imagery",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/World_Imagery/MapServer",
        }
    ],
    "arcgis-imagery-labels": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Imagery:Labels",
            "title": "Hybrid Reference Layer",
            "isReference": True,
        }
    ],
    "arcgis-light-gray": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:LightGray:Base",
            "title": "Light Gray Canvas Base",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:LightGray:Labels",
            "title": "Light Gray Canvas Labels",
            "isReference": True,
        },
    ],
    "arcgis-dark-gray": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:DarkGray:Base",
            "title": "Dark Gray Canvas Base",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:DarkGray:Labels",
            "title": "Dark Gray Canvas Labels",
            "isReference": True,
        },
    ],
    "arcgis-navigation": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Navigation",
            "title": "World Navigation Map",
        }
    ],
    "arcgis-navigation-night": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:NavigationNight",
            "title": "World Navigation Map (Dark Mode)",
        }
    ],
    "arcgis-streets": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Streets",
            "title": "World Street Map",
        }
    ],
    "arcgis-streets-night": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:StreetsNight",
            "title": "World Street Map (Night)",
        }
    ],
    "arcgis-streets-relief": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:StreetsRelief:Base",
            "title": "World Street Map (with Relief)",
        },
    ],
    "arcgis-topographic": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Topographic:Base",
            "title": "World Topographic Map",
        },
    ],
    "arcgis-oceans": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Ocean Base",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Ocean/World_Ocean_Base/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Oceans:Labels",
            "title": "World Ocean Reference",
            "isReference": True,
        },
    ],
    "osm-standard": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:Standard",
            "title": "OpenStreetMap",
        }
    ],
    "osm-standard-relief": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:StandardRelief:Base",
            "layerType": "VectorTileLayer",
            "title": "OpenStreetMap Relief Base",
        },
    ],
    "osm-streets": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:Streets",
            "title": "OpenStreetMap (Streets)",
        }
    ],
    "osm-streets-relief": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:StreetsRelief:Base",
            "layerType": "VectorTileLayer",
            "title": "OpenStreetMap Relief Base",
        },
    ],
    "osm-light-gray": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:LightGray:Base",
            "title": "OSM (Light Gray Base)",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:LightGray:Labels",
            "title": "OSM (Light Gray Reference)",
            "isReference": True,
        },
    ],
    "osm-dark-gray": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:DarkGray:Base",
            "title": "OSM (Dark Gray Base)",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/OSM:DarkGray:Labels",
            "title": "OSM (Dark Gray Reference)",
            "isReference": True,
        },
    ],
    "arcgis-terrain": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Terrain:Base",
            "title": "World Terrain Base",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Terrain:Detail",
            "title": "World Terrain Reference",
            "isReference": True,
        },
    ],
    "arcgis-community": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Community",
            "title": "Community",
        }
    ],
    "arcgis-charted-territory": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:ChartedTerritory:Base",
            "title": "Charted Territory",
        },
    ],
    "arcgis-colored-pencil": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:ColoredPencil",
            "title": "Colored Pencil",
        }
    ],
    "arcgis-nova": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Nova",
            "title": "Nova",
        }
    ],
    "arcgis-modern-antique": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:ModernAntique:Base",
            "title": "Modern Antique",
        },
    ],
    "arcgis-midcentury": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Midcentury",
            "title": "Mid-Century",
        }
    ],
    "arcgis-newspaper": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:Newspaper",
            "title": "Newspaper",
        }
    ],
    "arcgis-hillshade-light": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer",
        }
    ],
    "arcgis-hillshade-dark": [
        {
            "layerType": "ArcGISTiledMapServiceLayer",
            "showLegend": False,
            "title": "World Hillshade (Dark)",
            "url": "https://ibasemaps-api.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade_Dark/MapServer",
        }
    ],
    "arcgis-human-geography": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:HumanGeography:Base",
            "title": "Human Geography Base",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:HumanGeography:Detail",
            "title": "Human Geography Detail",
            "isReference": True,
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:HumanGeography:Label",
            "title": "Human Geography Label",
            "isReference": True,
        },
    ],
    "arcgis-human-geography-dark": [
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:HumanGeographyDark:Base",
            "title": "Human Geography Dark Base",
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:HumanGeographyDark:Detail",
            "title": "Human Geography Dark Detail",
            "isReference": True,
        },
        {
            "layerType": "VectorTileLayer",
            "styleUrl": "https://basemaps-api.arcgis.com/arcgis/rest/services/styles/ArcGIS:HumanGeographyDark:Label",
            "title": "Human Geography Dark Label",
            "isReference": True,
        },
    ],
}
basemap_dict_3d = {
    "topo-3d": {
        "baseMapLayers": [
            {
                "id": "18c679fb712-layer-37",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/1e7d1784d1ef4b79ba6764d0bd6c3150/resources/styles/root.json",
                "title": "Topographic",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "18c679ff88d-layer-39",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Trees",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_Trees_Thematic_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "18c67a02c0e-layer-40",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_DarkLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "18c679fde82-layer-38",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "18c679f066c-basemap-24",
        "title": "Topographic",
    },
    "navigation-3d": {
        "baseMapLayers": [
            {
                "id": "187e8fed2af-layer-0",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/ccc904ff872b4144b94934e55e32784b/resources/styles/root.json",
                "title": "Navigation",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "187e9050b73-layer-118",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_DarkLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "187e902e9f5-layer-117",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "187e8fedaab-basemap-36",
        "title": "Navigation",
    },
    "streets-3d": {
        "baseMapLayers": [
            {
                "id": "188f6cabbc4-layer-0",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/198298c4c64c4cb19de5b46aa00c198d/resources/styles/root.json",
                "title": "Streets",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "188f6c665f1-layer-63",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_DarkLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "188f6ccb089-layer-64",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "189012ccb2b-basemap-38",
        "title": "Streets",
    },
    "osm-3d": {
        "baseMapLayers": [
            {
                "id": "18dfc1e01ef-layer-49",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/8628d259c9d14bdc848771c23c513940/resources/styles/root.json",
                "title": "OpenStreetMap",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "18dfc1e3c1b-layer-50",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Trees",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_Trees_Thematic_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "18dfc1e7cd5-layer-52",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_DarkLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "18dfc1e591a-layer-51",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "18dfc17dee0-basemap-27",
        "title": "OpenStreetMap",
    },
    "gray-3d": {
        "baseMapLayers": [
            {
                "id": "189007ef83c-layer-0",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/01a14b466345455ba4176d2e6390db92/resources/styles/root.json",
                "title": "Light Gray Canvas",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "189007fe854-layer-64",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_DarkLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "189007fb122-layer-63",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "189007f0249-basemap-38",
        "title": "Light Gray Canvas",
    },
    "navigation-dark-3d": {
        "baseMapLayers": [
            {
                "id": "187e8fee2e2-layer-0",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/451a1777ab3f4bf095fae24a117439d9/resources/styles/root.json",
                "title": "Navigation (Dark)",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "187e918bf48-layer-116",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_LightLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "187e918e06c-layer-117",
                "layerDefinition": {
                    "drawingInfo": {
                        "renderer": {
                            "authoringInfo": {},
                            "symbol": {
                                "symbolLayers": [
                                    {
                                        "castShadows": True,
                                        "material": {"color": [55.0, 59.0, 62.0]},
                                        "type": "Fill",
                                    }
                                ],
                                "type": "MeshSymbol3D",
                            },
                            "type": "simple",
                        }
                    },
                    "elevationInfo": {"mode": "relativeToGround", "unit": "meter"},
                },
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "187e8feecb4-basemap-36",
        "title": "Navigation (Dark)",
    },
    "streets-dark-3d": {
        "baseMapLayers": [
            {
                "id": "188f6beaae0-layer-65",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/bc599b6d741a4ac084b7eea7bf8c5938/resources/styles/root.json",
                "title": "Streets (Dark)",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "188f6bf48b3-layer-66",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_LightLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "188f6bc8733-layer-63",
                "layerDefinition": {
                    "drawingInfo": {
                        "renderer": {
                            "authoringInfo": {},
                            "symbol": {
                                "symbolLayers": [
                                    {
                                        "castShadows": True,
                                        "material": {"color": [63.0, 67.0, 74.0]},
                                        "type": "Fill",
                                    }
                                ],
                                "type": "MeshSymbol3D",
                            },
                            "type": "simple",
                        }
                    },
                    "elevationInfo": {"mode": "relativeToGround", "unit": "meter"},
                },
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "188fb97e335-basemap-38",
        "title": "Streets (Dark)",
    },
    "dark-gray-3d": {
        "baseMapLayers": [
            {
                "id": "18900921725-layer-0",
                "layerType": "VectorTileLayer",
                "opacity": 1.0,
                "styleUrl": "https://cdn.arcgis.com/sharing/rest/content/items/4178f71acb934fb89f169e7d667c20c6/resources/styles/root.json",
                "title": "Dark Gray Canvas",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "1890092f8c2-layer-64",
                "layerDefinition": {},
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Places and Labels",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/OpenStreetMap3D_LightLabels_v1/SceneServer/layers/0",
                "visibility": True,
            },
            {
                "disablePopup": True,
                "id": "1890093eabc-layer-65",
                "layerDefinition": {
                    "drawingInfo": {
                        "renderer": {
                            "authoringInfo": {},
                            "symbol": {
                                "symbolLayers": [
                                    {
                                        "castShadows": True,
                                        "material": {"color": [69.0, 75.0, 82.0]},
                                        "type": "Fill",
                                    }
                                ],
                                "type": "MeshSymbol3D",
                            },
                            "type": "simple",
                        }
                    },
                    "elevationInfo": {"mode": "relativeToGround", "unit": "meter"},
                },
                "layerType": "ArcGISSceneServiceLayer",
                "listMode": "show",
                "opacity": 1.0,
                "screenSizePerspective": True,
                "showLabels": False,
                "showLegend": True,
                "timeAnimation": True,
                "title": "Buildings",
                "url": "https://basemaps3d.arcgis.com/arcgis/rest/services/Esri3D_Buildings_v1/SceneServer/layers/0",
                "visibility": True,
            },
        ],
        "id": "1890092201e-basemap-38",
        "title": "Dark Gray Canvas",
    },
}
