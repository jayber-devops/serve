from __future__ import annotations
import json
import datetime
from arcgis.gis import GIS, User, Item
from arcgis._impl.common._utils import local_time_to_online


###########################################################################
class BaseTask:
    """
    Base Schedule Class
    """

    _url = None
    _gis = None
    _con = None
    _properties = None

    def __init__(self, url: str, gis: GIS):
        self._url = url
        self._gis = gis

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"<{self.__class__.__name__}>"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def properties(self) -> dict:
        """
        Set of properties for the object.
        """
        if self._properties is None:
            params = {"f": "json"}
            res = self._gis._con.get(self._url, params)
            self._properties = res
        return self._properties


###########################################################################
class Run(BaseTask):
    """
    Represents a run of a scheduled :class:`task <arcgis.gis.tasks.Task>`. The
    objects are not meant to be initialized directly, but instead a list of
    *runs* are returned by the :attr:`~arcgis.gis.tasks.Task.runs` property
    of :class:`task <arcgis.gis.tasks.Task>` objects.

    ==================     ====================================================================
    **Parameter**           **Description**
    ------------------     --------------------------------------------------------------------
    url                    Required string. The URL to the REST endpoint.
    ------------------     --------------------------------------------------------------------
    gis                    Required GIS. The GIS object.
    ==================     ====================================================================
    """

    _gis = None
    _url = None

    # ----------------------------------------------------------------------
    def __init__(self, url: str, gis: GIS):
        super(Run, self)
        self._url = url
        self._gis = gis

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"<{self.__class__.__name__} @ {self.properties['runId']}>"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Removes the Task from the System.

        :return: Boolean

        """
        url = f"{self._url}/delete"
        params = {"f": "json"}
        res = self._gis._con.post(url, params)
        if "success" in res:
            return res["success"]
        return res

    # ----------------------------------------------------------------------
    @property
    def properties(self) -> dict:
        """
        A dictionary object listing various properties of the
        :class:`run <arcgis.gis.tasks.Run>` object.
        """
        if self._properties is None:
            params = {"f": "json"}
            resp = self._gis.session.get(self._url, params=params)
            res: dict = resp.json()
            self._properties = res
        return self._properties

    # ----------------------------------------------------------------------
    def update(self, status: str | None = None, description: str | None = None) -> bool:
        """
        Updates the Run's Status Message and Result Message.

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        status                 Optional String. The status of the run.  The allowed values are:
                               `scheduled`, `executing`, `succeeded`, `failed`, or `skipped`.
        ------------------     --------------------------------------------------------------------
        description            Optional String. Updates the descriptive message associated with the
                               current `Run`.
        ==================     ====================================================================

        :return: Boolean

        """
        params = {"f": "json"}
        status_values = [
            "scheduled",
            "executing",
            "succeeded",
            "failed",
            "skipped",
        ]
        if status is None and description is None:
            return False
        if status and status.lower() in status_values:
            params["status"] = status.lower()
        elif status and status.lower() not in status_values:
            raise ValueError("Invalid status")
        elif status is None:
            params["status"] = self.properties["status"]
        if description:
            params["result"] = description
        elif description is None:
            params["result"] = self.properties["result"]

        url = f"{self._url}/update"
        res = self._gis._con.post(url, params)
        if "success" in res:
            self._properties = None
            return res["success"]
        return res


###########################################################################
class Task(BaseTask):
    """
    Represents a scheduled :class:`task <arcgis.gis.tasks.Task>`. These objects
    are not meant to be intialized directly, but instead are returned
    by the :attr:`~arcgis.gis.tasks.TaskManager.all` property or
    :meth:`~arcgis.gis.tasks.TaskManager.search` method on the
    :class:`~arcgis.gis.tasks.TaskManager` object.

    .. code-block:: python

        # Usage example:  Returning task objects for an item
        >>> from arcgis.gis import GIS
        >>> gis = GIS(profile="your_organization_profile")

        >>> task_mgr = gis.users.me.tasks
        >>> user_item = gis.content.get(<item_id>)
        >>> task_list = task_mgr.search(item=user_item)
        >>> task_list

            [<Task @ 3259ac1...afc154f>,
             <Task @ 10f7a74...3afa7de>,
             <Task @ 0e6dc28...32ac65b>]

        >>> t0 = task_list[0]
        >>> t0

            <Task @ 3259ac1...afc154f>

    ==================     ====================================================================
    **Parameter**           **Description**
    ------------------     --------------------------------------------------------------------
    url                    Required string. The URL to the REST endpoint.
    ------------------     --------------------------------------------------------------------
    gis                    Required GIS. The GIS object.
    ==================     ====================================================================

    """

    _url = None
    _gis = None

    def __init__(self, url: str, gis: GIS):
        super(Task, self)
        self._url = url
        self._gis = gis

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"<Task @ {self.properties['id']}>"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Removes the Task from the System.

        :return: Boolean

        """
        url = f"{self._url}/delete"
        params = {"f": "json"}
        res = self._gis._con.post(url, params)
        if "success" in res:
            return res["success"]
        return res

    # ----------------------------------------------------------------------
    def enable(self, enabled: bool) -> bool:
        """
        The `enable` method allows administrators to enable or disable the scheduled task..

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        enabled                Required Boolean.  If True, the status of the task is set to active.
                               If False, the task is set active to False.
        ==================     ====================================================================

        :return: Boolean

        """
        params = {"f": "json"}
        if enabled == True:
            url = f"{self._url}/enable"
        elif enabled == False:
            url = f"{self._url}/disable"
        else:
            raise ValueError("`enabled` must be a boolean value")
        res = self._gis._con.post(url, params)
        if "success" in res:
            return res["success"]
        return res

    # ----------------------------------------------------------------------
    @property
    def properties(self) -> dict:
        """
        A dictionary object listing various properties of the
        :class:`task <arcgis.gis.tasks.Task>` object.

        .. code-block:: python

            # Usage Example: Listing keys of the properties object for a task:

            >>> from arcgis.gis import GIS
            >>> gis = GIS(profile="your_organization_profile")

            >>> task_mgr = gis.users.me.tasks
            >>> tsk = task_mgr.search(item=my_item)[0]
            >>> list(tsk.properties.keys())

                ['id',
                'itemId',
                'type',
                'title',
                'userId',
                'cronSchedule',
                'runIntervalSeconds',
                'nextStart',
                'maxOccurrences',
                'created',
                'updated',
                'startDate',
                'active',
                'taskState']

        :return:
            Dictionary-like object of *task* properties.
        """
        if self._properties is None:
            resp = self._gis.session.get(
                self._url,
                params={
                    "f": "json",
                },
            )
            resp.raise_for_status()
            self._properties = resp.json()
        return self._properties

    # ----------------------------------------------------------------------
    def start(self) -> bool:
        """
        Starts a task if it is actively running.

        :return: Boolean

        """
        return self.update(is_active=True)

    # ----------------------------------------------------------------------
    def stop(self) -> bool:
        """
        Stops a task if it is actively running.

        :return: Boolean

        """
        return self.update(is_active=False)

    # ----------------------------------------------------------------------
    def update(
        self,
        item: Item | None = None,
        cron: str | None = None,
        task_type: str | None = None,
        occurences: int = 10,
        start_date: datetime.datetime | None = None,
        end_date: datetime.datetime | None = None,
        title: str | None = None,
        parameters: dict | None = None,
        task_url: str | None = None,
        is_active: bool | None = None,
    ) -> bool:
        """
        Updates the current Task

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        item                   Optional Item. The item to update the schedule for.
        ------------------     --------------------------------------------------------------------
        cron                   Optional String. The executution time syntax.
        ------------------     --------------------------------------------------------------------
        task_type              Required String. The type of task, either executing a notebook or
                               updating an Insights workbook, that will be executed against the
                               specified item.  For notebook server tasks use ``ExecuteNotebook``,
                               for Insights notebook use: ``UpdateInsightsWorkbook``. Use
                               ``ExecuteSceneCook`` to cook scene tiles. Use ``ExecuteWorkflowManager``
                               to run workflow manager tasks.
                               Values: `ExecuteNotebook`, `UpdateInsightsWorkbook`,
                               `ExecuteSceneCook`, `ExecuteWorkflowManager`, `ExecuteReport`, or
                               `GPService`ns are
                               ``ExecuteNotebook`` or ``UpdateInsightsWorkbook``
        ------------------     --------------------------------------------------------------------
        occurences             Optional Integer. The maximum number of occurrences this task should execute.
        ------------------     --------------------------------------------------------------------
        start_date             Optional Datetime. The date/time when the task will begin executing.
        ------------------     --------------------------------------------------------------------
        end_date               Optional Datetime.  The date/time when the task will stop executing.
        ------------------     --------------------------------------------------------------------
        title                  Optional String. The name of the task.
        ------------------     --------------------------------------------------------------------
        parameters             Optional Dict.  Additional key/value pairs for execution of notebooks.
        ------------------     --------------------------------------------------------------------
        task_url               Optional String. A response URL with a set of results.
        ------------------     --------------------------------------------------------------------
        is_active              Optional Bool. Determines if the tasks is currently running.
        ==================     ====================================================================

        :return: Boolean or Dict on error.

        """
        SPECIALS = {
            "reboot": "@reboot",
            "hourly": "0 * * * *",
            "daily": "0 0 * * *",
            "weekly": "0 0 * * 0",
            "monthly": "0 0 1 * *",
            "yearly": "0 0 1 1 *",
            "annually": "0 0 1 1 *",
            "midnight": "0 0 * * *",
        }
        params = {
            "title": title or self.properties["title"],
            "type": task_type or self.properties["type"],
            "taskUrl": task_url or "",
            "parameters": parameters,
            "itemId": None,
            "minute": None,
            "hour": None,
            "dayOfMonth": None,
            "month": None,
            "dayOfWeek": None,
            "maxOccurrences": occurences or self.properties["maxOccurrences"],
            "isActive": None,
            "f": "json",
        }
        if is_active is None:
            params.pop("isActive", None)
        else:
            params["isActive"] = json.dumps(is_active)
        if task_url is None:
            params.pop("taskUrl", None)
        if cron is None:
            cron_schedule: dict = self.properties.get("cronSchedule", {})
            params["minute"] = cron_schedule.get("minute")
            params["hour"] = cron_schedule.get("hour")
            params["dayOfMonth"] = cron_schedule.get("dayOfMonth")
            params["month"] = cron_schedule.get("month")
            params["dayOfWeek"] = cron_schedule.get("dayOfWeek")
        elif isinstance(cron, str) and cron in SPECIALS:
            cron = SPECIALS[cron].split(" ")
            params["minute"] = cron[0]
            params["hour"] = cron[1]
            params["dayOfMonth"] = cron[2]
            params["month"] = cron[3]
            params["dayOfWeek"] = cron[4]
        else:
            cron = cron.split(" ")
            params["minute"] = cron[0]
            params["hour"] = cron[1]
            params["dayOfMonth"] = cron[2]
            params["month"] = cron[3]
            params["dayOfWeek"] = cron[4]

        if isinstance(item, Item):
            params["itemId"] = item.itemid
        elif item:
            params["itemId"] = item
        else:
            params["itemId"] = self.properties["itemId"]

        if start_date:
            params["startDate"] = local_time_to_online(dt=start_date)
        else:
            params.pop("startDate", None)
        if end_date:
            params["endDate"] = local_time_to_online(dt=end_date)
        else:
            params.pop("endDate", None)
        if parameters:
            params["parameters"] = json.dumps(parameters)
        elif "parameters" in self.properties:
            params["parameters"] = self.properties["parameters"]
        url = f"{self._url}/update"
        res = self._gis._con.post(url, params)
        if "success" in res:
            self._properties = None
            return res["success"]
        return res

    # ----------------------------------------------------------------------
    @property
    def runs(self) -> list:
        """
        Returns all *runs* for the *task*.  The maximum number of runs
        returned is 30>

        :return:
            List of :class:`~arcgis.gis.tasks.Run` objects.
        """
        runs = []
        url = f"{self._url}/runs"
        params = {"f": "json"}
        res = self._gis._con.get(url, params)
        for t in res["runs"]:
            run_url = f"{self._url}/runs/{t['runId']}"
            runs.append(Run(url=run_url, gis=self._gis))
            del t
        return runs


###########################################################################
class TaskManager:
    """

    Provides the functions to create, update, delete and view
    :class:`task <arcgis.gis.tasks.Task>` objects.

     .. note::
        Available starting with ArcGIS Enterprise release 10.8.1, and ArcGIS Online.

    Objects are not meant to be initialized directly, but instead are accessed
    using the :attr:`~arcgis.gis.User.tasks` property on a :class:`~arcgis.gis.User`
    object:

    .. code-block:: python

        >>> from arcgis.gis import GIS
        >>> gis = GIS(profile="your_online_profile")

        >>> task_mgr = gis.users.me.tasks
        >>> type(task_mgr)

        <class 'arcgis.gis.tasks._schedule.TaskManager'>

    ==================     ====================================================================
    **Parameter**           **Description**
    ------------------     --------------------------------------------------------------------
    url                    Required string. The URL to the REST endpoint.
    ------------------     --------------------------------------------------------------------
    user                   Required User. The user to perform the Task management on.
    ------------------     --------------------------------------------------------------------
    gis                    Required GIS. The GIS object.
    ==================     ====================================================================


    """

    _tasks = None

    def __init__(self, url: str, user: User, gis: GIS):
        """initializer"""
        self._url = url
        self._user = user
        self._gis = gis

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"<User {self._user.username} Tasks>"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    def search(
        self,
        item: Item | None = None,
        active: bool | None = None,
        types: str | None = None,
    ) -> list[Task]:
        """
        This property allows users to search for tasks based on criteria.

        ================  ===============================================================================
        **Parameter**      **Description**
        ----------------  -------------------------------------------------------------------------------
        item              Optional :class:`~arcgis.gis.Item`. The item to query tasks about.
        ----------------  -------------------------------------------------------------------------------
        active            Optional Bool. Queries tasks based on active status.
        ----------------  -------------------------------------------------------------------------------
        types             Optional String. The type of notebook execution for the item.  Can be one of:

                          * *ExecuteNotebook*
                          * *UpdateInsightsWorkbook*
                          * *ExecuteSceneCook*
                          * *ExecuteWorkflowManager*
                          * *ExecuteReport*
                          * *GPService*
        ================  ===============================================================================

        :return:
            List of :class:`~arcgis.gis.tasks.Task` objects

        """
        if item is None and active is None and types is None:
            return self.all
        else:
            _tasks = []
            url = f"{self._gis._portal.resturl}community/users/{self._user.username}/tasks"
            params = {
                "num": 100,
                "start": 1,
            }
            if item:
                params["itemId"] = item.itemid
            if not active is None:
                params["active"] = active
            if types:
                params["types"] = types
            res = self._gis._con.get(url, params)
            for t in res["tasks"]:
                url = f"{self._url}/{t['id']}"
                _tasks.append(Task(url=url, gis=self._gis))
            while res["nextStart"] != -1:
                params["start"] = res["nextStart"]
                res = self._gis._con.get(url, params)
                for t in res["tasks"]:
                    url = f"{self._url}/{t['id']}"
                    _tasks.append(Task(url=url, gis=self._gis))
            return _tasks
        return []

    # ----------------------------------------------------------------------
    def create(
        self,
        item: Item,
        cron: str,
        task_type: str,
        occurences: int = 10,
        start_date: datetime.datetime | None = None,
        end_date: datetime.datetime | None = None,
        title: str | None = None,
        parameters: dict | None = None,
        task_url: str | None = None,
    ) -> Task:
        """
        Creates a new scheduled task.

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        item                   Required :class:`~arcgis.gis.Item`. The item to schedule a task on.
        ------------------     --------------------------------------------------------------------
        cron                   Required String. The CRON statement. This should be in the following
                               format:

                               *<minute> <hour> <day of month> <month> <day of week>`*

                               Example to run a task weekly, use: `0 0 * * 0`.

                               .. note::
                                   See `cron <https://en.wikipedia.org/wiki/Cron#Overview>`_ for
                                   details on valid values and meanings for symbols.
        ------------------     --------------------------------------------------------------------
        task_type              Required String. The type of task that will be executed against the
                               specified _item_.

                               Values:

                               * `ExecuteNotebook`
                               * `UpdateInsightsWorkbook`
                               * `ExecuteSceneCook`
                               * `ExecuteWorkflowManager`
                               * `ExecuteReport`,
                               * `GPService`
                               * `RunDataPipeline`
        ------------------     --------------------------------------------------------------------
        occurences             Optional Integer. The maximum number of times the task will run.
        ------------------     --------------------------------------------------------------------
        start_date             Optional Datetime. The begin date for the task to run.
        ------------------     --------------------------------------------------------------------
        end_date               Optional Datetime. The end date for the task to run.
        ------------------     --------------------------------------------------------------------
        title                  Optional String. The title of the scheduled task.
        ------------------     --------------------------------------------------------------------
        parameters             Optional Dict. Optional collection of Key/Value pairs that will be
                               inserted into the task run at time of request.

                               .. note::
                                   Required when *task_type* argument is *ExecuteSceneCook*

                               .. code-block:: python

                                   # Usage Example: For a scene service
                                   >>> task_mgr = gis.users.me.tasks
                                   >>> task_output = task_mgr.create(
                                                             ...
                                                             parameters = {
                                                                   "service_url": <scene service URL>,
                                                                   "num_of_caching_service_instances": 2, #(2 instances are required)
                                                                   "layer": "{<list of scene layers to cook>}", #The default is all layers
                                                                   "update_mode": "PARTIAL_UPDATE_NODES"
                                                                },
                                                            ...
                                                        )
        ------------------     --------------------------------------------------------------------
        task_url               Optional String. The URL of the task of an asynchronous
                               geoprocessing service on any of the federated servers of your portal.

                               .. note::
                                   Required when *task_type* argument is *GPService*
        ==================     ====================================================================

        :return:
            :class:`~arcgis.gis.tasks.Task` object

        .. code-block:: python

            # Usage Example: Schedule a notebook to run every 15 minutes for 5 runs
            #                starting March 8, 2025 at 1pm Pacific

            >>> import datetime as dt
            >>> import pytz
            >>> from arcgis.gis import GIS

            >>> gis = GIS(profile="your_online_profile")

            >>> nb_item = gis.content.search("air_quality_regular_updates", "notebook")[0]

            >>> dt = dt.datetime(2025, 3, 8, 13, 0, 0)
            >>> pdt_tz = pytz.timezone("US/Pacific")
            >>> dt_pdt = pdt_tz.localize(dt)


            >>> tsk_mgr = gis.users.me.tasks
            >>> tsk_mgr.create(
            >>>        item=nb_item,
            >>>        cron= "*/15 * ? * 1,2,3,4,5,6,7",
            >>>        task_type="ExecuteNotebook",
            >>>        occurences=5,
            >>>        start_date= dt_pdt,
            >>>        title="data_index_update"
            >>>    )

        """
        SPECIALS = {
            "reboot": "@reboot",
            "hourly": "0 * * * *",
            "daily": "0 0 * * *",
            "weekly": "0 0 * * 0",
            "monthly": "0 0 1 * *",
            "yearly": "0 0 1 1 *",
            "annually": "0 0 1 1 *",
            "midnight": "0 0 * * *",
        }
        url = f"{self._url}/createTask"
        params = {
            "f": "json",
            "title": title,
            "type": task_type,
            "parameters": None,
            "itemId": None,
            "startDate": start_date,
            "endDate": end_date,
            "minute": None,
            "hour": None,
            "dayOfMonth": None,
            "month": None,
            "dayOfWeek": None,
            "maxOccurrences": occurences,
        }
        if task_url:
            params["taskURL"] = task_url
        if isinstance(item, Item):
            params["itemId"] = item.itemid
        else:
            params["itemId"] = item
        if title is None:
            params.pop("title", None)
        if start_date:
            params["startDate"] = local_time_to_online(dt=start_date)
        else:
            params.pop("startDate", None)
        if end_date:
            params["endDate"] = local_time_to_online(dt=end_date)
        else:
            params.pop("endDate", None)
        if cron in SPECIALS:
            cron = SPECIALS[cron]
        if cron:
            cron = cron.split(" ")
            while len(cron) < 5:
                cron.append("*")
            params.update(
                {
                    "minute": cron[0],
                    "hour": cron[1],
                    "dayOfMonth": cron[2],
                    "month": cron[3],
                    "dayOfWeek": cron[4],
                }
            )
        if parameters:
            if params["type"] == "ExecuteNotebook":
                params["parameters"] = json.dumps(
                    {"notebookParameters": parameters, "saveInjectedParameters": True}
                )
            else:
                params["parameters"] = json.dumps(parameters)
        res = self._gis._con.post(url, params)

        if "success" in res and res["success"]:
            url = f"{self._url}/{res['taskId']}"
            return Task(url, gis=self._gis)
        return res

    # ----------------------------------------------------------------------
    @property
    def all(self) -> list:
        """
        returns all the current user's tasks

        :return:
            List of :class:`~arcgis.gis.tasks.Task` objects

        """
        if self._tasks is None:
            self._tasks = []
            url = f"{self._gis._portal.resturl}community/users/{self._user.username}/tasks"
            params = {
                "num": 100,
                "start": 1,
            }
            res = self._gis._con.get(url, params)
            for t in res["tasks"]:
                url = f"{self._url}/{t['id']}"
                self._tasks.append(Task(url=url, gis=self._gis))
            while res["nextStart"] != -1:
                params["start"] = res["nextStart"]
                res = self._gis._con.get(url, params)
                for t in res["tasks"]:
                    url = f"{self._url}/{t['id']}"
                    self._tasks.append(Task(url=url, gis=self._gis))
        return self._tasks

    # ----------------------------------------------------------------------
    @property
    def count(self) -> int:
        """
        Returns the number of tasks belonging to the :class:`~arcgis.gis.User`.

        :return: Int
        """
        url = f"{self._gis._portal.resturl}community/users/{self._user.username}/tasks"
        params = {
            "num": 1,
            "start": 1,
        }
        res = self._gis._con.get(url, params)
        return res["total"]
