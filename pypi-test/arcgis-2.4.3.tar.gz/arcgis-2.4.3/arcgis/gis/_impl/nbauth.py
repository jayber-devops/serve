from __future__ import annotations


def get_token(nb_auth_file_path: str) -> str:
    """
    Returns the token provided by the notebook server for authentication

    :return: str
    """
    try:
        import arcgis_notebooks_auth
    except ImportError:
        raise ImportError(
            "The arcgis_notebooks_auth package is required to use notebook authentication; "
            "Please install it using `!conda install -c esri arcgis_notebooks_auth`"
        )
    return arcgis_notebooks_auth.get_token(nb_auth_file_path)
