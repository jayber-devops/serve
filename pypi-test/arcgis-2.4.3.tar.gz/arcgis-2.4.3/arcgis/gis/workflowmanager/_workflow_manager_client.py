class WorkflowManagerClient:
    """
    Wrapper around GIS/connection with logic specific to Workflow Manager API calls

    Intended for internal API use only.
    """

    def __init__(self, gis):
        self._gis = gis
        self._connection = gis._con

    def delete(self, url, **kwargs):
        return self._connection.delete(
            url, no_retry_drop_auth=True, try_json=False, **kwargs
        )

    def get(self, url, params: dict | None = None, **kwargs):
        return self._connection.get(url, params, no_retry_drop_auth=True, **kwargs)

    def post(
        self,
        url,
        params: dict | None = None,
        try_json: bool = False,
        post_json: bool = True,
        **kwargs
    ):
        return self._connection.post(
            url,
            params,
            no_retry_drop_auth=True,
            try_json=try_json,
            json_encode=False,
            post_json=post_json,
            **kwargs
        )

    def post_multipart(self, url: str, files: dict, params: dict | None = None):
        return self._connection.post_multipart(
            url,
            files=files,
            params=params,
            try_json=False,
            json_encode=False,
            post_json=False,
        )

    def put(self, url, params: dict | None = None, **kwargs):
        return self._connection.put(
            url,
            params,
            no_retry_drop_auth=True,
            post_json=True,
            try_json=False,
            json_encode=False,
            **kwargs
        )

    def handle_json_error(self, error: str, error_code: int = 0):
        self._connection._handle_json_error(error, error_code)
