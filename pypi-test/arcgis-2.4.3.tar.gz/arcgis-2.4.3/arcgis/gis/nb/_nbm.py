from __future__ import annotations
import os
import json
import time
from typing import Optional, Iterable, Any, Literal
from arcgis.gis import GIS, Item
from arcgis.auth.tools import LazyLoader
from arcgis._impl.common._mixins import PropertyMap
import concurrent.futures
import requests
from pydantic import BaseModel, ConfigDict, Field, ConfigDict

_common_deprecated = LazyLoader("arcgis._impl.common._deprecate")


###########################################################################
class RuntimeConfiguration(BaseModel):
    """
    The inputs for adding a custom runtime. This model should be used as
    the input for the `RuntimeManager.add` operation.

    """

    model_config = ConfigDict(
        populate_by_name=True,
        str_strip_whitespace=True,
        extra="allow",
        use_enum_values=True,
    )
    name: str = Field(
        ...,
        alias="name",
        description="A string to represent the new runtime, such as 'Notebook Custom Runtime Python 3' .",
    )
    image_id: str = Field(
        ...,
        alias="imageId",
        description="Full (nontruncated) ID for the new Docker image, when it was built.",
    )
    max_cpu: int | float = Field(
        ...,
        alias="maxCPU",
        description="The maximum number of CPU units to be used for each container.",
    )
    max_memory: int | float = Field(
        ...,
        alias="maxMemory",
        description="The maximum amount of memory to be used for each container.",
    )
    container_type: Literal["docker"] = Field("docker", frozen=True)
    max_memory_unit: str = Field(
        "g",
        alias="maxMemoryUnit",
        description="The unit specified by the max_memory parameter.",
    )
    requires_advanced_privileges: bool = Field(
        True,
        alias="requiresAdvancedPrivileges",
        description="Set this value to `true` if the runtime requires advanced privileges.",
    )
    shared_memory: int | float | None = Field(
        None,
        alias="sharedMemory",
        description="The amount of shared memory available for each container.",
    )
    shared_memory_unit: str = Field(
        "m",
        alias="sharedMemoryUnit",
        description="The unit specified by the shared memory parameter.",
    )
    image_pull_string: str | None = Field(
        None, alias="imagePullString", description="Optional string to pull the image."
    )
    docker_runtime: str | None = Field(
        None,
        alias="dockerRuntime",
        description="Only applies to GPU runtimes in Linux environments.",
    )
    manifest_file: str | None = Field(
        None,
        alias="manifestFile",
        description="The full path to a .json file (in UTF-8 or ANSI encoding) containing the list of Python libraries in the runtime.",
    )
    create_manifest_file: bool = Field(
        False,
        alias="createManifestFile",
        description="If set to true , a manifest .json file is automatically created for the Docker image registered as the notebook runtime. Providing a file for the manifestFile parameter overrides this setting.",
    )

    def _multipart_form_format(self, add_f: bool = True) -> dict[str, tuple]:
        """
        Return a dictionary formatted for use in a multipart/form-data
        request.
        """
        files = {}
        for key, value in self.model_dump(by_alias=True, exclude_none=False).items():
            if value is None:
                files[key] = (None, "")
            elif isinstance(value, bool):
                files[key] = (None, str(value).lower())
            elif isinstance(value, (int, float)):
                files[key] = (None, str(value))
            elif isinstance(value, dict):
                files[key] = (None, json.dumps(value))
            elif isinstance(value, str):
                files[key] = (None, value)
            else:
                files[key] = (None, json.dumps(value))
        if add_f:
            files["f"] = (None, "json")
        return files


###########################################################################
class RuntimeManager:
    """
    The `RuntimeManager` provides a way to manage and create runtimes on
    the ArcGIS Notebook Server site.

    There is one runtime included in each Docker container image, which is
    applied to a container at launch time. Notebook authors open ArcGIS
    Notebooks in their individual containers. The runtime included with the
    container image makes a precise collection of Python modules available
    to each notebook in the container.

    By default, there are two runtimes for ArcGIS Notebook Server: ArcGIS
    Notebook Python 3 Standard and ArcGIS Notebook Python 3 Advanced. These
    runtimes are loaded with their corresponding container images during
    ArcGIS Notebook Server installation, by running the postinstallation
    utility.
    """

    _url: str
    _gis: GIS | None = None
    _properties: dict[str, Any] | None = None

    # ---------------------------------------------------------------------
    def __init__(self, url: str, gis: GIS) -> None:
        self._url = url
        self._gis = gis
        self.session = gis.session

    # ----------------------------------------------------------------------
    def __str__(self):
        return "< RuntimeManager @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    def __repr__(self):
        return "< RuntimeManager @ {url} >".format(url=self._url)

    # ---------------------------------------------------------------------
    @property
    def properties(self) -> dict[str, Any]:
        """
        returns the properties of the endpoint
        :return: dict[str,Any]
        """
        if self._properties is None:
            resp: requests.Response = self.session.get(
                self._url,
                params={
                    "f": "json",
                },
            )
            resp.raise_for_status()
            self._properties = resp.json()
        return self._properties

    # ----------------------------------------------------------------------
    @property
    def current_runtime_version(self) -> str:
        """returns the current runtime version"""
        return self.properties.get("currentRuntimeVersion")

    # ----------------------------------------------------------------------
    @property
    def runtimes(self) -> Iterable[Runtime]:
        """
        Returns all registered runtimes for the notebook server.

        :return: Iterable[Runtime]
        """
        url: str = self._url
        params: dict[str, Any] = {"f": "json"}
        resp: requests.Response = self.session.get(url=url, params=params)
        resp.raise_for_status()
        res: dict[str, Any] = resp.json()
        if "runtimes" in res:
            for r in res["runtimes"]:
                yield Runtime(url=url + "/{rid}".format(rid=r["id"]), gis=self._gis)

    # ---------------------------------------------------------------------
    def restore(self) -> bool:
        """
        Resets the runtimes to the orginial factory settings

        :returns: bool
        """
        url: str = f"{self._url}/restore"
        params: dict[str, Any] = {
            "f": "json",
        }
        resp: requests.Response = self.session.post(url=url, data=params)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        self._refresh()
        if "error" in data:
            raise Exception(f"The `restore` opeation failed: {data}")
        elif "status" in data:
            return data["status"] == "success"

    # ---------------------------------------------------------------------
    def validate(self) -> dict[str, Any]:
        """
        This validates that Docker images that are associated with runtimes
        are installed on each machine of the Notebook Server site.

        :return: dict[str, Any]
        """
        url: str = f"{self._url}/validateRuntimes"
        params: dict[str, Any] = {
            "f": "json",
        }
        resp: requests.Response = self.session.post(url=url, data=params)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        if "error" in data:
            raise Exception(
                f"An error has been encountered with the `validate`: {data}"
            )
        return data

    # ----------------------------------------------------------------------
    def add(self, configuration: RuntimeConfiguration) -> Runtime | dict[str, Any]:
        """
        Creates a custom notebook runtime to expand the capabilities and
        resources of the runtimes provided by Esri, use this operation to
        register the custom runtime with the site. Notebook runtimes use
        Docker images.

        See `Extend <https://developers.arcgis.com/rest/enterprise-administration/notebook/register-runtime/>`_ a notebook runtime.

        :return: Runtime | dict[str,Any]
        """

        url = self._url + "/register"
        params: dict = configuration._multipart_form_format(add_f=True)

        manifest_file: str | None = params.pop("manifestFile", (None, None))[1]
        self._refresh()
        if manifest_file and os.path.isfile(manifest_file):
            with open(manifest_file) as reader:
                params["manifestFile"] = reader  # Specify the file you want to upload

                resp: requests.Response = self.session.post(url=url, files=params)
                resp.raise_for_status()
                data: dict[str, Any] = resp.json()
                if "notebookRuntime" in data:
                    runtime_url: str = f'{self._url}/{data["notebookRuntime"]["id"]}'
                    return Runtime(url=runtime_url, gis=self._gis)
                return data
        elif manifest_file and os.path.isfile(manifest_file) is False:
            raise ValueError("The `manifest_file` does not exist.")
        else:
            resp: requests.Response = self.session.post(url=url, files=params)
            resp.raise_for_status()
            data: dict[str, Any] = resp.json()
            if "notebookRuntime" in data:
                runtime_url: str = f'{self._url}/{data["notebookRuntime"]["id"]}'
                return Runtime(url=runtime_url, gis=self._gis)
            return data

    # ---------------------------------------------------------------------
    def _refresh(self):
        self._properties = None


########################################################################
class NotebookManager(object):
    """
    Provides access to managing a site's notebooks. An object of this
    class can be created using :attr:`~arcgis.gis.nb.NotebookServer.notebooks` property of the
    :class:`~arcgis.gis.nb.NotebookServer` class
    """

    _url = None
    _gis = None
    _properties = None
    _nbs = None
    _snapshot = None

    # ----------------------------------------------------------------------
    def __init__(self, url, gis, nbs):
        """Constructor"""
        self._url = url
        self._nbs = nbs
        if isinstance(gis, GIS):
            self._gis = gis
            self._con = self._gis._con
        else:
            raise ValueError("Invalid GIS object")

    # ----------------------------------------------------------------------
    def _init(self):
        """loads the properties"""
        try:
            params = {"f": "json"}
            res = self._gis._con.get(self._url, params)
            self._properties = PropertyMap(res)
        except:
            self._properties = PropertyMap({})

    # ----------------------------------------------------------------------
    def __str__(self):
        return "< NotebookManager @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    def __repr__(self):
        return "< NotebookManager @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    @property
    def properties(self):
        """returns the properties of the resource"""
        if self._properties is None:
            self._init()
        return self._properties

    # ----------------------------------------------------------------------
    def list(self):
        """
        Returns a list of notebook instances on the Notebook Server

        :return: List of :class:`~arcgis.gis.nb.Notebook` objects

        """
        return [
            Notebook(url=self._url, item_id=nbs["id"], properties=nbs)
            for nbs in self.properties.notebooks
        ]

    # ----------------------------------------------------------------------
    @property
    @_common_deprecated.deprecated(
        deprecated_in="2.4.2",
        removed_in="2.4.5",
        current_version=None,
        details="Use the `runtime_manager` instead.",
    )
    def runtimes(self) -> Iterable[Runtime]:
        """
        Returns a list of all runtimes

        :return: Iterable[Runtime]

        **This is deprecated at version 2.4.3 use the `runtime_manager` endpoint.**

        """
        url = self._url + "/runtimes"
        params = {"f": "json"}
        res = self._con.get(url, params)
        if "runtimes" in res:
            for r in res["runtimes"]:
                yield Runtime(url=url + "/{rid}".format(rid=r["id"]), gis=self._gis)

    # ----------------------------------------------------------------------
    @property
    def runtime_manager(self) -> RuntimeManager:
        """
        Returns the manager to manage runtimes

        :return: RuntimeManager
        """
        url = self._url + "/runtimes"
        return RuntimeManager(url=url, gis=self._gis)

    # ----------------------------------------------------------------------
    @property
    def snapshots(self):
        """
        Provides access to managing Notebook's snapshots

        :return: :class:`~arcgis.gis.nb.SnapshotManager`
        """
        if self._snapshot is None:
            from ._snapshot import SnapshotManager

            url = self._url + "/snapshots"
            self._snapshot = SnapshotManager(url=url, gis=self._gis)
        return self._snapshot

    # ----------------------------------------------------------------------
    @_common_deprecated.deprecated(
        deprecated_in="2.4.2",
        removed_in="2.4.5",
        current_version=None,
        details="Use the `runtime_manager` instead.",
    )
    def restore_runtime(self):
        """
        This operation restores the two default notebook runtimes in ArcGIS
        Notebook Server - ArcGIS Notebook Python 3 Standard and ArcGIS
        Notebook Python 3 Advanced - to their original settings.

        **This is deprecated at version 2.4.3 use the `runtime_manager` endpoint.**
        """
        url = self._url + "/runtimes/restore"
        params = {"f": "json"}
        res = self._con.post(url, params)
        if "status" in res:
            return res["status"] == "success"
        return res

    # ----------------------------------------------------------------------
    @staticmethod
    def _future_job(
        fn,
        task_name,
        jobid=None,
        task_url=None,
        notify=False,
        gis=None,
        **kwargs,
    ) -> "Job" | "NotebookJob":
        """
        runs the job asynchronously

        :return: Job object
        """
        from arcgis._impl._async.jobs import Job, NotebookJob

        tp = concurrent.futures.ThreadPoolExecutor(1)
        try:
            future = tp.submit(fn=fn, **kwargs)
        except:
            future = tp.submit(fn, **kwargs)
        tp.shutdown(False)
        if gis._is_arcgisonline:
            return Job(future, task_name, jobid, task_url, notify, gis=gis)
        else:
            return NotebookJob(
                future=future,
                task_name=task_name,
                jobid=jobid,
                task_url=task_url,
                notify=notify,
                gis=gis,
            )

    # ----------------------------------------------------------------------
    def execute_notebook(
        self,
        item: Item,
        update_portal_item: bool = True,
        parameters: Optional[list] = None,
        save_parameters: bool = False,
        future: bool = False,
    ):
        """

        The Execute Notebook operation allows administrators and users with
        the `Create and Edit Notebooks` privilege to remotely
        run a notebook that they own.  The notebook specified in the operation will
        be run with all cells in order.

        Using this operation, you can schedule the execution of a notebook,
        either once or with a regular occurrence. This allows you to
        automate repeating tasks such as data collection and cleaning,
        content updates, and portal administration. On Linux machines, use
        a cron job to schedule the executeNotebook operation; on Windows
        machines, you can use the Task Scheduler.

        .. note::
            To run this operation in ArcGIS Enterprise, you must log in with
            an Enterprise account. You cannot execute notebooks using the
            ArcGIS Notebook Server primary site administrator account.

        You can specify parameters to be used in the notebook at execution
        time. If you've specified one or more parameters, they'll be
        inserted into the notebook as a new cell. This cell will be placed
        at the beginning of the notebook, unless you have added the
        *parameters* tag to a cell.

        See `Execute Notebook <https://developers.arcgis.com/rest/enterprise-administration/notebook/execute-notebook/>`_
        for full administration details.

        ====================    ====================================================================
        **Parameter**            **Description**
        --------------------    --------------------------------------------------------------------
        item                    Required notebook :class:`~arcgis.gis.Item`. Opens the existing portal
                                notebook.
        --------------------    --------------------------------------------------------------------
        update_portal_item      Optional Boolean. Specifies whether you want to update the
                                notebook's portal item after execution. The default is *True*. You may
                                want to specify true when the notebook you're executing contains
                                information that needs to be updated, such as a workflow that
                                collects the most recent version of a dataset. It may not be
                                important to update the portal item if the notebook won't store any
                                new information after executing, such as an administrative notebook
                                that emails reminders to inactive users.
        --------------------    --------------------------------------------------------------------
        parameters              Optional Dictionary. Defines the parameters to add to the
                                notebook for this execution. The parameters will be inserted as a
                                new cell directly after the cell you have tagged *parameters*.
                                Separate parameters with a comma. Use formats:

                                * "x":1 when defining number parameters
                                * "y":"text" when defining string parameters

                                See `Prepare the Notebook <https://enterprise.arcgis.com/en/notebook/latest/use/windows/prepare-a-notebook-for-automated-execution.htm#GUID-74ECC731-D8D3-4E63-A22C-38027407A209>`_
                                for detailed explanation.
        --------------------    --------------------------------------------------------------------
        save_parameters         Optional Boolean.  Specifies whether the notebook parameters cell
                                should be saved in the notebook for future use. The default is
                                *False*.
        --------------------    --------------------------------------------------------------------
        future                  Optional boolean.

                                * If *True*, a *future* object will be returned and the process runs
                                  asynchronously, allowing for other work to be done while
                                  processing completes.
                                * If *False*, which is the default, the process waits for results
                                  before continuing.
        ====================    ====================================================================

        :return:

            * If *future=False*, a Python dictionary
            * If *future = True*, then the result is a
              `concurrent.futures.Future <https://docs.python.org/3/library/concurrent.futures.html>`_
              object. Call *result()* on the object to get the response

        .. code-block:: python

            # Usage Example:

            >>> from arcgis.gis import GIS
            >>> gis = GIS("home")
            >>> nb_server = gis.notebook_server[0]

            >>> notebook_item = gis.content.get('<notebook_item_id>')

            >>> nb_mgr = nb_server.notebooks
            >>> nb_mgr.execute_notebook(notebook_item)

        """
        from arcgis.gis import Item

        url = self._url + "/executeNotebook"
        itemid = None
        if isinstance(item, str):
            itemid = item
        elif isinstance(item, Item):
            itemid = item.itemid
        params = {
            "f": "json",
            "itemId": itemid,
            "updatePortalItem": update_portal_item,
            "saveInjectedParameters": save_parameters,
        }
        if parameters:
            params["notebookParameters"] = parameters
        if future:

            def _fn(start_job, nbs):
                resp = self._gis._con.get(start_job["jobUrl"], {"f": "json"})
                if "status" in resp and resp["status"].lower() != "success":
                    status = self._gis._con.get(start_job["jobUrl"], {"f": "json"})
                    i = 0
                    while status["status"].lower() != "completed":
                        time.sleep(0.3 * i)
                        if status["status"].lower() in [
                            "failed",
                            "failing",
                            "cancelled",
                            "cancelling",
                            "cancel",
                        ]:
                            return status
                        elif status["status"].lower().find("cancel") > -1:
                            return status
                        elif (
                            status["status"].lower().find("fail") > -1
                            or status["status"].lower().find("error") > -1
                        ):
                            raise Exception(f"Job Fail {status}")
                        status = self._gis._con.get(start_job["jobUrl"], {"f": "json"})
                        i += 1
                        if i > 20:
                            i = 20
                    return status
                return resp

            start_job = self._gis._con.post(url, params)
            if "jobUrl" in start_job:
                return NotebookManager._future_job(
                    fn=_fn,
                    task_name="Execute Notebook",
                    task_url=start_job["jobUrl"],
                    jobid=start_job.get("jobId", None),
                    gis=self._gis,
                    **{"start_job": start_job, "nbs": self._nbs},
                )
            else:
                return start_job

        res = self._gis._con.post(url, params)
        return res

    # ----------------------------------------------------------------------
    def open_notebook(
        self,
        itemid: str,
        templateid: Optional[str] = None,
        nb_runtimeid: Optional[str] = None,
        template_nb: Optional[str] = None,
        *,
        future: bool = False,
    ):
        """

        Opens a notebook on the notebook server

        ==================      ====================================================================
        **Parameter**            **Description**
        ------------------      --------------------------------------------------------------------
        itemid                  Required String. Opens an existing portal item.
        ------------------      --------------------------------------------------------------------
        templateid              Optional String. The id of the portal notebook template. To get the
                                system templates, look at the sample notebooks group:

                                .. code-block:: python

                                    >>> from arcgis.gis import GIS
                                    >>> gis = GIS()
                                    >>> grp = gis.groups.search("title:(esri sample notebooks) AND
                                    >>>                                 owner:\"esri_notebook\")[0]
                                    >>> grp.content
        ------------------      --------------------------------------------------------------------
        nb_runtimeid            Optional String. The runtime to use to generate a new notebook.
        ------------------      --------------------------------------------------------------------
        template_nb             Optional String. The start up template for the notebook.
        ------------------      --------------------------------------------------------------------
        future                  Optional Bool. If True, the job will run asynchronously.
        ==================      ====================================================================

        :return: Dict or Job

        """

        def _fn(url, params, nbs):
            """used to fire off async job"""
            import time

            start_job = self._gis._con.post(url, params)
            status_url = start_job.get("jobUrl", None) or start_job.get(
                "notebookStatusUrl", None
            )
            if status_url:
                resp = self._gis._con.get(status_url, {"f": "json"})
            else:
                return start_job
            if "status" in resp and resp["status"].lower() != "success":
                status = self._gis._con.get(status_url, {"f": "json"})
                i = 0
                while status["status"].lower() != "completed":
                    time.sleep(0.3 * i)
                    if status["status"].lower() == "failed":
                        return status
                    elif (
                        status["status"].lower().find("fail") > -1
                        or status["status"].lower().find("error") > -1
                    ):
                        raise Exception(f"Job Fail {status}")
                    status = self._gis._con.get(status_url, {"f": "json"})
                    i += 1
                    if i > 20:
                        i = 20
                return status

        params = {
            "itemId": itemid,
            "templateId": templateid,
            "notebookRuntimeId": nb_runtimeid,
            "templateNotebook": template_nb,
            "async": True,
            "f": "json",
        }
        url = self._url + "/openNotebook"
        if future:
            return NotebookManager._future_job(
                fn=_fn,
                task_name="Open Notebook",
                gis=self._gis,
                **{"url": url, "params": params, "nbs": self._nbs},
            )
        else:
            res = self._con.post(url, params)
            status_url = res.get("jobUrl", None) or res.get("notebookStatusUrl", None)
            if status_url:
                job_url = status_url
                params = {"f": "json"}
                job_res = self._con.get(job_url, params)
                while job_res["status"] != "COMPLETED":
                    job_res = self._con.get(job_url, params)
                    if job_res["status"].lower().find("fail") > -1:
                        return job_res
                return job_res
            return res


########################################################################
class Runtime(object):
    """
    Provides information about the properties of a specific notebook runtime in your ArcGIS Notebook Server site
    """

    _url = None
    _gis = None
    _properties = None

    # ----------------------------------------------------------------------
    def __init__(self, url, gis):
        """Constructor"""
        self._url = url
        if isinstance(gis, GIS):
            self._gis = gis
            self._con = self._gis._con
        else:
            raise ValueError("Invalid GIS object")

    # ----------------------------------------------------------------------
    def _init(self):
        """loads the properties"""
        try:
            params = {"f": "json"}
            res = self._gis._con.get(self._url, params)
            self._properties = PropertyMap(res)
        except:
            self._properties = PropertyMap({})

    # ----------------------------------------------------------------------
    def __str__(self):
        return "< Runtime @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    def __repr__(self):
        return "< Runtime @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    @property
    def properties(self):
        """returns the properties of the resource"""
        if self._properties is None:
            self._init()
        return self._properties

    # ----------------------------------------------------------------------
    def delete(self):
        """
        Deletes the current runtime from the ArcGIS Notebook Server

        :return: Boolean

        """
        url = self._url + "/unregister"
        params = {"f": "json"}
        res = self._con.post(url, params)
        if "status" in res:
            return res["status"] == "success"
        return res

    # ----------------------------------------------------------------------
    def update(
        self,
        name: Optional[str] = None,
        image_id: Optional[str] = None,
        max_cpu: Optional[float] = None,
        max_memory: Optional[float] = None,
        memory_unit: Optional[str] = None,
        max_swap_memory: Optional[str] = None,
        swap_memory_unit: Optional[str] = None,
        shared_memory: Optional[str] = None,
        docker_runtime: Optional[str] = None,
        shared_unit: Optional[str] = None,
        version: Optional[str] = None,
        container_type: Optional[str] = None,
        pull_string: Optional[str] = None,
        require_advanced_priv: Optional[bool] = None,
        manifest: Optional[str] = None,
    ):
        """
        This operation allows you to update the properties of a notebook
        runtime in ArcGIS Notebook Server. These settings will be applied
        to every container to which the runtime is applied.

        You can use this operation to update the resource limits of the
        runtime, such as maximum CPU and maximum memory. You can also use
        it to extend either of the default notebook runtimes, in order to
        make additional Python modules available to your notebook authors,
        or as a step in making ArcGIS Notebook Server able to use graphical
        processing units (GPUs).



        """
        url = self._url + "/update"
        if manifest is None:
            manifest = ""
        if manifest:
            file = {"manifestFile": manifest}
        else:
            file = None

        params = {
            "name": name,
            "version": version,
            "imageId": image_id,
            "containerType": container_type,
            "imagePullString": pull_string,
            "requiresAdvancedPrivileges": require_advanced_priv,
            "maxCpu": max_cpu or float(self.properties.maxCpu),
            "maxMemory": max_memory or float(self.properties.maxMemory),
            "maxMemoryUnit": memory_unit or "g",
            "maxSwapMemory": max_swap_memory or "",
            "maxSwapMemoryUnit": swap_memory_unit or "g",
            "sharedMemory": shared_memory or "",
            "sharedMemoryUnit": shared_unit or "m",
            "dockerRuntime": docker_runtime,
            "f": "json",
        }
        import json

        for k in list(params.keys()):
            if params[k] is None and k in self.properties:
                params[k] = self.properties[k]
            elif params[k] is None:
                params[k] = ""
            if isinstance(params[k], bool):
                params[k] = json.dumps(params[k])
            elif isinstance(params[k], (int, float)):
                params[k] = json.dumps(float(params[k]))

        if len(params) == 1:
            return False
        res = self._con.post_multipart(url, params, files=file)

        if "status" in res:
            return res["status"] == "success"
        return res

    # ----------------------------------------------------------------------
    @property
    def manifest(self):
        """
        This resource returns a JSON representation of all the Python
        libraries supported in the specified notebook runtime. Notebook
        authors who open notebooks using this runtime are able to import
        any of the libraries in the manifest into their notebooks.

        :return: List of Dictionaries

        """
        url = self._url + "/manifest"
        params = {"f": "json"}
        res = self._con.get(url, params)
        if "libraries" in res:
            return res["libraries"]
        return res


###########################################################################
class Notebook(object):
    """
    This represents an individual notebook resource in the notebook server.
    """

    _url = None
    _item_id = None
    _properties = None
    _gis = None

    # ----------------------------------------------------------------------
    def __init__(self, url, item_id, properties=None, gis=None):
        self._url = url + "/%s" % item_id
        self._item_id = item_id
        if properties:
            self._properties = properties
        if gis is None:
            from arcgis.env import active_gis

            gis = active_gis
        self._gis = gis

    # ----------------------------------------------------------------------
    def _init(self):
        """loads the properties"""
        try:
            params = {"f": "json"}
            res = self._gis._con.get(self._url, params)
            self._properties = PropertyMap(res)
        except:
            self._properties = PropertyMap({})

    # ----------------------------------------------------------------------
    def __str__(self):
        return "< Notebook @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    def __repr__(self):
        return "< Notebook @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    @property
    def properties(self):
        """returns the properties of the resource"""
        if self._properties is None:
            self._init()
        return self._properties

    # ----------------------------------------------------------------------
    def close(self):
        """
        This operation stops a running notebook. You can use it to free up
        space in your notebook container. Idle notebooks are automatically
        cleaned up according to the duration defined by the
        idleNotebookThreshold property. The default value for that property
        is 24 hours.

        :return: Boolean

        """
        params = {"f": "json"}
        url = self._url + "/closeNotebook"
        res = self._gis._con.post(url, params)
        if "status" in res:
            return res["status"] == "success"
        return res
