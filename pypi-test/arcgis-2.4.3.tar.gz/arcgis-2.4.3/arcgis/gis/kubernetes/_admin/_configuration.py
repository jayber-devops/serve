from __future__ import annotations

import requests

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, ConfigDict

from arcgis.auth import EsriSession

__all__ = [
    "SiteConfiguration",
    "configure_enterprise",
    "ConfigurationJob",
    "LogSetting",
    "Availability",
]


###########################################################################
class ConfigurationJob:
    """
    An object to query for status and results from the configuration job. Objects
    of this class are not initialized directly, but instead are returned by the
    :func:`~arcgis.gis.kubernetes._admin._configuration.configure_enterprise`
    operation.

    """

    session: EsriSession | requests.Session
    url: str
    data: dict

    def __init__(self, url: str, session: EsriSession | requests.Session, data: dict):
        self.data = data
        self.url = url
        self.session = session

    def _refresh_status(self) -> dict[str, Any]:
        resp: requests.Response = self.session.get(
            url=self.url,
            params={
                "f": "json",
            },
        )
        resp.raise_for_status()
        self.data = resp.json()
        return self.data

    @property
    def properties(self) -> dict[str, Any]:
        return self._refresh_status()

    @property
    def message(self) -> str | None:
        """returns the status message"""
        self._refresh_status()
        if "status" in self.data and "message" in self.data["status"]:
            return self.data.get("status", {}).get("message", None)
        return None

    @property
    def status(self) -> str:
        """Returns the `status` of the installation"""
        self._refresh_status()
        if "status" in self.data and "state" in self.data["status"]:
            return self.data.get("status", {}).get("state", None)
        return None

    @property
    def stages(self) -> list[dict[str, Any]]:
        """
        Returns the installation update messages to the administrator.
        """
        self._refresh_status()
        if "status" in self.data and "stages" in self.data["status"]:
            return self.data.get("status", {}).get("stages", None)
        return None


###########################################################################
class LogSetting(Enum):
    """
    Specifies the level that can be used to override some log settings for
    your organization. Currently, you can update the level at which logs
    will be recorded during configuration. The default log level is VERBOSE
    during configuration. Once the organization is configured, the log
    level will switch to WARNING. The log level can be changed after
    configuration using the Edit operation.
    """

    SEVERE = "SEVERE"
    WARNING = "WARNING"
    INFO = "INFO"
    FINE = "FINE"
    VERBOSE = "VERBOSE"
    DEBUG = "DEBUG"


###########################################################################
class Availability(Enum):
    """
    The architecture profile set for the organization.
    """

    DEVELOPMENT = "development"
    STANDARD = "standard-availability"
    ENHANCED = "enhanced-availability"


###########################################################################
class SiteConfiguration(BaseModel):
    """
    This is the initial site configuration for ArcGIS Enterprise on
    Kubernetes.
    """

    model_config = ConfigDict(
        extra="allow",
        use_enum_values=True,
        arbitrary_types_allowed=True,
    )

    username: str = Field(
        ...,
        alias="username",
        description="""The initial administrator account username. Valid usernames must be at least six characters in length,
                       using alphanumeric values with only the following symbols allowed:
                       
                       * *@*
                       * *_* (underscore)
                       * *,*
                       * *-* (hyphen)
                    """,
    )
    password: str = Field(
        ...,
        alias="password",
        description="The password for the initial administrator account. Valid passwords must be at least eight characters in length and contain at least one letter (A-Z, a-z) and one number (0-9). All special characters are supported.",
    )
    email: str = Field(
        ...,
        alias="email",
        description="The email address associated with the initial administrator account.",
    )
    first_name: str = Field(
        ...,
        alias="firstName",
        description="The first name of the user being designated as the initial administrator.",
    )
    last_name: str = Field(
        ...,
        alias="lastName",
        description="The last name of the user being designated as the initial administrator.",
    )
    security_question: int = Field(
        ...,
        ge=1,
        le=14,
        alias="securityQuestionIdx",
        description="The index of the secret question used to retrieve a forgotten password.",
    )
    security_answer: str = Field(
        ...,
        description="The answer to the secret question specified in the security_question.",
        alias="securityQuestionAns",
    )
    user_license_type: str = Field(
        "creatorUT",
        alias="userLicenseTypeId",
        description="The user type for the initial administrator account. The values listed below are the user types that are compatible with the Administrator role. ",
    )
    license_file: str = Field(
        ...,
        alias="licenseField",
        description="The ArcGIS Enterprise on Kubernetes license file (.json). This license file, which contains information regarding your user types, apps, and capabilities, is obtained from My Esri.",
    )
    volumes_config: dict[str, Any] = Field(
        ...,
        alias="volumesConfig",
        description="""A dictionary containing the default storage configurations for the eight persistent volumes that are required for the deployment. By default, the storage provisioning type for each persistent volume is DYNAMIC,
                       though it can be manually changed to STATIC to support static provisioning types. See `volumesConfig <https://developers.arcgis.com/rest/enterprise-administration/enterprise/configure/#request-parameters>`_
                       in the REST endpoint documentation for complete description of key-value options.
                    """,
    )
    log_setting: LogSetting = Field(
        LogSetting.VERBOSE,
        alias="logSettings",
        description="Specifies the level that can be used to override some log settings for your organization. ",
    )
    availability: Availability = Field(
        Availability.STANDARD,
        alias="systemArchitectureProfile",
        description="The architecture profile set for the organization. Architecture profiles are predefined deployment profiles that correlate to varying levels of redundancy across pods.",
    )
    user_managed_stores: list[dict[str, Any]] | None = Field(
        None,
        alias="userManagedStores",
        description="""Introduced at 10.9.1. A list of dictionaries that provides information to register the root folder paths for data stores.
                       See `user-managed store properties <https://developers.arcgis.com/rest/enterprise-administration/enterprise/register-data-store-item/#user-managed-store-properties>`_,
                       for full details on key-value options.
                    """,
    )
    system_properties: dict[str, Any] | None = Field(
        None,
        alias="systemProperties",
        description="A dictionary that can be used to set up the system properties for the organization before it is configured.",
    )
    cloud_config: list[dict[str, Any]] | None = Field(
        None,
        alias="cloudConfig",
        description="""A list of dictionaries containing the deployment's cloud storage configuration for cloud-native object stores and
                       cloud-native relational data stores (added at ArcGIS Enterprise 11.4 on Kubernetes). See
                       `Cloud configuration details <https://developers.arcgis.com/rest/enterprise-administration/enterprise/configure/#cloud-configuration-properties>`_
                       for full details of key-value options.
                    """,
    )
    description: str | None = Field(
        None, alias="description", description="A description of the account."
    )


# -------------------------------------------------------------------------
def configure_enterprise(
    url: str, session: EsriSession | requests.Session, configuration: SiteConfiguration
) -> ConfigurationJob:
    """
    The configure operation is the first operation that must be invoked
    when ArcGIS Enterprise on Kubernetes is installed for the first time. During
    configuration, a number of tasks are performed, including the following:

         - EsriDocker images are downloaded for ArcGIS Enterprise on Kubernetes.
         - ArcGIS Enterprise containers are deployed to your Kubernetes cluster.
         - An organization is created.

    Due to the number of tasks and processes performed during organization
    creation, the configure operation can be time consuming. Once the
    organization is created, you can publish GIS services and begin
    administering and configuring your organization.

    ======================     =================================================
    **Parameter**              **Description**
    ----------------------     -------------------------------------------------
    url                        Required string. The url for the home page of the
                               deployment.
    ----------------------     -------------------------------------------------
    session                    Required :class:`~arcgis.auth.EsriSession` or
                               *requests.Session* object.
    ----------------------     -------------------------------------------------
    configuration              Required
                               :class:`~arcgis.gis.kubernetes._admin._configuration.SiteConfiguration`
                               object.
    ======================     =================================================

    :returns:
        A :class:`~arcgis.gis.kubernetes._admin._configuration.ConfigurationJob` object.

    .. code-block:: python

        # Usage Example: Configure a new ArcGIS on Kubernetes deployment

        >>> from arcgis.auth import EsriSession
        >>> from arcgis.gis.kubernetes import (
        >>>            SiteConfiguration,
        >>>            Availability,
        >>>            LogSetting,
        >>>            configure_enterprise
        >>> )

        >>> url = "https://www.kubernetes-setup-site.com/arcgis"
        >>> session = EsriSession()

        >>> kube_config = SiteConfiguration(
        >>>    availability= Availability.STANDARD,
        >>>    description="New Arcgis Enterprise on Kubernetes configuration.",
        >>>    email="kube_admin@example.com",
        >>>    first_name="Kubernetes",
        >>>    last_name="Administrator",
        >>>    license_file="/path/to/file",
        >>>    log_setting= LogSetting.DEBUG,
        >>>    username="Admin_Username",
        >>>    password="secure_password",
        >>>    security_question=1,
        >>>    security_answer="Hometown",
        >>>    user_license_type="creatorUT",
        >>>    user_managed_stores={
        >>>            "clientPath":"\\\\path\\to\\data",
        >>>            ....
        >>>    },
        >>>    volumes_config={
        >>>            "volumesConfig" : [{
        >>>                  "provisioningType": "DYNAMIC
        >>>             },
        >>>            ...
        >>>            ]
        >>>    }
        >>> )

        >>> config_job = configure_enterprise(
        >>>                     url=url,
        >>>                     session=session,
        >>>                     configuration=kube_config
        >>>              )

    """
    params: dict = {"f": "json"}
    md: dict = configuration.model_dump(by_alias=True)
    params.update(md)
    resp: requests.Response = session.post(url=url, data=params)
    resp.raise_for_status()
    data: dict = resp.json()
    if "error" in data:
        raise Exception(f"The following error occurred: {data}")
    return ConfigurationJob(url=url, session=session, data=data)
