from __future__ import annotations

import time
import concurrent.futures
from arcgis.gis import GIS
from typing import Any, TypeVar

__all__ = ["Container", "ContainerManager"]


K = TypeVar("K")
V = TypeVar("V")


class Container:
    """
    Represents a Single Notebook Container

    ================  ===============================================================================
    **Parameter**      **Description**
    ----------------  -------------------------------------------------------------------------------
    url               Required String. The url for the container.
    ----------------  -------------------------------------------------------------------------------
    gis               Required GIS. The ArcGIS Online connection object.
    ================  ===============================================================================


    """

    _properties = None

    def __init__(self, url: str, gis: GIS):
        """initializer"""
        self._url = url
        self._gis = gis

    @property
    def properties(self):
        if self._properties is None:
            url = f"{self._url}"
            params = {"f": "json"}
            self._properties = self._gis._con.get(url, params)
        return self._properties

    def shutdown(self) -> bool:
        """stops the current container"""
        url = f"{self._url}/terminateContainer"
        params = {"f": "json"}
        return self._gis._con.post(url, params)

    @property
    def notebooks(self) -> list[dict[str, Any]]:
        """returns a list of notebooks running in the current container"""
        url = f"{self._url}/notebooks"
        params = {"f": "json"}
        return self._gis._con.get(url, params)

    def close(self, notebook_id: str) -> bool:
        """closes a notebook"""
        url = f"{self._url}/notebooks/{notebook_id}/closeNotebook"
        params = {"f": "json"}
        return self._gis._con.post(url, params)


class ContainerManager:
    """
    ================  ===============================================================================
    **Parameter**      **Description**
    ----------------  -------------------------------------------------------------------------------
    url               Required String. The base url for the ContainerManager endpoints.
    ----------------  -------------------------------------------------------------------------------
    gis               Required :class:`~arcgis.gis.GIS`. The ArcGIS Online connection object.
    ================  ===============================================================================

    """

    def __init__(self, url: str, gis: GIS):
        self._url = url
        self._gis = gis
        self._con = gis._portal.con

    def list(self) -> list[dict[str, Any]]:
        """Returns a list of containers"""
        url = f"{self._url}"
        params = {"f": "json"}
        return self._gis._con.get(url, params)

    def get(self, id: str) -> Container:
        """Gets an instance of a container"""
        return Container(url=f"{self._url}/{id}", gis=self._gis)

    def start(
        self, runtime: str, instance_type: str | None = None
    ) -> concurrent.futures.Future:
        """starts a container"""
        url = f"{self._url}/startContainer"
        params = {
            "f": "json",
            "notebookRuntimeId": runtime,
        }
        if instance_type:
            params["instanceTypeName"] = instance_type

        res = self._con.post(path=url, postdata=params)
        executor = concurrent.futures.ThreadPoolExecutor(1)
        future = executor.submit(self._check_job_status, res)
        executor.shutdown(False)
        return future

    def _check_job_status(self, res):
        """checks the container start status"""
        n = 1
        if "startContainerStatusUrl" in res:
            time.sleep(0.5)
            surl = res["startContainerStatusUrl"]
            sres = self._con.get(path=surl, params={"f": "json"})
            while sres["status"].lower() != "completed":
                sres = self._con.get(path=surl, params={"f": "json"})
                if sres["status"].lower() in "failed":
                    return False
                if n >= 40:
                    n = 40
                time.sleep(0.5 * n)
                n += 1
            else:
                return True
        return res
