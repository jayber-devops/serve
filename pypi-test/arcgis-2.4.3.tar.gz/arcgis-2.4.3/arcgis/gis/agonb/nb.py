from __future__ import annotations
from arcgis.gis import GIS
from .containers import ContainerManager
from .instpref import InstancePreference
from .runtime import RuntimeManager
from .snapshot import SnapshotManager
from .notebook import NotebookManager
from typing import TypeVar
from arcgis.auth.tools import LazyLoader

_common_deprecated = LazyLoader("arcgis._impl.common._deprecate")
__all__ = ["AGOLNotebookManager"]

K = TypeVar("K")
V = TypeVar("V")


class AGOLNotebookManager:
    _container = None
    _istpref = None
    _runtimes = None
    _snapshot = None
    _nbm = None
    _services = None
    _da = None

    def __init__(self, url: str, gis: GIS):
        self._url = url
        self._gis = gis

    @property
    def containers(self) -> ContainerManager:
        """
        Provides the ability to manage containers and the notebooks within them

        :returns: :class:`~arcgis.gis.agonb.ContainerManager`
        """
        if self._container is None:
            self._container = ContainerManager(
                url=f"{self._url}/system/containers", gis=self._gis
            )
        return self._container

    @property
    def services(self):
        """returns the service manager."""
        if self._services is None:
            from arcgis.gis.nb._services import NBServicesManager

            url = self._url + "/services"
            self._services = NBServicesManager(url, self._gis, nbs=self)
        return self._services

    @property
    def instance_preferences(self) -> InstancePreference:
        """
        Provides information about the available instances for notebooks

        :returns: :class:`~arcgis.gis.agonb.InstancePreference`
        """
        if self._istpref is None:
            url = f"{self._url}/notebooks/instancePreferences"
            self._istpref = InstancePreference(url=url, gis=self._gis)
        return self._istpref

    @property
    def _machines(self) -> dict[K, V]:
        """
        Returns information about the machines running on notebook server
        :returns: Dict
        """
        url = f"{self._url}/machines"
        params = {"f": "json"}
        return self._gis._con.get(url, params)

    @property
    @_common_deprecated.deprecated(
        deprecated_in="2.4.2",
        removed_in="2.4.5",
        current_version=None,
        details="Use the `runtime_manager` instead.",
    )
    def runtimes(self) -> RuntimeManager:
        return self.runtime_manager

    @property
    def runtime_manager(self) -> RuntimeManager:
        """
        Provides information about the available runtimes on the notebook server

        :returns: :class:`~arcgis.gis.agonb.RuntimeManager`
        """
        if self._runtimes is None:
            url = f"{self._url}/notebooks/runtimes"
            self._runtimes = RuntimeManager(url=url, gis=self._gis)
        return self._runtimes

    @property
    def snapshots(self) -> SnapshotManager:
        """
        Returns tools to work with snapshots on notebooks

        :returns: :class:`~arcgis.gis.agonb.SnapshotManager`
        """
        if self._snapshot is None:
            url = f"{self._url}/notebooks/snapshots"
            self._snapshot = SnapshotManager(url=url, gis=self._gis)
        return self._snapshot

    @property
    def notebooksmanager(self) -> NotebookManager:
        """
        Manages the run and execution of notebooks

        :returns: :class:`~arcgis.gis.agonb.NotebookManager`
        """
        if self._nbm is None:
            url = f"{self._url}/notebooks"
            self._nbm = NotebookManager(url=url, gis=self._gis, nbs=self)
        return self._nbm

    # ----------------------------------------------------------------------
    @property
    def data_access(self) -> "NotebookDataAccess":
        """Provides access to managing files stored on notebook server.

        :return:
            :class:`~arcgis.gis.nb._dataaccess.NotebookDataAccess` object

        """
        if self._da is None:
            from arcgis.gis.nb._dataaccess import NotebookDataAccess

            user = self._gis.users.me
            url = user.generate_direct_access_url("notebook")["url"]
            # remove the /notebookWorkspace part and replace with the username
            url = url.replace("/notebooksWorkspace", "")
            self._da = NotebookDataAccess(url, self._gis)
        return self._da
