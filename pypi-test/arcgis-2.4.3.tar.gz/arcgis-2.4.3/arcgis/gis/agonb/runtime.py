from __future__ import annotations
from arcgis.gis import GIS
from arcgis.auth import EsriSession
from typing import TypeVar, Any
import requests
from arcgis.auth.tools import LazyLoader

_common_deprecated = LazyLoader("arcgis._impl.common._deprecate")
T = TypeVar("T")
V = TypeVar("V")

__all__ = ["AGORuntime", "RuntimeManager"]


########################################################################
class AGORuntime:
    """
    Provides information about the properties of a specific notebook
    runtime in your ArcGIS Online Notebook.
    """

    _url = None
    _gis = None
    _properties = None
    _session: EsriSession | None = None

    # ----------------------------------------------------------------------
    def __init__(self, url: str, gis: GIS, properties: dict):
        """Constructor"""
        self._url = url
        self._properties = properties
        if isinstance(gis, GIS):
            self._gis = gis
            self._con = self._gis._con
        else:
            raise ValueError("Invalid GIS object")

    # ----------------------------------------------------------------------
    @property
    def session(self) -> EsriSession:
        """returns the session object"""
        if self._session is None:
            self._session = self._gis.session
        return self._session

    # ----------------------------------------------------------------------
    def _init(self):
        """loads the properties"""
        try:
            params = {"f": "json"}
            resp: requests.Response = self.session.get(self._url, params=params)
            resp.raise_for_status()
            res: dict = resp.json()
            self._properties = res
        except Exception as ex:
            raise Exception(str(ex))

    # ----------------------------------------------------------------------
    def __str__(self):
        return "< AGORuntime @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    def __repr__(self):
        return "< AGORuntime @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    @property
    def properties(self):
        """returns the properties of the resource"""
        if self._properties is None:
            self._init()
        return self._properties

    # ----------------------------------------------------------------------
    @property
    def manifest(self):
        """
        This resource returns a JSON representation of all the Python
        libraries supported in the specified notebook runtime. Notebook
        authors who open notebooks using this runtime are able to import
        any of the libraries in the manifest into their notebooks.

        :return: List of Dictionaries

        """
        url = self._url + "/manifest"
        params = {"f": "json"}
        resp: requests.Response = self.session.get(url, params=params)
        resp.raise_for_status()
        res: dict = resp.json()
        if "libraries" in res:
            return res["libraries"]
        return res


class RuntimeManager:
    """
    Provides information about the Runtimes in the Notebook Server

    ================  ===============================================================================
    **Parameter**      **Description**
    ----------------  -------------------------------------------------------------------------------
    url               Required String. The base url for the RuntimeManager endpoints.
    ----------------  -------------------------------------------------------------------------------
    gis               Required :class:`~arcgis.gis.GIS`. The ArcGIS Online connection object.
    ================  ===============================================================================

    """

    _properties: dict[str, Any] | None = None
    _session: EsriSession | None = None

    def __init__(self, url: str, gis: GIS):
        """initializer"""
        self._url = url
        self._gis = gis
        self._session = gis.session

    # ----------------------------------------------------------------------
    @property
    def session(self) -> EsriSession:
        """returns the session object"""
        if self._session is None:
            self._session = self._gis.session
        return self._session

    # ----------------------------------------------------------------------
    def __str__(self):
        return "< AGORuntimeManager @ {url} >".format(url=self._url)

    # ----------------------------------------------------------------------
    def __repr__(self):
        return "< AGORuntimeManager @ {url} >".format(url=self._url)

    # ---------------------------------------------------------------------
    @property
    def properties(self) -> dict[str, Any]:
        """
        returns the properties of the endpoint
        :return: dict[str,Any]
        """
        if self._properties is None:
            resp: requests.Response = self.session.get(
                self._url,
                params={
                    "f": "json",
                },
            )
            resp.raise_for_status()
            self._properties = resp.json()
        return self._properties

    # ----------------------------------------------------------------------
    @property
    def current_runtime_version(self) -> str:
        """returns the current runtime version"""
        return self.properties.get("currentRuntimeVersion")

    # ----------------------------------------------------------------------
    @property
    def runtimes(self) -> Iterable[AGORuntime]:
        """
        Returns all registered runtimes for the notebook server.

        :return: Iterable[Runtime]
        """
        url: str = self._url
        params: dict[str, Any] = {"f": "json"}
        resp: requests.Response = self.session.get(url=url, params=params)
        resp.raise_for_status()
        res: dict[str, Any] = resp.json()

        for r in res.get("runtimes", []):
            yield AGORuntime(
                url=url + "/{rid}".format(rid=r["id"]), gis=self._gis, properties=r
            )

    @_common_deprecated.deprecated(
        deprecated_in="2.4.2",
        removed_in="2.4.5",
        current_version=None,
        details="Use the `RuntimeManager.runtimes` instead.",
    )
    def list(self) -> list[dict[T, V]]:
        """
        returns a list of runtimes on the system

        :returns: list[dict[T,V]]
        """
        params = {"f": "json"}
        return self._gis._con.get(self._url, params).get("runtimes", [])

    @_common_deprecated.deprecated(
        deprecated_in="2.4.2",
        removed_in="2.4.5",
        current_version=None,
        details="Use the `manifest` on the AGORuntime class instead.",
    )
    def manifest(self, id: str) -> dict[T, V]:
        """
        returns a dictionary containing all the libraries for that runtime

        :returns: dict[T,V]
        """
        url = f"{self._url}/{id}/manifest"
        params = {"f": "json"}
        return self._gis._con.get(url, params)
