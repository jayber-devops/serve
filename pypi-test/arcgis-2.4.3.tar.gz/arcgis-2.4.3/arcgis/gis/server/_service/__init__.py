"""
Classes for ArcGIS Services
"""

from __future__ import absolute_import

__version__ = "2.4.3"
__all__ = ["Service"]
