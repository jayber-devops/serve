from __future__ import annotations
import json
from typing import Any
from arcgis import env
from arcgis._impl.common._mixins import PropertyMap
from arcgis._impl.common._utils import _prepare_parameters
from arcgis.features._trace_configuration import TraceConfiguration


########################################################################
class UtilityNetworkManager(object):
    """
    The Utility Network Service exposes analytic capabilities (tracing)
    as well as validation of network topology and management of
    sub-networks (managing sources, updating sub-networks, exporting
    sub-networks, and so on). The Utility Network Service is conceptually
    similar to the Network Analysis Service for transportation networks.

    =====================   ===========================================
    **Inputs**              **Description**
    ---------------------   -------------------------------------------
    url                     Required String. The web endpoint to the utility service.
    ---------------------   -------------------------------------------
    version                 Optional :class:`~arcgis.features._version.Version`. The `Version` class where the branch version will take place.
    ---------------------   -------------------------------------------
    gis                     Optional :class:`~arcgis.gis.GIS` . The `GIS` connection object.
    =====================   ===========================================


    """

    _session = None
    _gis = None
    _url = None
    _property = None
    _version_guid = None
    _version_name = None
    _version = None

    # ----------------------------------------------------------------------
    def __init__(self, url, version=None, gis=None):
        """Constructor"""
        if gis is None:
            gis = env.active_gis
        self._gis = gis
        self._session = gis._session
        self._url = url
        if version:
            self._version = version
            self._version_name = version.properties.versionName
            if self._version_name in ["SDE.DEFAULT", "DBO.DEFAULT"]:
                # fix due to locking issue
                self._version_guid = None
            else:
                self._version_guid = version._guid
        else:
            self._version = None
            self._version_guid = None
            self._version_name = None

    # ----------------------------------------------------------------------
    def _init(self):
        """initializer"""
        try:
            res = self._session.get(url=self._url, params={"f": "json"}).json()
            self._property = PropertyMap(res)
        except Exception as e:
            self._property = PropertyMap({})

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"< Utility Network Server @ {self._url} >"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return f"< Utility Network Server @ {self._url} >"

    # ----------------------------------------------------------------------
    @property
    def properties(self):
        """returns the properties for the service"""
        if self._property is None:
            self._init()
        return self._property

    # ----------------------------------------------------------------------
    def trace(
        self,
        locations: list[dict],
        trace_type: str,
        moment: int | None = None,
        configuration: dict | TraceConfiguration | None = None,
        result_type: list[dict] | None = None,
        result_types: list[dict] | None = None,
        trace_config_global_id: str | None = None,
        out_sr: int | None = None,
        future: bool = False,
        pbf: bool = False,
    ) -> dict:
        """
        A trace refers to a pre-configured algorithm that systematically travels
        a network to return results. Generalized traces allow you to trace
        across multiple types of domain networks. For example, running a
        Connected trace through your electric network. An assortment of options
        is provided with trace to support various analytic workflows. All traces
        use the network topology to read cached information about network
        features. This is done to improve performance of complex traces on large
        networks. Trace results are not guaranteed to accurately represent a
        utility network when dirty areas are present. The network topology must be
        validated to ensure it reflects the most recent edits or updates made to
        the network

        .. note::
            The active portal account must be licensed with the *Advanced Editing*
            user type extension to use this operation.

        =======================    ==================================================
        **Parameter**              **Description**
        -----------------------    --------------------------------------------------
        locations                  Required list of dictionaries. The locations for
                                   starting points and barriers. An empty array must
                                   be used when performing a subnetwork trace if a
                                   *subnetworkName* is provided as part of the
                                   `configuration`—for example, `locations=[]`.


                                   The location is ignored by the trace if the following
                                   required properties are not defined:

                                   * `percentAlong` : required for edge features and objects.
                                   * `terminalID` : required for junction features and objects.


                                   .. code-block:: python

                                       [{
                                           "traceLocationType" : "startingPoint" | "barrier",
                                           "globalId" : <guid>,
                                           "terminalId" : <int>,   // optional
                                           "percentAlong" : <double>, // optional
                                           "isFilterBarrier" : true | false // optional Introduced at 10.8.1
                                       }]
        -----------------------    --------------------------------------------------
        trace_type                 Required string. Specifies the core algorithm that
                                   will be executed to analyze the network. Can be
                                   configured using the `configuration` parameter.

                                   Values:

                                   * 'connected'
                                   * 'subnetwork'
                                   * 'subnetworkController'
                                   * 'upstream'
                                   * 'downstream'
                                   * 'loops'
                                   * 'shortestPath'
                                   * 'isolation'
        -----------------------    --------------------------------------------------
        moment                     Optional Integer. Unix Epoch time in milliseconds.
                                   Specifies the session moment. This should only be
                                   specified if you do not want to use the current
                                   moment.

                                   Example: moment = <Epoch time in milliseconds>
        -----------------------    --------------------------------------------------
        configuration              Optional dictionary or TraceConfiguration object.
                                   Specifies the collection of trace configuration
                                   properties. Depending on the `trace_type`, some
                                   properties are required.

                                   To see all configuration properties see:
                                   `Trace Configuration Properties
                                   <https://developers.arcgis.com/rest/services-reference/enterprise/trace-utility-network-server-.htm#GUID-F0C932FD-B403-4223-9B00-E44D156C7DF9/>`_
        -----------------------    --------------------------------------------------
        result_type                ** Deprecated, use `result_types` instead. **
        -----------------------    --------------------------------------------------
        result_types               Optional parameter specifying the types of results
                                   to return.

                                   .. code-block::

                                       [{
                                           "type" : "elements" | "aggregatedGeometry" | "connectivity" | "features" | "associations",
                                           "includeGeometry" : true | false,
                                           "includePropagatedValues": true | false,
                                           "networkAttributeNames" :["attribute1Name","attribute2Name",...],
                                           "diagramTemplateName": <value>,
                                           "resultTypeFields":[{"networkSourceId":<int>,"fieldname":<value>},...]
                                        },...
                                       ]
        -----------------------    --------------------------------------------------
        trace_config_global_id     Optional String. The global ID of a named trace configuration.
                                   When specified, this configuration is used instead of the
                                   traceConfiguration parameter. Additionally, named trace
                                   configurations are persisted with their own trace type so the
                                   trace type parameter is ignored.
        -----------------------    --------------------------------------------------
        out_sr                     Optional Integer. The output spatial reference.
        -----------------------    --------------------------------------------------
        pbf                        Optional Boolean. If True, the results are returned in
                                   the PBF format. The default is False.
        -----------------------    --------------------------------------------------
        future                     Optional boolean. If `True`, the request is processed as an asynchronous
                                   job and a URL is returned that points a location displaying the status
                                   of the job.

                                   The default is `False`.
        =======================    ==================================================

        .. note::
            When the Elements, Features, Connectivity, or Containment and attachment
            associations result_types options are specified, the output .json file
            includes a sourceMapping element. This element allows you to look up the
            layer name associated with each networkSourceId. To learn more, see
            `Configure a trace <https://pro.arcgis.com/en/pro-app/latest/help/data/utility-network/configure-a-trace.htm>`_

        :return:
            A dictionary with keys and value types of:

                | {
                |    "traceResults": {
                |        "elements": list,
                |    }
                |    "success": bool
                | }

        """
        url = "%s/trace" % self._url
        if isinstance(configuration, TraceConfiguration):
            configuration = configuration.to_dict()
        params = {
            "f": "pbf" if pbf is True else "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "traceType": trace_type,
            "moment": moment,
            "traceLocations": locations,
            "traceConfiguration": configuration,
            "async": future,
        }
        if trace_config_global_id:
            params["traceConfigurationGlobalId"] = trace_config_global_id

        # Both result_type and result_types will be mapped to resultTypes,
        # however prioritize result_types if both are provided
        if result_types:
            params["resultTypes"] = result_types
        elif result_type:
            params["resultTypes"] = result_type
        if out_sr:
            params["outSR"] = out_sr

        if future:
            res = self._session.post(url=url, data=_prepare_parameters(params)).json()
            f = self._run_async(
                self._status_via_url,
                session=self._session,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def disable_topology(self, future: bool = False) -> dict:
        """
        Disables the network topology for a utility network. When the
        topology is disabled, feature and association edits do not generate
        dirty areas. Analytics and diagram generation can't be performed when
        the topology is not present.

        When the network topology is disabled, the following happens:

        - All current rows in the topology tables are deleted.
        - No dirty areas are generated from edits.
        - Existing errors remain and can be addressed prior to enabling the
          network topology, without the overhead of dirty areas.

        To perform certain network configuration tasks, the network
        topology must be disabled.

        - Operation must be executed by the portal utility network owner.
        - The topology can be disabled in the default version or in a named
          version.  If the topology is disabled in a named version, the
          reconcile process can be used to inherit the state from the default
          branch version.

        =======================    ==================================================
        future                     Optional boolean. If `True`, the request is processed as an asynchronous
                                   job and a URL is returned that points a location displaying the status
                                   of the job.

                                   The default is `False`.
        =======================    ==================================================

        :return:
            Dictionary indicating 'success' or 'error'

        """
        url = "%s/disableTopology" % self._url
        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
        }
        if future:
            res = self._session.post(url=url, data=_prepare_parameters(params)).json()
            f = self._run_async(
                self._status_via_url,
                session=self._session,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def enable_topology(self, error_count: int = 10000, future: bool = False) -> dict:
        """
        Enabling the network topology for a utility network is done on the
        **DEFAULT** version. Enabling is **not** supported in named versions.
        When the network topology is enabled, all feature and association edits
        generate dirty areas, which are then cleaned  when the network topology
        is validated.

        When the network topology is enabled, the following happens:
        - Existing errors are deleted.
        - The topology is built for the full extent of the network.
        - Error dirty areas are created for any newly discovered errors.
        - The network topology is marked as enabled.

        .. note::
            The active portal account must be licensed with the *Advanced Editing*
            user type extension to use this operation.

        ====================================     ====================================================================
        **Parameter**                             **Description**
        ------------------------------------     --------------------------------------------------------------------
        error_count                              Optional Integer. Sets the threshold when the *enable_topology* will
                                                 stop if the maximum number of errors is met. The default value is
                                                 10,000.
        ------------------------------------     --------------------------------------------------------------------
        future                                    Optional boolean. If `True`, the request is processed as an asynchronous
                                                  job and a URL is returned that points a location displaying the status
                                                  of the job.

                                                  The default is `False`.
        ====================================     ====================================================================

        :return: Dictionary indicating 'success' or 'error'

        """
        if self._version_name.lower().find("default") == -1:
            raise Exception("Current version is not the `DEFAULT` version.")

        params = {"f": "json", "maxErrorCount": error_count}
        url = "%s/enableTopology" % self._url
        if future:
            res = self._session.post(url=url, data=_prepare_parameters(params)).json()
            f = self._run_async(
                self._status_via_url,
                con=self._gis._portal.con,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def disable_subnetwork_controller(
        self,
        network_source_id: str,
        global_id: str,
        terminal_id: str,
        out_sr: int | None = None,
    ) -> dict:
        """
        A subnetwork controller (or simply, a source or a sink) is the
        origin (or destination) of resource flow for a subset (or subnetwork)
        of the network. Examples of subnetwork controllers are circuit breakers
        in electric networks, town border stations in gas networks, and pump
        stations in water networks. Subnetwork controllers correspond to devices
        that have the *Subnetwork Controller* network category set. A source is
        removed with this method.

        ======================        ============================================================
        **Parameter**                 **Description**
        ----------------------        ------------------------------------------------------------
        network_source_id             Required String. The network source ID that the subnetwork
                                      controller participates in.
        ----------------------        ------------------------------------------------------------
        global_id                     Required String. The global ID of the device being disabled
                                      as a network controller.
        ----------------------        ------------------------------------------------------------
        terminal_id                   Required String. The terminal ID of the device being
                                      disabled as a network controller.
        ----------------------        ------------------------------------------------------------
        out_sr                        Required int. The output spatial reference as a wkid.
        ======================        ============================================================

        """

        url = "%s/disableSubnetworkController" % self._url
        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "networkSourceId": network_source_id,
            "featureGlobalId": global_id,
            "terminalId": terminal_id,
        }
        if out_sr:
            params["outSR"] = out_sr
        return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def enable_subnetwork_controller(
        self,
        network_source_id: str,
        global_id: str,
        terminal_id: str,
        subnetwork_controller_name: str,
        tier_name: str,
        subnetwork_name: str | None = None,
        description: str | None = None,
        notes: str | None = None,
        out_sr: int | None = None,
    ) -> dict:
        """
        A subnetwork controller is the origin (or destination) of resource
        flow for a subset (or subnetwork) of the network (e.g., a circuit
        breaker in electric networks, a town border station in gas networks, or
        pump stations in water networks). Controllers correspond to Devices that
        have the *Subnetwork Controller* network category set.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        network_source_id                           Required String. The network source ID that the subnetwork controller
                                                    participates in.
        ------------------------------------        --------------------------------------------------------------------
        global_id                                   Required String. The global ID of the device being enabled as a
                                                    network controller.
        ------------------------------------        --------------------------------------------------------------------
        terminal_id                                 Required String. The terminal ID for the terminal on the device being
                                                    enabled as a network controller.
        ------------------------------------        --------------------------------------------------------------------
        subnetwork_controller_name                  Required String. The name of the subnetwork controller.
        ------------------------------------        --------------------------------------------------------------------
        tier_name                                   Required String. The name of the tier.
        ------------------------------------        --------------------------------------------------------------------
        subnetwork_name                             Optional String. Specifies the name of the subnetwork.
        ------------------------------------        --------------------------------------------------------------------
        description                                 Optional String. Represents the description of the subnetwork controller.
        ------------------------------------        --------------------------------------------------------------------
        notes                                       Optional String. The notes associated with the subnetwork controller.
        ------------------------------------        --------------------------------------------------------------------
        out_sr                                      Optional Integer. The output spatial reference as a wkid (integer).
        ====================================        ====================================================================

        """

        url = "%s/enableSubnetworkController" % self._url
        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "networkSourceId": network_source_id,
            "featureGlobalId": global_id,
            "terminalID": terminal_id,
            "subnetworkControllerName": subnetwork_controller_name,
            "subnetworkName": subnetwork_name,
            "tierName": tier_name,
            "description": description,
            "notes": notes,
        }
        if out_sr is not None:
            params["outSR"] = out_sr
        return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def export_subnetwork(
        self,
        domain_name: str,
        tier_name: str,
        subnetwork_name: str,
        trace_configuration: dict | TraceConfiguration | None = None,
        export_acknowledgement: bool = False,
        result_type: list[dict] | None = None,
        result_types: list[dict] | None = None,
        moment: int | None = None,
        run_async: bool = False,
        future: bool = False,
        out_sr: int | None = None,
        pbf: bool = False,
    ) -> dict:
        """
        The *export_subnetwork* operation is used to export information about a
        subnetwork into a JSON file. That information can then be consumed by
        outside systems such as outage management and asset tracking. The
        operation allows you to delete corresponding rows in the Subnetworks
        table as long as the *IsDeleted* attribute is set to *True*. This
        indicates a subnetwork controller feeding the subnetwork has been
        removed.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        domain_name                                 Required String. The name of the domain network of which the subnetwork
                                                    is a part.
        ------------------------------------        --------------------------------------------------------------------
        tier_name                                   Required String. The name of the tier of which the subnetwork is a part.
        ------------------------------------        --------------------------------------------------------------------
        subnetwork_name                             Required String. The name of the subnetwork.
        ------------------------------------        --------------------------------------------------------------------
        trace_configuration                         Optional Dictionary or TraceConfiguration object. Specifies the
                                                    collection of trace configuration parameters.
                                                    See: `Trace <https://developers.arcgis.com/rest/services-reference/enterprise/trace-utility-network-server-.htm#GUID-F0C932FD-B403-4223-9B00-E44D156C7DF9/>`_
        ------------------------------------        --------------------------------------------------------------------
        export_acknowledgement                      Optional Boolean. Specify whether the export is acknowledged.
        ------------------------------------        --------------------------------------------------------------------
        result_type                                 **Deprecated** Use *result_types* instead.
        ------------------------------------        --------------------------------------------------------------------
        result_types                                Optional list of dictionaries. Specifies the type of results to return.

                                                    .. code-block:: python

                                                        [
                                                            {
                                                                "type" : "features" | "geometries" | "network" | "connectivity" | "controllers" | "associations" | "aggregatedGeometry" |
                                                                "diagram" | "elements" |  "associations",
                                                                "includeGeometry" : true | false,
                                                                "includePropagatedValues": true | false,
                                                                "includeDomainDescriptions": true | false,
                                                                "networkAttributeNames" :["attribute1Name","attribute2Name",...],
                                                                "diagramTemplateName": <value>,
                                                                "resultTypeFields":[{"networkSourceId":<int>,"fieldname":<value>},...]
                                                            },...
                                                        ]
        ------------------------------------        --------------------------------------------------------------------
        moment                                      Optional Integer. Unix Epoch time in milliseconds. Specify the
                                                    session moment if you do not want to use the current moment.
        ------------------------------------        --------------------------------------------------------------------
        out_sr                                      Optional Integer. Optional parameter specifying the output spatial reference.
        ------------------------------------        --------------------------------------------------------------------
        pbf                                         Optional Boolean. If true, the response will be in PBF format.
                                                    The default from the REST is False. In Pro, starting at 3.3, the default is True so make
                                                    sure to set `pbf` to True if you want to mimic that response.
        ------------------------------------        --------------------------------------------------------------------
        future                                      Optional boolean. If `True`, the request is processed as an asynchronous
                                                    job and a URL is returned that points a location displaying the status
                                                    of the job.

                                                    The default is `False`.
        ====================================        ====================================================================

        :return:
            A dictionary with keys and value types of:

                | {
                |    "moment": int,
                |    "url": str,
                |    "subnetworkHasBeenDeleted": bool,
                |    "success": bool
                | }

        .. note::
            When the Features, Connectivity, or Containment and attachment
            associations *result_types* options are specified, the output
            *.json* file includes a *sourceMapping* element which allows you
            to look up the layer name associated with each *networkSourceId*.

        """

        url = "%s/exportSubnetwork" % self._url
        if isinstance(trace_configuration, TraceConfiguration):
            trace_configuration = trace_configuration.to_dict()

        # if 'supportFlowDirections' is False, remove `use_digitized_direction` from the trace configuration
        if (
            "supportFlowDirections" in self.properties
            and not self.properties["supportFlowDirections"]
        ):
            if "use_digitized_direction" in trace_configuration:
                del trace_configuration["use_digitized_direction"]
            elif "useDigitizedDirection" in trace_configuration:
                del trace_configuration["useDigitizedDirection"]

        if run_async:
            future = True

        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "moment": moment,
            "domainNetworkName": domain_name,
            "tierName": tier_name,
            "subnetworkName": subnetwork_name,
            "exportAcknowledgement": export_acknowledgement,
            "traceConfiguration": trace_configuration,
            "async": future,
        }

        # Both result_type and result_types will be mapped to resultTypes,
        # however prioritize result_types if both are provided
        if result_types:
            params["resultTypes"] = result_types
        elif result_type:
            params["resultTypes"] = result_type
        if out_sr:
            params["outSR"] = out_sr
        if pbf:
            params["f"] = "pbf"

        if future:
            res = self._session.post(url=url, data=_prepare_parameters(params)).json()
            f = self._run_async(
                self._status_via_url,
                session=self._session,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def query_network_moments(
        self,
        moments_to_return: list[str] | None = None,
        moment: int | None = None,
    ) -> dict:
        """
        The `query_network_moments` operation returns the moments related
        to the network topology and operations against the topology. This
        includes when the topology was initially enabled, when it was last
        validated, when the topology was last disabled (and later enabled),
        and when the definition of the utility network was last modified.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        moments_to_return                           Optional List of Strings. Represents the collection of validate moments to
                                                    return. Default is all.

                                                    Values:

                                                            [ "initialEnableTopology" | "fullValidateTopology" | "partialValidateTopology" | "enableTopology" | "disableTopology" | "definitionModification" | "updateIsConnected" | "indexUpdate" | "all"]

                                                    .. code-block:: python

                                                        >>> # Example Usage:

                                                        >>> query_network_moments(moments_to_return=["enableTopology","initialEnableTopology"],
                                                                                  ...)
        ------------------------------------        --------------------------------------------------------------------
        moment                                      Optional Integer. Unix Epoch time in milliseconds. Specify the
                                                    session moment if you do not want to use the current moment.
        ====================================        ====================================================================

        :return:
            A dictionary with keys and value types of:

                | {"networkMoments": list,
                | "validateNetworkTopology": bool,
                | "success": bool}
        """
        url = "%s/queryNetworkMoments" % self._url
        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "momentsToReturn": (
                moments_to_return if moments_to_return is not None else ["all"]
            ),
            "moment": moment,
        }
        return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def synthesize_association_geometries(
        self,
        attachment_associations: bool = False,
        connectivity_associations: bool = False,
        containment_associations: bool = False,
        count: int = 200,
        extent: dict = None,
        out_sr: int | dict[str, Any] | None = None,
        moment: int | None = None,
    ) -> dict:
        """
        The `synthesize_association_geometries` operation is used to export
        geometries representing associations that are synthesized as line
        segments corresponding to the geometries of the devices at the
        endpoints. All features associated with an association must be in
        the specified extent in order for the geometry to be synthesized.
        If only zero or one of the devices/junctions intersects the extent,
        then no geometry will be synthesized.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        attachment_associations                     Optional Boolean. Whether to return attachment associations.
        ------------------------------------        --------------------------------------------------------------------
        connectivity_associations                   Optional Boolean. Represents whether to return connectivity associations.
        ------------------------------------        --------------------------------------------------------------------
        containment_associations                    Optional Boolean. Whether to return containment associations.
        ------------------------------------        --------------------------------------------------------------------
        count                                       Required Int. Represents the maximum number of geometries that
                                                    can be synthesized and returned in the result.
        ------------------------------------        --------------------------------------------------------------------
        extent                                      Required Dictionary. Represents the envelope of the area to
                                                    synthesize association geometries.

                                                    .. code-block:: python

                                                        {
                                                            "xmin": <minimum x-coordinate>,
                                                            "ymin": <minimum y-coordinate>,
                                                            "xmax": <maximum x-coordinate>,
                                                            "ymax": <maximum y-coordinate>,
                                                            "spatialReference": {
                                                            "wkid": <spatial reference well-known identifier>,
                                                            "latestWkid": <the current wkid value associated with the wkid>
                                                            }
                                                        }
        ------------------------------------        --------------------------------------------------------------------
        out_sr                                      Optional Dictionary. Represents the output spatial reference.
        ------------------------------------        --------------------------------------------------------------------
        moment                                      Optional Integer. Unix Epoch time in milliseconds. Specify the
                                                    session moment if you do not want to use the current moment.
        ====================================        ====================================================================

        :return:
            A dictionary with keys and value types of:

                | {"maxGeometryCountExceeded": bool,
                | "associations": list,
                | "success": bool}
        """
        url = "%s/synthesizeAssociationGeometries" % self._url
        params = {
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "moment": moment,
            "attachmentAssociations": attachment_associations,
            "connectivityAssociations": connectivity_associations,
            "containmentAssociations": containment_associations,
            "maxGeometryCount": count,
            "extent": extent,
            "outSR": out_sr,
            "f": "json",
        }
        return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def update_is_connected(self, future: bool = False) -> dict:
        """

        Utility network features have an attribute called *IsConnected* that
        lets you know if a feature is connected to a subnetwork controller, and
        could potentially be part of an existing subnetwork. This operation
        updates this attribute on features in the specified utility network.
        This operation can only be executed on the default version by the portal
        utility network owner.

        ====================================        ====================================================================
        **Parameter**                               **Description**
        ------------------------------------        --------------------------------------------------------------------
        future                                      Optional boolean. If `True`, the request is processed as an asynchronous
                                                    job and a URL is returned that points a location displaying the status
                                                    of the job.

                                                    The default is *False*.
        ====================================        ====================================================================
        """
        url = "%s/updateIsConnected" % self._url
        params = {"f": "json"}

        if future:
            res = self._session.post(
                path=url, postdata=_prepare_parameters(params)
            ).json()
            f = self._run_async(
                self._status_via_url,
                session=self._session,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def update_subnetwork(
        self,
        domain_name: str,
        tier_name: str,
        subnetwork_name: str | None = None,
        all_subnetwork_tier: bool = False,
        continue_on_failure: bool = False,
        trace_configuration: dict | None = None,
        future: bool = False,
    ) -> dict:
        """
        A subnetwork is updated by calling the update_subnetwork operation. With
        this operation, one or all of the sub-networks in a single tier can be
        updated. When a subnetwork is updated, four things can occur; the
        Subnetwork Name attribute is updated for all features in the subnetwork,
        the record representing the subnetwork inside the SubnetLine feature
        class is generated or updated, rows for the subnetwork controllers in the
        Sub-networks table are updated, and diagrams are generated or updated for
        the subnetwork.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        domain_name                                 Required String. The name of the domain network that the subnetwork
                                                    is a part of.
        ------------------------------------        --------------------------------------------------------------------
        tier_name                                   Required String. The name of the tier that the subnetwork is a part of.
        ------------------------------------        --------------------------------------------------------------------
        subnetwork_name                             Optional String. Represents the name of the subnetwork to update. If
                                                    this parameter is not specified, the `all_subnetwork_tier` parameter
                                                    should be set to `True`, otherwise an error will occur.
        ------------------------------------        --------------------------------------------------------------------
        all_subnetwork_tier                         Optional Boolean. Set to `True` when all the sub-networks in a tier
                                                    need to be updated.
        ------------------------------------        --------------------------------------------------------------------
        continue_on_failure                         Optional Boolean. Continue updating sub-networks when `all_subnetwork_tier`
                                                    is `True` and a failure occurs when processing a subnetwork.
        ------------------------------------        --------------------------------------------------------------------
        trace_configuration                         Optional Dictionary. Represents the collection of trace configuration
                                                    parameters. See `trace` method to get parameters.
        ------------------------------------        --------------------------------------------------------------------
        future                                      Optional boolean. If `True`, the request is processed as an asynchronous
                                                    job and a URL is returned that points a location displaying the status
                                                    of the job.

                                                    The default is `False`.
        ====================================        ====================================================================

        :return: Dictionary of the JSON response.

        """
        url = "%s/updateSubnetwork" % self._url

        # if 'supportFlowDirections' is False, remove `use_digitized_direction` from the trace configuration
        if (
            "supportFlowDirections" in self.properties
            and not self.properties["supportFlowDirections"]
        ):
            if "use_digitized_direction" in trace_configuration:
                del trace_configuration["use_digitized_direction"]
            elif "useDigitizedDirection" in trace_configuration:
                del trace_configuration["useDigitizedDirection"]

        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "domainNetworkName": domain_name,
            "tierName": tier_name,
            "subnetworkName": subnetwork_name,
            "allSubnetworksInTier": all_subnetwork_tier,
            "continueOnFailure": continue_on_failure,
            "traceConfiguration": trace_configuration,
            "async": future,
        }

        if future:
            res = self._session.post(url=url, data=_prepare_parameters(params)).json()
            f = self._run_async(
                self._status_via_url,
                session=self._session,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def validate_topology(
        self,
        envelope: dict[str, Any],
        run_async: bool = False,
        return_edits: bool = False,
        validate_set: list[dict] | None = None,
        out_sr: int | None = None,
        validation_type: str = None,
        future: bool = False,
    ) -> dict:
        """
        Validating the network topology for a utility network maintains
        consistency between feature editing space and network topology space.
        Validating a network topology may include all or a subset of the
        dirty areas present in the network. Validation of network topology
        is supported synchronously and asynchronously.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        envelope                                    Required Dictionary. The envelope of the area to validate.

                                                    .. code-block:: python

                                                        {
                                                            "xmin": <minimum x-coordinate>,
                                                            "ymin": <minimum y-coordinate>,
                                                            "xmax": <maximum x-coordinate>,
                                                            "ymax": <maximum y-coordinate>,
                                                            "spatialReference": {
                                                            "wkid": <spatial reference well-known identifier>,
                                                            "latestWkid": <the current wkid value associated with the wkid>
                                                            }
                                                        }
        ------------------------------------        --------------------------------------------------------------------
        run_async                                   Optional Boolean. If *True* the request is processed as an
                                                    asynchronous job. The URL is returned to check the status of a job.
        ------------------------------------        --------------------------------------------------------------------
        return_edits                                Optional Boolean. Returned results are organized in a layer-by-layer fashion.
                                                    If `return_edits` is set to True, each layer may have edited features
                                                    returned in an *editedFeatures* object.The editedFeatures object
                                                    returns full features including the original features prior to
                                                    to delete; the original and current features for updates; and the
                                                    current rows for inserts, which may contain implicit changes
                                                    (for example, as a result of a calculation rule).

                                                    The response includes no editedFeatures and 'exceededTransferLimit = true'
                                                    if the count of edited features to return is more than the maxRecordCount.
                                                    If clients are using this parameter to maintain a cache, they should
                                                    invalidate the cache when exceededTransferLimit = true is returned.
                                                    If the server encounters an error when generating the list
                                                    of edits is the response, exceededTransferLimit = true is also returned.

                                                    Edited features are returned in the spatial reference
                                                    of the feature service as defined by the service's SpatialReference object
                                                    or by the spatialReference of the layer's extent object.
        ------------------------------------        --------------------------------------------------------------------
        validate_set                                Optional List of Dictionary. Introduced at Enterprise 10.9.1, it specifies
                                                    the set of features and objects to validate.

                                                    .. code-block:: python

                                                        [
                                                            {
                                                                "sourceId": <int>,
                                                                "globalIds": [<guid>]
                                                            }
                                                        ]
        ------------------------------------        --------------------------------------------------------------------
        out_sr                                      Optional integer. The output spatial reference.
        ------------------------------------        --------------------------------------------------------------------
        validation_type                             Optional string. Specifies the type of validation that will be performed.
                                                    The `rebuild` and `forceRebuild` options provide tools to rebuild the network
                                                    topology and repair inconsistencies discovered during the validate operation.
                                                    The `rebuild` option uses the dirty areas associated with the specified
                                                    `envelope` or `validate_set` values.
                                                    The `forceRebuild` option ignores the dirty areas and applies to all features in the
                                                    specified `envelope` or `validate_set` values.
                                                    Both the `rebuild` and `forceRebuild` options perform a build to reconstruct
                                                    the specified portions of the topology. The default is `normal`.

                                                    Values: 'normal' | 'rebuild' | 'forceRebuild'
        ------------------------------------        --------------------------------------------------------------------
        future                                      Optional boolean. If `True`, the request is processed as an asynchronous
                                                    job and a URL is returned that points a location displaying the status
                                                    of the job.

                                                    The default is `False`.
        ====================================        ====================================================================

        :return: Dictionary indicating 'success' or 'error'

        """
        url = "%s/validateNetworkTopology" % self._url
        if not validation_type:
            validation_type = "normal"

        if validation_type not in ["normal", "rebuild", "forceRebuild"]:
            raise ValueError(
                "Invalid validation_type. Must be one of 'normal', 'rebuild', or 'forceRebuild'."
            )
        if run_async:
            future = run_async
        params = {
            "f": "json",
            "gdbVersion": self._version_name,
            "sessionId": self._version_guid,
            "validateArea": envelope,
            "async": future,
            "returnEdits": return_edits,
        }
        if self._gis.version >= [9, 2]:
            params["validateSet"] = validate_set
            params["validationType"] = validation_type
        if out_sr:
            params["outSR"] = out_sr

        if future or run_async:
            res = self._session.post(url=url, data=_prepare_parameters(params)).json()
            f = self._run_async(
                self._status_via_url,
                session=self._session,
                url=res["statusUrl"],
                params={"f": "json"},
            )
            return f
        else:
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def associations(self) -> dict:
        """
        The associations resource provides access to operations that
        allow you to query and extract useful information from the
        associations table of a utility network.

        .. note::
            Available starting at Enterprise 10.9.1

        :return:
            A dictionary with two keys

        .. code-block:: python

            {"associations":list, "success": bool}
        """

        if self._gis.version >= [9, 2]:
            url = "%s/associations" % self._url
            params = {"f": "json"}
            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def query_associations(
        self,
        elements: list[dict] | None = None,
        moment: int | None = None,
        types: list[str] | None = None,
        return_deletes: bool = False,
    ) -> dict:
        """
        The query operation allows you to query the associations table and
        return association information for network features in a utility network.

        .. note::
            Available starting at Enterprise 10.9.1

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        elements                                    Required List of Dictionary. The feature or object elements for which
                                                    the association is queried.

                                                    .. code-block:: python

                                                        [{
                                                            "networkSourceId": <int>,
                                                            "globalId" : <guid>,
                                                            "terminalId": <int> //optional
                                                        }]
        ------------------------------------        --------------------------------------------------------------------
        moment                                      Optional Epoch time in milliseconds. Specify if you do not want to
                                                    use the current moment.
        ------------------------------------        --------------------------------------------------------------------
        types                                       Optional List of String(s). Specify the association types to be queried.

                                                    Values:

                                                    * "connectivity"
                                                    * "attachment"
                                                    * "containment"
                                                    * "junctionEdgeFromConnectivity"
                                                    * "junctionMidspanConnectivity"
                                                    * "junctionEdgeToConnectivity"
        ------------------------------------        --------------------------------------------------------------------
        return_deletes                              Optional Boolean. Specify whether to return logically deleted associations.
        ====================================        ====================================================================

        """
        if self._gis.version >= [9, 2]:
            url = "%s/associations/query" % self._url
            params = {
                "f": "json",
                "gdbVersion": self._version_name,
                "elements": json.dumps(elements),
                "returnDeletes": return_deletes,
            }
            if elements:
                params["moment"] = moment
            if types:
                params["types"] = types

            return self._session.post(url=url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def traverse_associations(
        self,
        elements: list[dict],
        moment: int | None = None,
        type: str = "unspecified",
        direction: str = "descending",
        dirty_filter: str = "none",
        error_filter: str = "none",
        stop_at_first_spatial: bool = True,
        max_depth: int | None = None,
    ) -> dict:
        """
        The `traverse_associations` operation allows you to obtain and extract useful
        information from the associations table in a utility network.

        The `type` parameter is used to provide the following predefined traversal types:

        * dirtyAreaExpansion—Returns associations and objects that have been modified and are marked as dirty. Completes a downward traversal, followed by an ascending traversal, with an exit filter on the first spatial feature in each direction.

        * firstContainers—Completes an ascending traversal on containment associations, with an exit filter on the first spatial feature.

        * spatialParents—Completes an ascending traversal on all association types, with an exit filter on the first spatial feature.

        * topContainers—Completes an ascending traversal to return associations and objects with no exit filter.

        * errorsNotModified—Completes a downward traversal to return associations in error, with an exit filter on the first spatial feature.

        * modifiedObjects—Completes a downward traversal to return associations that are dirty, with an exit filter on the first spatial feature.

        To create a custom traversal the `direction`, `dirty_filter`, `error_filter`, `stop_at_first_spatial`, and `max_depth` parameters can be used. When a traversal type is specified using the type parameter other than the default `unspecified``, these parameters are ignored.

        Available starting at Enterprise 10.9.1

        .. note::
            Associations are not traversed from spatial features to non-spatial objects
            and back to spatial features when the exit filter is placed on the first
            spatial feature.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        elements                                    Required List of Dictionary. The feature or object elements for which
                                                    the association is queried.

                                                    .. code-block:: python

                                                        [{
                                                            "networkSourceId": <int>,
                                                            "globalId" : <guid>,
                                                            "terminalId": <int> //optional
                                                        }]
        ------------------------------------        --------------------------------------------------------------------
        moment                                      Optional Epoch time in milliseconds. Specify if you do not want to
                                                    use the current moment.
        ------------------------------------        --------------------------------------------------------------------
        type                                        Optional String. Specify the association types to be queried.

                                                    Values:

                                                    * "unspecified"
                                                    * "dirtyAreaExpansion"
                                                    * "firstContainers"
                                                    * "spatialParents"
                                                    * "topContainers"
                                                    * "errorsNotModified"
                                                    * "modifiedObjects"
        ------------------------------------        --------------------------------------------------------------------
        direction                                   Optional String. Specify the direction of the association traversal.

                                                    Values:

                                                        "ascending" | "descending"
        ------------------------------------        --------------------------------------------------------------------
        dirty_filter                                Optional String. Specify whether to filter based on the dirty status
                                                    of the association.

                                                    .. note::
                                                        When `dirty_filter` and `error_filter` are specified together,
                                                        the filters are combined using the AND expression

                                                    Values:

                                                        "none" | "dirty" | "notDirty"
        ------------------------------------        --------------------------------------------------------------------
        error_filter                                Optional String. Specify whether to filter associations based on the
                                                    error code.

                                                    Values:

                                                       "none" | "inError" | "notInError"
        ------------------------------------        --------------------------------------------------------------------
        stop_at_first_spatial                       Optional Bool. Specify whether to stop the traversal of associations
                                                    from non-spatial object to feature when a spatial feature is encountered.
                                                    The traversal will stop at the feature and will not traverse to the
                                                    next non-spatial object.
        ------------------------------------        --------------------------------------------------------------------
        max_depth                                   Optional Integer. Control how many hops through the association graph
                                                    are allowed in either the ascending or descending direction.
        ====================================        ====================================================================

        """
        if self._gis.version >= [9, 2]:
            url = "%s/associations/traverse" % self._url
            params = {
                "f": "json",
                "gdbVersion": self._version_name,
                "elements": elements,
                "moment": moment,
                "type": type,
                "direction": direction,
                "dirtyStatusFilter": dirty_filter,
                "errorStatusFilter": error_filter,
                "stopAtFirstSpatial": stop_at_first_spatial,
                "maxDepth": max_depth,
            }
            return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def locations(self) -> dict:
        """
        The `locations` resource provides access to an operation that allows
        you to query the localizability of a provided set of objects and
        optionally synthesize geometry to be returned.

        Introduced at Enterprise 10.9.1

        :return: "success" if able to reach locations, else "error"
        """

        if self._gis.version >= [9, 2]:
            url = "%s/locations" % self._url
            params = {"f": "json"}
            return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def query_locations(
        self,
        elements: list[dict],
        max_geom_count: int,
        moment: int | None = None,
        attachment_associations: bool = False,
        connectivity_associations: bool = False,
        containment_associations: bool = False,
        locations: bool = False,
        out_sr: int | dict | None = None,
        future: bool = False,
    ) -> dict:
        """
        The query operation queries the localizability of the provided set of objects
        and optionally synthesizes geometry to be returned for each object in a
        geometry bag as a collection of points and polylines.

        ====================================        ====================================================================
        **Parameter**                                **Description**
        ------------------------------------        --------------------------------------------------------------------
        elements                                    Required List of Dictionary. The set of objects for which to get
                                                    localizability and synthesize the geometries.

                                                    .. code-block:: python

                                                        [{
                                                            "sourceId": <int>,
                                                            "globalIds" : [<guid>],
                                                        }]
        ------------------------------------        --------------------------------------------------------------------
        max_geom_count                              Required Integer. The maximum number of geometries that can be synthesized
                                                    and returned in the result.
        ------------------------------------        --------------------------------------------------------------------
        moment                                      Optional Epoch time in milliseconds. Specify if you do not want to
                                                    use the current moment.
        ------------------------------------        --------------------------------------------------------------------
        attachment_associations                     Optional Boolean. Whether to synthesize the geometry representing the
                                                    structural attachment associations.
        ------------------------------------        --------------------------------------------------------------------
        connectivity_associations                   Optional Boolean. Whether to synthesize the geometry representing the
                                                    connectivity associations.
        ------------------------------------        --------------------------------------------------------------------
        containment_associations                    Optional Boolean. Whether to synthesize the geometry representing the
                                                    containment associations.
        ------------------------------------        --------------------------------------------------------------------
        locations                                   Optional Boolean. Specify whether to synthesize the geometry representing
                                                    the derived location of the object. This option only affects the
                                                    results when objects are features or non-spatial objects.
        ------------------------------------        --------------------------------------------------------------------
        out_sr                                      Optional Dictionary or Integer. The output spatial reference.
        ====================================        ====================================================================

        :return:
            A dictionary with keys and value types of

                | {"exceededTransferLimit": bool,
                | "objects": list,
                | "associations": list,
                | "success": bool}
        """

        if self._gis.version >= [9, 2]:
            url = "%s/locations/query" % self._url
            params = {
                "f": "json",
                "gdbVersion": self._version_name,
                "sessionId": self._version_guid,
                "objects": elements,
                "maxGeometryCount": max_geom_count,
                "moment": moment,
                "attachmentAssociations": attachment_associations,
                "connectivityAssociations": connectivity_associations,
                "containmentAssociations": containment_associations,
                "locations": locations,
                "outSR": out_sr,
                "async": future,
            }

            if future:
                res = self._session.post(
                    url=url, data=_prepare_parameters(params)
                ).json()
                f = self._run_async(
                    self._status_via_url,
                    session=self._session,
                    url=res["statusUrl"],
                    params={"f": "json"},
                )
                return f
            else:
                return self._session.post(
                    url=url, data=_prepare_parameters(params)
                ).json()

    # ----------------------------------------------------------------------
    def trace_configurations(self) -> TraceConfigurationsManager:
        """
        The `trace_configurations` resource provides access to all trace
        configuration operations for a utility network.
        It is returned as an array of named trace configurations with the creator,
        name, and global ID for each.

        :return:
            A :class:`~arcgis.features._utility.TraceConfigurationsManager` object.
        """

        if self._gis.version >= [9, 2]:
            url = "%s/traceConfigurations" % self._url
            return TraceConfigurationsManager(
                url,
                version=self._version,
                gis=self._gis,
                service_url=self._url,
            )

    # ----------------------------------------------------------------------
    def _run_async(self, fn, **inputs):
        """runs the inputs asynchronously"""
        import concurrent.futures

        tp = concurrent.futures.ThreadPoolExecutor(1)
        try:
            future = tp.submit(fn=fn, **inputs)
        except Exception as e:
            future = tp.submit(fn, **inputs)
        tp.shutdown(False)
        return future

    # ----------------------------------------------------------------------

    def _status_via_url(self, session, url, params):
        """
        performs the asynchronous check to see if the operation finishes
        """
        status_allowed = [
            "InProgress",
            "Pending",
            "Completed",
            "Failed",
        ]
        status = session.get(url, params=_prepare_parameters(params)).json()
        while status["status"] in status_allowed and status["status"] != "Completed":
            if status["status"] == "Completed":
                return status
            elif status["status"] in [
                "Failed",
            ]:
                break
            status = session.get(url, params=_prepare_parameters(params)).json()
        return status


class TraceConfigurationsManager(object):
    """
    The traceConfigurations resource provides access to all trace configuration
    operations for a network service. It is returned as an array of named trace
    configurations with the creator, name, and global ID for each.


    The TraceConfigurationsManager allows methods to be done on a trace configuration.
    """

    _session = None
    _gis = None
    _url = None
    _property = None
    _version_guid = None
    _version_name = None
    _service_url = None

    # ----------------------------------------------------------------------
    def __init__(self, url, version=None, gis=None, service_url=None):
        """Constructor"""
        if gis is None:
            gis = env.active_gis
        self._gis = gis
        self._session = gis._session
        self._url = url
        self._service_url = service_url
        if version:
            self._version = version
            self._version_guid = version._guid
            self._version_name = version.properties.versionName
        else:
            self._version = None
            self._version_guid = None
            self._version_name = None

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"< Trace Configuration Manager @ {self._url} >"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return f"< Trace Configuration Manager @ {self._url} >"

    # ----------------------------------------------------------------------
    def list(self) -> dict:
        """
        List of all trace configurations in a service.

        :return:
            A dictionary with two keys: {"traceConfigurations": list, "success": bool}
        """
        return self._session.post(
            self._url, data=_prepare_parameters({"f": "json"})
        ).json()

    # ----------------------------------------------------------------------
    def query(
        self,
        global_ids: list[str] | None = None,
        creators: list[str] | None = None,
        tags: list[str] | None = None,
        names: list[str] | None = None,
        as_trace_configuration_class: bool = False,
    ) -> dict:
        """
        The query operation returns all properties from one or more
        named trace configurations in a utility network.

        ============================        ===========================================
        **Parameter**                        **Description**
        ----------------------------        -------------------------------------------
        global_ids                          Optional list of strings. Specify the global
                                            IDs of the named trace configs to be queried.
        ----------------------------        -------------------------------------------
        creators                            Optional list of strings. The creators of
                                            the named trace configurations to be queried.
        ----------------------------        -------------------------------------------
        tags                                Optional list of strings. The user tags of
                                            the named trace configurations to be queried.
        ----------------------------        -------------------------------------------
        names                               Optional list of strings. The names of the
                                            named trace configurations to be queried.
        ----------------------------        -------------------------------------------
        as_trace_configuration_class        Optional boolean. If True the list for
                                            "traceCongifurations" in return will be a list
                                            of TraceConfiguration class instances. If False,
                                            the list will be a list of dictionaries of trace
                                            configuration instances. The default is False.
        ============================        ===========================================

        :return:
            A dictionary with two keys: {"traceConfigurations": list, "success": bool}
        """
        if self._gis.version >= [9, 2]:
            url = "%s/query" % self._url
            params = {
                "f": "json",
                "globalIds": global_ids,
                "creators": creators,
                "tags": tags,
                "names": names,
            }
            res = self._session.post(url, data=_prepare_parameters(params)).json()
            if as_trace_configuration_class:
                trace_configs = []
                for trace in res["traceConfigurations"]:
                    trace = TraceConfiguration.from_config(trace)
                    trace_configs.append(trace)
                res["traceConfigurations"] = trace_configs
            return res

    # ----------------------------------------------------------------------
    def delete(self, global_ids: list[str]) -> dict:
        """
        The delete operation provides the ability to delete one or more named
        trace configurations in a utility network. A named trace configuration
        can only be deleted by an administrator or its creator.

        :return: A dictionary with key "success" indicating True or False.
        """
        if self._gis.version >= [9, 2]:
            url = "%s/delete" % self._url
            params = {
                "f": "json",
                "globalIds": global_ids,
            }
            return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def create(
        self,
        name: str,
        trace_type: str,
        trace_config: dict | TraceConfiguration,
        description: str | None = None,
        result_types: list[dict] | None = None,
        tags: list[str] | None = None,
    ) -> dict:
        """
        The create operation on the traceConfigurations resource provides the
        ability to create a single named trace configuration. Named trace
        configurations store the properties of a complex trace in a utility
        network and can be shared through a map service consumed by a web map
        or field app. Multiple parameters and properties are provided with
        the create operation that support the analytic workflows associated
        with the trace operation.

        If your trace configuration already exists, use the query method to find it.

        ======================      ===============================================
        **Parameter**                **Description**
        ----------------------      -----------------------------------------------
        name                        Required String. The altered name of the trace
                                    configuration.
        ----------------------      -----------------------------------------------
        trace_type                  Required String. Specify the core algorithm that
                                    will be used to analyze the network. Trace types
                                    can be configured using the `trace_config` parameter.

                                    Values:

                                        "connected" | "subnetwork" | "upstream" | "subnetworkController" | "downstream" | "loops" | "shortenPath" | "isolation"
        ----------------------      -----------------------------------------------
        trace_config                Required Dictionary or TraceConfiguration object.
                                    Specify the collection of
                                    altered trace configuration properties.

                                    See: `Properties <https://developers.arcgis.com/rest/services-reference/enterprise/trace-utility-network-server-.htm#GUID-F0C932FD-B403-4223-9B00-E44D156C7DF9/>`_
        ----------------------      -----------------------------------------------
        description                 Optional String. Specify the altered description
                                    of the trace configuration.
        ----------------------      -----------------------------------------------
        result_types                Optional List of Dictionary. Specify the altered
                                    types of results to return.

                                    .. code-block:: python

                                        [{
                                            "type" : "elements" | "aggregatedGeometry" | "connectivity" | "features" | "associations",
                                            "includeGeometry" : true | false,
                                            "includePropagatedValues": true | false,
                                            "networkAttributeNames" :["attribute1Name","attribute2Name",...],
                                            "diagramTemplateName": <value>,
                                            "resultTypeFields":[{"networkSourceId":<int>,"fieldname":<value>},...]
                                        },...]

        ----------------------      -----------------------------------------------
        tags                        Optional List of String(s). Specify the altered
                                    user-provided tags.
        ======================      ===============================================

        :return: A dictionary with key "success" indicating True or False.
        """
        if isinstance(trace_config, TraceConfiguration):
            trace_config = trace_config.to_dict()
        if self._gis.version >= [9, 2]:
            url = "%s/create" % self._url
            params = {
                "f": "json",
                "gdbVersion": self._version_name,
                "name": name,
                "description": description,
                "traceType": trace_type,
                "traceConfiguration": trace_config,
                "resultTypes": result_types,
                "tags": tags,
            }
            return self._session.post(url, data=_prepare_parameters(params)).json()

    # ----------------------------------------------------------------------
    def alter(
        self,
        global_id: str,
        name: str | None = None,
        description: str | None = None,
        trace_type: str = "connected",
        trace_config: dict | TraceConfiguration | None = None,
        result_types: list[dict] | None = None,
        tags: list[str] | None = None,
    ) -> dict:
        """
        The alter operation provides the ability to alter a single named
        trace configuration. A named trace configuration can only be altered
        by an administrator or the creator of the configuration.
        For example, you can update an existing trace configuration to
        accommodate changes in the network or address incorrectly set parameters
        without the need to delete and re-create a trace configuration.
        This enables existing map services to continue use of the named trace
        configuration without requiring the map to be republished.

        ======================      ===============================================
        **Parameter**                **Description**
        ----------------------      -----------------------------------------------
        global_id                   Required String. Specifying the global ID of
                                    the named trace configuration to alter.
        ----------------------      -----------------------------------------------
        name                        Optional String. The altered name of the trace
                                    configuration.
        ----------------------      -----------------------------------------------
        description                 Optional String. Specify the altered description
                                    of the trace configuration.
        ----------------------      -----------------------------------------------
        trace_type                  Optional String. Specify the core algorithm that
                                    will be used to analyze the network. Trace types
                                    can be configured using the `trace_config` parameter.

                                    Values:

                                            "connected" | "subnetwork" | "upstream" | "subnetworkController" | "downstream" | "loops" | "shortenPath" | "isolation"
        ----------------------      -----------------------------------------------
        trace_config                Optional Dictionary or instance of TraceConfiguration
                                    class. Specify the collection of
                                    altered trace configuration properties.

                                    See: `Properties <https://developers.arcgis.com/rest/services-reference/enterprise/trace-utility-network-server-.htm#GUID-F0C932FD-B403-4223-9B00-E44D156C7DF9/>`_
        ----------------------      -----------------------------------------------
        result_types                Optional List of Dictionary. Specify the altered
                                    types of results to return.

                                    .. code-block:: python

                                        [{
                                            "type" : "elements" | "aggregatedGeometry" | "connectivity" | "features" | "associations",
                                            "includeGeometry" : true | false,
                                            "includePropagatedValues": true | false,
                                            "networkAttributeNames" :["attribute1Name","attribute2Name",...],
                                            "diagramTemplateName": <value>,
                                            "resultTypeFields":[{"networkSourceId":<int>,"fieldname":<value>},...]
                                        },...]

        ----------------------      -----------------------------------------------
        tags                        Optional List of String(s). Specify the altered
                                    user-provided tags.
        ======================      ===============================================

        :return: A dictionary with key "success" indicating True or False.
        """

        if self._gis.version >= [9, 2]:
            url = "%s/alter" % self._url
            if isinstance(trace_config, TraceConfiguration):
                trace_config = trace_config.to_dict()
            params = {
                "f": "json",
                "globalId": global_id,
                "name": name,
                "description": description,
                "traceType": trace_type,
                "traceConfiguration": trace_config,
                "resultTypes": result_types,
                "tags": tags,
            }
            return self._session.post(url, data=_prepare_parameters(params)).json()
