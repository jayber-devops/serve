from __future__ import annotations
from pydantic import (
    BaseModel,
    Field,
    conlist,
    field_validator,
    ValidationInfo,
    ConfigDict,
    model_validator,
)
from typing import Literal, Tuple, Union, Optional, Any

__all__ = [
    "_PolygonValidator",
    "_PolylineValidator",
    "_PointValidator",
    "_EnvelopeValidator",
    "_MultiPointValidator",
    "_SpatialReferenceValidator",
]

###########################################################################
EndPointType = conlist(float, min_length=2, max_length=4)
CenterPointType = conlist(float, min_length=2, max_length=2)
MultiPointCoordinate = conlist(float | int, min_length=2, max_length=4)
###########################################################################
CircularArcTuple = Tuple[
    EndPointType,
    CenterPointType,
    Literal[0, 1],  # Minor/Major flag
    Literal[0, 1],  # Clockwise flag
]
###########################################################################
EllipticArcTuple = Tuple[
    EndPointType,
    CenterPointType,
    Literal[0, 1],  # Minor/Major flag
    Literal[0, 1],  # Clockwise flag
    float,  # Rotation (radians)
    float,  # Semi-major axis length
    float,  # Minor/Major axis ratio
]
###########################################################################
# Type for a single point (coordinates)
PointType = conlist(float | int | None, min_length=2, max_length=4)


###########################################################################
class OpenCircularArc(BaseModel):
    """
    Represents an Open Circular Arc, strictly defined by a two-element 'c'
    property array. Uses conlist for precise length validation of the points.
    """

    # Define 'c' as a Tuple to enforce the exact structure and order of the 2 elements.
    c: Tuple[
        # 1. End point: [<x>, <y>, <z>, <m>] (min 2, max 4 elements)
        conlist(float, min_length=2, max_length=4),
        # 2. Interior point: [<interior_x>, <interior_y>] (exactly 2 elements)
        conlist(float, min_length=2, max_length=2),
    ] = Field(
        ...,
        description="The array representing the end point and interior point in order.",
    )

    # --- Properties for easier access ---

    @property
    def end_point(self) -> conlist(float, min_length=2, max_length=4):
        return self.c[0]

    @property
    def interior_point(self) -> conlist(float, min_length=2, max_length=2):
        return self.c[1]


###########################################################################
class BezierCurve(BaseModel):
    """
    Represents a Cubic Bézier Curve, strictly defined by a three-element 'b'
    property array. Uses conlist for precise length validation of the points.
    """

    # Define 'b' as a Tuple to enforce the exact structure and order of the 3 elements.
    b: Tuple[
        # 1. End point: [<x>, <y>, <z>, <m>] (min 2, max 4 elements)
        conlist(float, min_length=2, max_length=4),
        # 2. Control point 1: [<x>, <y>] (exactly 2 elements)
        conlist(float, min_length=2, max_length=2),
        # 3. Control point 2: [<x>, <y>] (exactly 2 elements)
        conlist(float, min_length=2, max_length=2),
    ] = Field(
        ...,
        description="The array representing the three cubic Bezier curve properties in order.",
    )

    # --- Properties for easier access ---

    @property
    def end_point(self) -> conlist(float, min_length=2, max_length=4):
        return self.b[0]

    @property
    def control_point_1(self) -> conlist(float, min_length=2, max_length=2):
        return self.b[1]

    @property
    def control_point_2(self) -> conlist(float, min_length=2, max_length=2):
        return self.b[2]


###########################################################################
class Arc(BaseModel):
    """
    Represents either a Circular Arc (4-element array) or an Elliptic Arc
    (7-element array) using the 'a' property, with strict list length validation.
    """

    # Pydantic will attempt to match the data against EllipticArcTuple first (since it's longer)
    # and then fall back to CircularArcTuple.
    a: Union[EllipticArcTuple, CircularArcTuple] = Field(
        ...,
        description="The array representing the arc properties. Length 4 for Circular, Length 7 for Elliptic.",
    )

    @property
    def arc_type(self) -> Literal["Elliptic", "Circular"]:
        """Identifies the type of arc based on the array length."""
        return "Elliptic" if len(self.a) == 7 else "Circular"

    @property
    def end_point(self) -> EndPointType:
        return self.a[0]

    @property
    def center_point(self) -> CenterPointType:
        return self.a[1]

    @property
    def is_minor(self) -> bool:
        """True if the arc is minor (1)."""
        return self.a[2] == 1

    @property
    def is_clockwise(self) -> bool:
        """True if the arc is oriented clockwise (1)."""
        return self.a[3] == 1

    @property
    def rotation_radians(self) -> Union[float, None]:
        """Major axis rotation angle (radians). Only available for Elliptic Arc."""
        # This field is only safe to access if the length is 7
        return self.a[4] if self.arc_type == "Elliptic" else None

    @property
    def semi_major_axis(self) -> Union[float, None]:
        """Length of the semi-major axis. Only available for Elliptic Arc."""
        return self.a[5] if self.arc_type == "Elliptic" else None

    @property
    def axis_ratio(self) -> Union[float, None]:
        """Ratio of the minor axis to major axis. Only available for Elliptic Arc."""
        return self.a[6] if self.arc_type == "Elliptic" else None


###########################################################################
# A segment within a curved ring is either a straight point or a curve definition
CurvedRingSegment = Union[PointType, OpenCircularArc, BezierCurve, Arc]
CurvedPathSegment = Union[PointType, OpenCircularArc, BezierCurve, Arc]
###########################################################################
# A curved ring is a list of segments
CurvedRing = list[CurvedRingSegment]
CurvedPath = list[CurvedPathSegment]
###########################################################################
# A standard ring is a list of points
StandardRing = list[PointType]
StandardPath = list[PointType]
###########################################################################
# A list of point IDs for a single ring
RingIDs = list[Union[int, str]]  # Assuming IDs can be integers or strings
PathIDs = list[Union[int, str]]  # Assuming IDs can be integers or strings


###########################################################################
class _PolylineValidator(BaseModel):
    """
    Represents a Polyline object that supports both standard and curved paths
    (with Arc and Bezier segments).
    """

    # Flags for Z and M presence
    hasZ: bool = Field(
        False, description="Indicates if the coordinates include a Z value."
    )
    hasM: bool = Field(
        False, description="Indicates if the coordinates include an M value."
    )

    # Curved paths (outer boundary and holes)
    curvedPaths: Optional[list[CurvedPath]] = Field(
        None,
        alias="curvePaths",
        description="list of paths that can contain straight line segments (PointType) or curve objects (Arc, OpenCircularArc, BezierCurve).",
    )

    # Standard Paths (outer boundary and holes, ONLY straight segments)
    paths: Optional[list[StandardPath]] = Field(
        None,
        alias="paths",
        description="List of paths that contain only straight line segments (PointType).",
    )

    # Optional list of IDs corresponding to the points/segments in the paths
    ids: Optional[list[PathIDs]] = Field(
        None, description="Optional list of point/segment IDs for each path."
    )

    # Optional spatial reference system definition
    spatialReference: Optional[dict[str, Any]] = Field(
        None, description="The spatial reference of the geometry."
    )

    @field_validator("curvedPaths", "paths", mode="after")
    @classmethod
    def check_at_least_one_path_type_is_present(cls, v: Any, info: ValidationInfo):
        """Ensure either 'curvedPaths' or 'paths' is present."""
        curved_paths = info.data.get("curvedPaths")
        paths = info.data.get("paths")
        if curved_paths is None and paths is None and v is None:
            raise ValueError(
                "Polyline must contain at least one of 'curvedPaths' or 'paths'."
            )
        return v

    @field_validator("ids", mode="after")
    @classmethod
    def check_ids_length_matches_paths(
        cls, v: Optional[list[PathIDs]], info: ValidationInfo
    ) -> Optional[list[PathIDs]]:
        """Ensure the number of ID lists matches the number of total paths, and each ID list matches the number of segments in its path."""
        if v is None:
            return v

        data = info.data
        paths = data.get("paths") or []
        curved_paths = data.get("curvedPaths") or []
        all_paths = list(paths) + list(curved_paths)

        if len(v) != len(all_paths):
            raise ValueError(
                f"The number of lists in 'ids' ({len(v)}) must match the total number of path ({len(all_paths)})."
            )

        for idx, (id_list, path) in enumerate(zip(v, all_paths)):
            num_segments = len(path)
            if len(id_list) != num_segments:
                raise ValueError(
                    f"ID list at index {idx} has {len(id_list)} elements, but path {idx} has {num_segments} segments."
                )
        return v

    @field_validator("spatialReference", mode="after")
    @classmethod
    def validate_spatial_reference(cls, v: Any, info: ValidationInfo) -> Any:
        if v:
            _SpatialReferenceValidator(**v)
        return v


###########################################################################
class _SpatialReferenceValidator(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    wkid: int | None = Field(None, title="wkid", alias="wkid")
    latestWkid: int | None = Field(None, alias="latestWkid", title="latestWkid")
    vcsWkid: int | None = Field(None, alias="vcsWkid", title="vcsWkid")
    latestVcsWkid: int | None = Field(
        None, alias="latestVcsWkid", title="latestVcsWkid"
    )
    wkt: str | None = Field(None, title="wkt")
    latestWkt: str | None = Field(None, alias="latestWkt", title="latestWkt")

    @model_validator(mode="after")
    def _ensure_at_least_one_identifier(self):
        """Ensure at least one of 'wkid', 'latestWkid', 'wkt', or 'latestWkt' is provided."""
        if not any([v for v in (self.wkt, self.latestWkt, self.wkid, self.latestWkid)]):
            raise ValueError(
                "At least one of 'wkid', 'latestWkid', 'wkt', or 'latestWkt' must be provided."
            )
        return self


###########################################################################
class _PointValidator(BaseModel):
    x: int | float | None = Field(
        ..., alias="x", title="x", description="The 'x' coordinate of the geometry"
    )
    y: int | float | None = Field(
        None, alias="y", title="y", description="The 'y' coordinate of the geometry"
    )
    z: int | float | None = Field(
        None, alias="z", title="z", description="The 'z' coordinate of the geometry"
    )
    m: int | None = Field(
        None, alias="m", title="m", description="The 'm' coordinate of the geometry"
    )
    id: int | None = Field(
        None,
        alias="id",
        title="id",
        description="The 'identifier' of the coordinate of the geometry",
    )
    spatialReference: dict[str, Any] | None = Field(
        None,
        alias="spatialReference",
        description="The spatial reference of the geometry.",
    )

    @field_validator("spatialReference", mode="after")
    @classmethod
    def validate_spatial_reference(cls, v: Any, info: ValidationInfo) -> Any:
        if v:
            _SpatialReferenceValidator(**v)
        return v


###########################################################################
class _EnvelopeValidator(BaseModel):
    """
    This object defines the bounding geometry given the lower-left and
    upper-right corners of the bounding box.
    """

    model_config = ConfigDict(
        extra="forbid",
    )
    spatialReference: dict[str, Any] | None = Field(
        ...,
        alias="spatialReference",
        description="An object used to specify the spatial reference of the given geometry.",
        title="spatialReference",
    )

    xmin: float | int | Literal["NaN"] | None = Field(
        None,
        description="A numeric value indicating the bottom-left X-coordinate of an extent envelope.",
    )
    ymin: float | int | None = Field(
        None,
        description="A numeric value indicating the bottom-left Y-coordinate of an extent envelope.",
    )
    zmin: float | int | None = Field(
        None,
        description="A numeric value indicating the bottom Z-coordinate of an extent envelope.",
    )
    idmin: int | None = Field(
        None,
        alias="idmin",
        description="An minimum ID value for the envelope.",
    )
    xmax: float | int | None = Field(
        None,
        description="A numeric value indicating the top-right X-coordinate of an extent envelope.",
    )
    ymax: float | int | None = Field(
        None,
        description="A numeric value indicating the top-right Y-coordinate of an extent envelope.",
    )
    zmax: float | int | None = Field(
        None,
        description="A numeric value indicating the top Z-coordinate of an extent envelope.",
    )
    idmax: int | None = Field(
        None,
        alias="idmax",
        description="An maximum ID value for the envelope.",
    )
    mmin: float | int | None = Field(
        None,
        alias="mmin",
        description="A numeric value indicating the minimum M-coordinate of an extent envelope.",
    )
    mmax: float | int | None = Field(
        None,
        alias="mmax",
        description="A numeric value indicating the maximum M-coordinate of an extent envelope.",
    )

    @field_validator("spatialReference", mode="after")
    @classmethod
    def validate_spatial_reference(cls, v: Any, info: ValidationInfo) -> Any:
        if v:
            _SpatialReferenceValidator(**v)
        return v


###########################################################################
class _MultiPointValidator(BaseModel):
    """
    Represents a MultiPoint object that can support x,y,z,m values.
    """

    # Flags for Z and M presence
    hasZ: bool = Field(
        False, description="Indicates if the coordinates include a Z value."
    )
    hasM: bool = Field(
        False, description="Indicates if the coordinates include an M value."
    )
    # Standard Rings (outer boundary and holes, ONLY straight segments)
    points: list[MultiPointCoordinate] = Field(
        ...,
        alias="points",
        description="List of points coordinates.",
    )
    # Optional list of IDs corresponding to the points/segments in the rings
    ids: Optional[list[RingIDs]] = Field(
        None, description="Optional list of point IDs for each coordinate."
    )
    spatialReference: dict[str, Any] | None = Field(
        None,
        alias="spatialReference",
        description="The spatial reference of the geometry.",
    )

    @field_validator("ids", mode="after")
    @classmethod
    def check_ids_length_matches_points(
        cls, v: Optional[list[RingIDs]], info: ValidationInfo
    ) -> Optional[list[RingIDs]]:
        """Ensure the number of ID lists matches the number of points, and each ID list matches the number of coordinates in points."""
        if v is None:
            return v
        points = info.data.get("points")
        if not points:
            if len(v) != 0:
                raise ValueError(f"'ids' must be empty if 'points' is empty.")
            return v
        if len(v) != len(points):
            raise ValueError(
                f"The number of lists in 'ids' ({len(v)}) must match the number of points ({len(points)})."
            )
        for idx, (id_list, pt) in enumerate(zip(v, points)):
            if not isinstance(id_list, list):
                raise ValueError(f"ID at index {idx} is not a list.")
        return v

    @field_validator("spatialReference", mode="after")
    @classmethod
    def validate_spatial_reference(cls, v: Any, info: ValidationInfo) -> Any:
        if v:
            _SpatialReferenceValidator(**v)
        return v


###########################################################################
class _PolygonValidator(BaseModel):
    """
    Represents a Polygon object that supports both standard and curved rings
    (with Arc and Bezier segments).
    """

    # Flags for Z and M presence
    hasZ: bool = Field(
        False, description="Indicates if the coordinates include a Z value."
    )
    hasM: bool = Field(
        False, description="Indicates if the coordinates include an M value."
    )

    # Curved Rings (outer boundary and holes)
    curvedRings: Optional[list[CurvedRing]] = Field(
        None,
        alias="curvedRings",
        description="List of rings that can contain straight line segments (PointType) or curve objects (Arc, OpenCircularArc, BezierCurve).",
    )

    # Standard Rings (outer boundary and holes, ONLY straight segments)
    rings: Optional[list[StandardRing]] = Field(
        None,
        alias="rings",
        description="List of rings that contain only straight line segments (PointType).",
    )

    # Optional list of IDs corresponding to the points/segments in the rings
    ids: Optional[list[RingIDs]] = Field(
        None, description="Optional list of point/segment IDs for each ring."
    )

    # Optional spatial reference system definition
    spatialReference: Optional[dict[str, Any]] = Field(
        None, description="The spatial reference of the geometry."
    )

    @field_validator("spatialReference", mode="after")
    @classmethod
    def validate_spatial_reference(cls, v: Any, info: ValidationInfo) -> Any:
        if v:
            _SpatialReferenceValidator(**v)
        return v

    @model_validator(mode="after")
    def validate_model(self) -> Any:
        """Checks the rings"""
        if self.curvedRings is None and self.rings is None:
            raise ValueError(
                "rings or curvedRings must be defined in order to have a valid Polygon geometry."
            )

        return self

    @field_validator("curvedRings", "rings", mode="after")
    @classmethod
    def check_at_least_one_ring_type_is_present(
        cls, v: Any, info: ValidationInfo
    ) -> Any:
        """Ensure either 'curvedRings' or 'rings' is present."""
        # 'info.data' contains validated fields up to this point
        if (
            info.data.get("curvedRings") is None
            and info.data.get("rings") is None
            and v is None
        ):
            # Need to check both 'curvedRings' and 'rings' as this validator runs for both
            if info.field_name == "curvedRings" or info.field_name == "rings":
                # Check for the *other* field as well if the current one is None
                if (
                    info.data.get("curvedRings") is None
                    and info.data.get("rings") is None
                ):
                    raise ValueError(
                        "Polygon must contain at least one of 'curvedRings' or 'rings'."
                    )
        return v

    @field_validator("ids", mode="after")
    @classmethod
    def check_ids_length_matches_rings(
        cls, v: Optional[list[RingIDs]], info: ValidationInfo
    ) -> Optional[list[RingIDs]]:
        """Ensure the number of ID lists matches the number of total rings."""
        if v is None:
            return v

        data = info.data
        num_rings = 0
        if data.get("curvedRings"):
            num_rings += len(data["curvedRings"])
        if data.get("rings"):
            num_rings += len(data["rings"])

        if len(v) != num_rings:
            raise ValueError(
                f"The number of lists in 'ids' ({len(v)}) must match the total number of rings ({num_rings})."
            )

        # The full validation check for each ring's segment count is omitted as per original note,
        # but the check for the number of ID lists is crucial and is maintained.
        return v
