from __future__ import annotations
from arcgis.ai._text.api import translate, analyze_text

__all__ = ["translate", "analyze_text"]
