from __future__ import annotations
import copy
from arcgis.auth.tools import LazyLoader
from arcgis.auth import EsriSession
from typing import Any, Literal
from arcgis.ai._utils import _get_url, _get_gis

_arcgis_gis = LazyLoader("arcgis.gis")

__all__ = ["translate", "analyze_text"]


# -------------------------------------------------------------------------
def translate(
    text: str | list[str],
    to_language: list[str],
    from_language: str | None = "en",
    provider: Literal["default", "gpt"] | None = None,
    *,
    gis: _arcgis_gis.GIS | None = None,
) -> list[str]:
    """
    Translates language strings passed to the desired array of output cultures.
    Users have the option to choose the translation provider. Currently supported providers
    are "gpt" for large language model translation and "default" for default translation.

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    text                list[str] or str. The text to translate.
    ---------------     --------------------------------------------------------------------
    to_language         Required list of strings. The list of languages to convert to.
                        To see a list of supported languages, use the `languages` property of the `GIS` object.

                        Example: to_language = ["fr", "de"] (to translate to French and German)
    ---------------     --------------------------------------------------------------------
    from_language       Optional str. The source language.  The default is US English.
                        To see a list of supported languages, use the `languages` property of the `GIS` object.

                        Example: from_language = "en" (for English)
    ---------------     --------------------------------------------------------------------
    gis                 Optional GIS. The connection to the organization that has AI assistants enabled.
    ---------------     --------------------------------------------------------------------
    provider            Optional string. Only accepted values are "gpt" or "default".
                        The translation provider to use. The default is "default".

                        - default - machine translation service that uses modern neural machine translation technology to translate text and documents
                        - gpt - translation service that uses a Large Language Model to translate text and documents that takes advantage of context. This approach requires careful review and the technology is improving.
    ===============     ====================================================================

    :return:

    Dictionary with the translations.

    """
    # Get the GIS and service URL
    gis = _get_gis(gis)
    service_url: str = _get_url(gis=gis, utility_service="text_translate")
    if service_url is None:
        raise ValueError(
            "The text translation service is not available in your organization."
        )
    session: EsriSession = gis.session

    # Prepare text data
    if isinstance(text, str):
        text = [{"key": "key:1", "text": text}]
    elif isinstance(text, (list, tuple)):
        text = [{"key": f"key:{idx}", "text": t} for idx, t in enumerate(text)]
    if isinstance(to_language, str):
        to_language = [to_language]

    if from_language is None:
        from_language = "en"

    if text is None or len(text) == 0:
        raise ValueError(
            "The text parameter must contain at least one string to translate."
        )

    # Prepare request parameters
    params: dict[str, Any] = {
        "f": "json",
        "outputCultures": to_language,
        "inputCulture": from_language,
        "input": text,
        "provider": provider or "default",
    }

    # Prepare headers and make the POST request
    headers = copy.copy(session.headers)
    headers["x-esri-request-source"] = "ArcGIS-API-For-Python"
    resp = session.post(
        url=service_url,
        json=params,
        headers=headers,
        allow_redirects=True,
    )

    # Handle response
    try:
        resp.raise_for_status()
    except Exception as e:
        return {"error": str(e), "details": resp.text}
    return resp.json()


# -------------------------------------------------------------------------
def analyze_text(
    text: str,
    prompt: str | list[str] | list[dict[str, str]],
    to_language: str | None = None,
    from_language: str | None = None,
    *,
    gis: _arcgis_gis.GIS | None = None,
) -> dict[str, Any]:
    """
    Analyzes the provided text against the given prompt(s) using AI capabilities. Allows users to submit
    text for analysis, which can include tasks such as sentiment analysis, entity recognition, and other
    natural language processing operations.

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    text                Required string. The text to analyze.
    ---------------     --------------------------------------------------------------------
    prompt              Required str, list[str], or dict[str, str]. Defines the types of
                        analysis to perform. If a string or list of strings, these are the
                        prompts or instructions. If a dictionary, keys are labels for each
                        analysis type and values are the corresponding prompts/instructions.

                        Example 1 (string):
                        prompt = "Summarize the following text."

                        Example 2 (list):
                        prompt = [
                            "Summarize the following text.",
                            "Extract key entities from the following text."
                        ]

                        Example 3 (dictionary):
                        prompt = [{
                            "key": "summarize_prompt",
                            "context": "Summarize the following text."
                        },
                        {
                            "key": "entities_prompt",
                            "context": "Extract key entities from the following text."
                        }]
    ---------------     --------------------------------------------------------------------
    to_language         Optional string. The output language for analysis. Default is
                        "en". To see a list of supported languages, use the `languages` property of
                        the `GIS` object. (Example: `gis.languages`)
    ---------------     --------------------------------------------------------------------
    from_language       Optional string. The source language of the input text. Default is
                        "en". To see a list of supported languages, use the `languages` property of
                        the `GIS` object. (Example: `gis.languages`)
    ---------------     --------------------------------------------------------------------
    gis                 Optional GIS. The connection to the organization that has AI
                        assistants enabled.
    ===============     ====================================================================

    :return:

        Dictionary with the analysis results.

    """
    # Get the GIS and service URL
    gis = _get_gis(gis)
    service_url: str = _get_url(gis=gis, utility_service="text_analyze")
    if service_url is None:
        raise ValueError(
            "The text analysis service is not available in your organization."
        )
    session: EsriSession = gis.session

    # Prepare prompt data
    if isinstance(prompt, str):
        context = [{"key": "key:1", "context": prompt}]
    elif isinstance(prompt, (list, tuple)):
        # Flatten if prompt is a list of dicts (already formatted), else convert each string to dict
        if prompt and all(
            isinstance(t, dict) and "key" in t and "context" in t for t in prompt
        ):
            context = prompt  # Already in correct format
        else:
            context = [
                {"key": f"unique_string_{idx}", "context": t}
                for idx, t in enumerate(prompt)
            ]

    if context is None or len(context) == 0:
        raise ValueError(
            "The prompt parameter must contain at least one prompt and be of type `str`, `list[str]`, or `list[dict[str, str]]`."
        )

    # Prepare request parameters
    params: dict[str, Any] = {
        "f": "json",
        "input": text,
        "data": context,
    }
    if to_language:
        params["outputCulture"] = to_language
    if from_language:
        params["inputCulture"] = from_language

    # Prepare headers and make the POST request
    headers = copy.copy(session.headers)
    headers["x-esri-request-source"] = "ArcGIS-API-For-Python"
    resp = session.post(
        url=service_url,
        json=params,
        headers=headers,
        allow_redirects=True,
    )

    # Handle response
    try:
        resp.raise_for_status()
    except Exception as e:
        return {"error": str(e), "details": resp.text}
    return resp.json()
