from functools import lru_cache
from arcgis.auth.tools import LazyLoader

_arcgis_gis = LazyLoader("arcgis.gis")
_arcgis_env = LazyLoader("arcgis")


# -------------------------------------------------------------------------
def _get_gis(gis: _arcgis_gis.GIS | None) -> _arcgis_gis.GIS:
    gis = gis or _arcgis_env.env.active_gis or _arcgis_gis.GIS()
    if gis.org_settings.get("aiAssistantsEnabled", False) is False:
        raise Exception(
            (
                "AI assistants is not available on this Portal."
                " Please contact your administrator."
            )
        )

    state, msg = _validate_gis(gis)
    if state is False:
        raise ValueError(msg)
    return gis


def _get_url(gis: _arcgis_gis.GIS, utility_service: str) -> str:
    """returns the service url from the logged in GIS account"""
    prop: dict = dict(gis.properties)
    help_services: dict = prop.get("helperServices", {})
    if "aiUtilityServices" in help_services:
        available_services: dict = help_services.get("aiUtilityServices", None)
        base_url: str = available_services.get("url")
        service_endpoint: str = available_services.get("api", {}).get(
            f"{utility_service}"
        )
        if base_url and service_endpoint:
            return f"{base_url}{service_endpoint}"
    return None


@lru_cache(maxsize=255)
def _validate_gis(gis: _arcgis_gis.GIS) -> bool:
    """validates if the GIS object and user meet the criteria"""
    if gis is None:
        return (
            False,
            "The GIS object is None, please provide the GIS object.",
        )
    if gis._is_arcgisonline is False:
        return False, "The GIS object is not ArcGIS Online"
    elif gis.users.me is None:
        return False, "The GIS object is anonymous, please login."

    return True, ""
