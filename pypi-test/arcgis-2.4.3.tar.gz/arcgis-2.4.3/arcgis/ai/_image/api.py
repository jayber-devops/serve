from __future__ import annotations
import copy
from arcgis.auth.tools import LazyLoader
from arcgis.ai._utils import _get_url, _get_gis
from typing import Any
from arcgis.auth import EsriSession

_arcgis_gis = LazyLoader("arcgis.gis")


def analyze_image(
    image: str,
    prompt: str | list[str] | list[dict[str, str]],
    to_language: str | None = None,
    *,
    gis: _arcgis_gis.GIS | None = None,
) -> dict[str, Any]:
    """
    Analyze the image using AI-powered models for object detection, text extraction, image description, and segmentation.

    .. Note::
        The image must be hosted on an `arcgis.com` domain. Images from other domains will not be accepted.

    ===============     ====================================================================
    **Parameter**       **Description**
    ---------------     --------------------------------------------------------------------
    image               Required string. URL of the image (must be hosted on arcgis.com domain)
    ---------------     --------------------------------------------------------------------
    prompt              Required str or list[str] or list[dict[str, str]]. Prompt or list of prompts describing the analysis to perform.

                        Examples:
                        - Single string prompt: "List all the colors present in the image."
                        - List of string prompts: ["Describe the scene in the image.", "Identify any text in the image."]
                        - List of dict prompts: [{"key": "colors_prompt", "context": "List all the colors present in the image."}, {"key": "text_prompt", "context": "Identify any text in the image."}]
    ---------------     --------------------------------------------------------------------
    to_language         Optional str. The source language.  The default is US English ("en").
                        To see a list of supported languages, use the `languages` property of the `GIS` object.
    ---------------     --------------------------------------------------------------------
    gis                 Optional GIS. The connection to the organization that has AI assistants enabled.
    ===============     ====================================================================

    :return:
    Dictionary with the analysis results.
    """
    # Get GIS instance and service URL
    gis = _get_gis(gis)
    service_url = _get_url(gis, "image_analyze")
    if service_url is None:
        raise ValueError(
            "The image analysis service is not available in your organization."
        )
    session: EsriSession = gis.session

    # Prepare prompt data
    if isinstance(prompt, str):
        prompt_data = [{"key": "unique_string_1", "context": prompt}]
    elif isinstance(prompt, (list, tuple)):
        # Flatten if prompt is a list of dicts (already formatted), else convert each string to dict
        if prompt and all(
            isinstance(t, dict) and "key" in t and "context" in t for t in prompt
        ):
            prompt_data = prompt  # Already in correct format
        else:
            prompt_data = [
                {"key": f"unique_string_{idx}", "context": t}
                for idx, t in enumerate(prompt)
            ]
    if not prompt_data:
        raise ValueError(
            "The prompt parameter must contain at least one prompt and be of type `str`, `list[str]`, or `list[dict[str, str]]`."
        )

    # Prepare request parameters
    params: dict[str, Any] = {
        "f": "json",
        "input": image,
        "data": prompt_data,
    }
    if to_language:
        params["outputCulture"] = to_language

    # Prepare headers and make the request
    headers = copy.copy(session.headers)
    headers["x-esri-request-source"] = "ArcGIS-API-For-Python"
    resp = session.post(
        url=service_url,
        json=params,
        headers=headers,
    )

    # Handle response
    try:
        resp.raise_for_status()
    except Exception as e:
        return {"error": str(e), "details": resp.text}
    return resp.json()
