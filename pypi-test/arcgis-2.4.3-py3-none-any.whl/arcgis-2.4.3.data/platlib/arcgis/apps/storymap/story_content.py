from __future__ import annotations
from enum import Enum

from arcgis._impl.common._deprecate import deprecated
from arcgis.auth.tools import LazyLoader

arcgis = LazyLoader("arcgis")
_imports = LazyLoader("arcgis._impl.imports")
sm_module = LazyLoader("arcgis.apps.storymap")
urllib3 = LazyLoader("urllib3")
requests = LazyLoader("requests")
mimetypes = LazyLoader("mimetypes")
puremagic = LazyLoader("puremagic")
html = LazyLoader("html")
os = LazyLoader("os")
io = LazyLoader("io")
_parse = LazyLoader("urllib.parse")
utils = LazyLoader("arcgis.apps.storymap._utils")
uuid = LazyLoader("uuid")
pd = LazyLoader("pandas")
arcgis_map = LazyLoader("arcgis.map")
struct = LazyLoader("struct")
warnings = LazyLoader("warnings")


class Language(Enum):
    """
    Represents the supported Languages for the Code Content.
    """

    TEXT = "txt"
    ARCADE = "arcade"
    CSHARP = "cs"
    CSS = "css"
    DIFF = "diff"
    HTML = "html"
    JAVASCRIPT = "js"
    JAVA = "java"
    JSON = "json"
    JSX = "jsx"
    KOTLIN = "kt"
    PYTHON = "py"
    R = "r"
    SQL = "sql"
    SVG = "svg"
    SWIFT = "swift"
    TSX = "tsx"
    TYPESCRIPT = "ts"


class TextStyles(Enum):
    """
    Represents the Supported Text Styles for the Text Content.
    Example: Text(text="foo", style=TextStyles.HEADING)
    """

    PARAGRAPH = "paragraph"
    BULLETLIST = "bullet-list"
    NUMBERLIST = "numbered-list"
    HEADING = "h2"
    SUBHEADING = "h3"
    QUOTE = "quote"
    HEADING1 = "h2"
    HEADING2 = "h3"
    HEADING3 = "h4"


class Scales(Enum):
    """
    Scale is a unit-less way of describing how any distance on the map translates
    to a real-world distance. For example, a map at a 1:24,000 scale communicates that 1 unit
    on the screen represents 24,000 of the same unit in the real world.
    So one inch on the screen represents 24,000 inches in the real world.

    This can be used for methods involving viewpoint in the Map Content.
    """

    WORLD = {"scale": 147914382, "zoom": 2}
    CONTINENT = {"scale": 50000000, "zoom": 3}
    COUNTRIESLARGE = {"scale": 25000000, "zoom": 4}
    COUNTRIESSMALL = {"scale": 12000000, "zoom": 5}
    STATES = {"scale": 6000000, "zoom": 6}
    PROVINCES = {"scale": 6000000, "zoom": 6}
    STATE = {"scale": 3000000, "zoom": 7}
    PROVINCE = {"scale": 3000000, "zoom": 7}
    COUNTIES = {"scale": 1500000, "zoom": 8}
    COUNTY = {"scale": 750000, "zoom": 9}
    METROPOLITAN = {"scale": 320000, "zoom": 10}
    CITIES = {"scale": 160000, "zoom": 11}
    CITY = {"scale": 80000, "zoom": 12}
    TOWN = {"scale": 40000, "zoom": 13}
    NEIGHBORHOOD = {"scale": 2000, "zoom": 14}
    STREETS = {"scale": 10000, "zoom": 15}
    STREET = {"scale": 5000, "zoom": 16}
    BUILDINGS = {"scale": 2500, "zoom": 17}
    BUILDING = {"scale": 1250, "zoom": 18}
    SMALLBUILDING = {"scale": 800, "zoom": 19}
    ROOMS = {"scale": 400, "zoom": 20}
    ROOM = {"scale": 100, "zoom": 22}


class SlideLayout(Enum):
    """
    This depicts the various layout types that can be used for a BriefingSlide.
    """

    SINGLE = "single"
    DOUBLE = "double"
    TITLELESSSINGLE = "titleless-single"
    TITLELESSDOUBLE = "titleless-double"
    FULL = "full"
    SECTIONDOUBLE = "section-double"
    SECTIONSINGLE = "section-single"
    TITLELESSFLEXIBLE = "titleless-flexible"
    FLEXIBLE = "flexible"


class SlideSubLayout(Enum):
    """
    Depicts the various subtypes for a BriefingSlide. For example, if the layout type is
    `DOUBLE` then the sublayout type can be `THREE_SEVEN` or `SEVEN_THREE` or `ONE_ONE`.
    """

    THREE_SEVEN = "3-7"
    SEVEN_THREE = "7-3"
    ONE_ONE = "1-1"


class GalleryDisplay(Enum):
    JIGSAW = "jigsaw"
    SQUAREDYNAMIC = "square-dynamic"


class CoverType(Enum):
    """
    The different cover types for the StoryMap, briefings, and collections.

    Storymap and Briefing can be: FULL | SIDEBYSIDE | MINIMAL
    Collection can be: GRID | MAGAZINE | JOURNAL
    """

    FULL = "full"
    SIDEBYSIDE = "sidebyside"
    MINIMAL = "minimal"
    GRID = "grid"
    MAGAZINE = "magazine"
    JOURNAL = "journal"
    CARD = "card"
    SPLIT = "split"
    TOP = "top"


class VerticalPosition(Enum):
    """
    The vertical position of the cover.
    """

    TOP = "top"
    MIDDLE = "middle"
    BOTTOM = "bottom"


class HorizontalPosition(Enum):
    """
    The horizontal position of the cover.
    """

    START = "start"
    CENTER = "center"
    END = "end"


class CoverStyle(Enum):
    """
    The style of the cover
    """

    GRADIENT = "gradient"
    THEMED = "themed"
    TRANSPARENTWITHLIGHTCOLOR = "transparent-with-light-color"
    TRANSPARENTWITHDARKCOLOR = "transparent-with-dark-color"


class CoverSize(Enum):
    """
    The size of the cover
    """

    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"


###############################################################################################################
class Separator:
    """
    Add a subtle break in between different sections of your story. The exact look of the separator will vary based on the theme you have chosen.

    Class representing a `separator`. You can use this class to edit and remove separators from a storymap.
    This refers to the main separator content type that can be added to a story. For timeline separators use
    the Timeline class.
    """

    def __init__(self, **kwargs) -> None:
        # Can be created from scratch or already exist in story
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return "Separator()"

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs) -> None:
        # Assign the story
        self._story = story

        # Create separator nodes.
        self._story._properties["nodes"][self._node] = {
            "type": "separator",
        }

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)


###############################################################################################################
class Image:
    """
    Class representing an `Image` in a Story, Briefing, or Collection created from a url or file.

    .. warning::
        Image must be smaller than 10 MB to avoid having issues when saving or publishing.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    path                    Required String. The file path or url to the image that will be added.
    ------------------      --------------------------------------------------------------------
    link                    Optional String. A URL that will open in a new tab when the image is
                            clicked. An image with a link cannot be expanded.
    ==================      ====================================================================
    """

    def __init__(
        self, path: str | None = None, link: str | None = None, **kwargs
    ) -> None:
        self._story = kwargs.pop("story", None)  # storymap or briefing

        # Keep track if URL since different representation style in story dictionary
        self._is_url = False
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # If node exists in the story, then create from resources and node dictionary provided.
        # If the node doesn't already exist, create a new instance.
        self._existing = self._check_node()

        if self._existing:
            # Get the resource node id
            self._resource_node = self._story._properties["nodes"][self._node]["data"][
                "image"
            ]
            self._is_url = (
                self._story._properties["resources"][self._resource_node]["data"][
                    "provider"
                ]
                == "uri"
            )
            # Path differs whether from file path or URL originally
            self._path = (
                self._story._properties["resources"][self._resource_node]["data"]["src"]
                if self._is_url
                else self._story._properties["resources"][self._resource_node]["data"][
                    "resourceId"
                ]
            )
            self._link = (
                self._story._properties["nodes"][self._node]["data"]["link"]
                if "link" in self._story._properties["nodes"][self._node]["data"]
                else None
            )
        else:
            # Create a new instance of Image
            self._path = path
            self._resource_node = utils.create_unique_id(resource=True)
            self._link = link

            # Determine if URL or file path
            if _parse.urlparse(self._path).scheme == "https":
                self._is_url = True

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Image(image='{self.image}')"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self) -> str:
        """
        Get properties for the Image.

        :return:
            A dictionary depicting the node dictionary and resource
            dictionary for the image.
            If nothing is returned, make sure your content has been added
            to the story.
        """
        if self._existing is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
                "resource_dict": self._story._properties["resources"][
                    self._resource_node
                ],
            }

    # ----------------------------------------------------------------------
    @property
    def image(self) -> str:
        """
        Get/Set the image property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        image               String. The new image path.
        ==================  ========================================
        """
        return self._path

    # ----------------------------------------------------------------------
    @image.setter
    def image(self, path: str):
        if self._existing:
            self._update_image_data(path)
        else:
            # Determine if URL or file path
            if _parse.urlparse(self._path).scheme == "https":
                self._is_url = True
        self._path = path

    # ----------------------------------------------------------------------
    @property
    def link(self) -> str | None:
        """
        Get/Set a URL that will open in a new tab when the image is clicked.
        An image with a link cannot be expanded.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        link                String. The new URL link. To remove the link,
                            set to None.
        ==================  ========================================

        :return:
            A string representing the link being used. None if nothing is set.
        """
        return self._link

    # ----------------------------------------------------------------------
    @link.setter
    def link(self, link: str):
        self._link = link
        if self._existing:
            if link is None:
                if "link" in self._story._properties["nodes"][self._node]["data"]:
                    del self._story._properties["nodes"][self._node]["data"]["link"]
                return
            self._story._properties["nodes"][self._node]["data"]["link"] = link

    # ----------------------------------------------------------------------
    @property
    def full_view(self) -> bool | None:
        """
        This property, if True, will set the image to fit to screen. Enable this option
        for portrait images you would like readers to see in their entirety without
        scrolling. This constraint does not apply when the story is viewed on a small
        screen, and other image sizing options may have no effect when it is enabled.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        enable              Boolean. Set to True to enable full view.
        ==================  ========================================

        :return:
            A boolean representing if full view is enabled.
        """
        if self._existing is True:
            if "isInFullView" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"][
                    "isInFullView"
                ]
        return None

    # ----------------------------------------------------------------------
    @full_view.setter
    def full_view(self, enable: bool):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"][
                "isInFullView"
            ] = enable

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the image.

        The Image must be part of a story or briefing to add a caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Image.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the image.

        The Image must be a part of a story or briefing to add alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Image.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text
            return self.alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set display for image.

        The Image must be a part of a story or briefing to change display.

        Values for Storymap: `small` | `wide` | `full` | `float`
        Values for Briefings: `fill` | `fit`
        """
        if self._existing is True and isinstance(self._story, sm_module.StoryMap):
            return self._story._properties["nodes"][self._node]["config"].get("size")
        elif self._existing is True and isinstance(self._story, sm_module.Briefing):
            return (
                self._story._properties["nodes"][self._node]["config"]
                .get("placement", {})
                .get("type")
            )

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display):
        if self._existing is True and isinstance(self._story, sm_module.StoryMap):
            self._story._properties["nodes"][self._node]["config"]["size"] = display
        elif self._existing is True and isinstance(self._story, sm_module.Briefing):
            # For briefings, display is set in placement
            self._story._properties["nodes"][self._node]["config"]["placement"][
                "type"
            ] = display

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story, **kwargs):
        # Assign the story
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", None)

        # Make an add resource call if not url. File path is added as a resource to Story Item
        if self._is_url is False:
            utils.add_resource(self._story, self._path)

        # Create image nodes. This is similar for file path and url
        self._story._properties["nodes"][self._node] = {
            "type": "image",
            "data": {
                "image": self._resource_node,
                "caption": "" if caption is None else caption,
                "alt": "" if alt_text is None else alt_text,
            },
        }
        if isinstance(self._story, sm_module.StoryMap):
            self._story._properties["nodes"][self._node]["config"] = {
                "size": "" if display is None else display
            }
        elif isinstance(self._story, sm_module.Briefing):
            self._story._properties["nodes"][self._node].setdefault("config", {})[
                "placement"
            ] = {
                "type": "fit",
                "fill": {"x": 0.5, "y": 0.5},
                "fit": {"color": "backgroundColor"},
            }

        if isinstance(self._story, sm_module.StoryMap):
            self._story._properties["nodes"][self._node]["config"] = {
                "size": "" if display is None else display
            }
        elif isinstance(self._story, sm_module.Briefing):
            self._story._properties["nodes"][self._node]["config"]["placement"] = {
                "type": "fit",
                "fill": {"x": 0.5, "y": 0.5},
                "fit": {"color": "backgroundColor"},
            }

        # Create resource node. Different if file path or url
        if self._is_url is False:
            # Get image properties and create the resourceId that corresponds to the resource added
            width, height = utils.get_image_dimensions(self._path)
            self._story._properties["resources"][self._resource_node] = {
                "type": "image",
                "data": {
                    "resourceId": os.path.basename(os.path.normpath(self._path)),
                    "provider": "item-resource",
                    "height": height,
                    "width": width,
                },
            }
        else:
            # Get image properties and assign the image src
            width, height = utils.get_image_dimensions(self._path) or (400, 300)
            self._story._properties["resources"][self._resource_node] = {
                "type": "image",
                "data": {
                    "src": self._path,
                    "provider": "uri",
                    "height": height,
                    "width": width,
                },
            }
        if self._link:
            # Add link if it exists
            self._story._properties["nodes"][self._node]["data"]["link"] = self._link

    # ----------------------------------------------------------------------
    def _update_url_data(self, new_image):
        # New image is a Url
        self._is_url = True
        # Use puremagic to get image dimensions
        width, height = utils.get_image_dimensions(new_image)
        self._update_dimensions(width, height)

        # Update resource dictionary
        self._update_resource_data(new_image)

    # ----------------------------------------------------------------------
    def _get_resource_id(self):
        return (
            self._story._properties["resources"][self._resource_node]["data"][
                "resourceId"
            ]
            if "resourceId"
            in self._story._properties["resources"][self._resource_node]["data"]
            else None
        )

    # ----------------------------------------------------------------------
    def _update_file_path_data(self, new_image):
        # Update the height and width for the image
        # Use puremagic to get image dimensions
        width, height = utils.get_image_dimensions(new_image)
        self._update_dimensions(width, height)

        # Update resource dictionary
        resource_id = self._get_resource_id()
        # Update where file path is held
        self._story._properties["resources"][self._resource_node]["data"][
            "resourceId"
        ] = os.path.basename(os.path.normpath(new_image))
        # Delete path if item was previously a url
        if "src" in self._story._properties["resources"][self._resource_node]["data"]:
            del self._story._properties["resources"][self._resource_node]["data"]["src"]
        # Update provider
        self._story._properties["resources"][self._resource_node]["data"][
            "provider"
        ] = "item-resource"
        # Update the resource by removing old and adding new
        if resource_id:
            utils.remove_resource(self._story, resource_id)
        utils.add_resource(self._story, new_image)

    # ----------------------------------------------------------------------
    def _update_dimensions(self, width, height):
        self._story._properties["resources"][self._resource_node]["data"][
            "height"
        ] = height
        self._story._properties["resources"][self._resource_node]["data"][
            "width"
        ] = width

    # ----------------------------------------------------------------------
    def _update_resource_data(self, new_image):
        # Update resource dictionary
        # Do not need to make a resource
        self._story._properties["resources"][self._resource_node]["data"][
            "src"
        ] = new_image
        # Delete if the image was previously a file path
        if (
            "resourceId"
            in self._story._properties["resources"][self._resource_node]["data"]
        ):
            del self._story._properties["resources"][self._resource_node]["data"][
                "resourceId"
            ]
        # Update provider
        self._story._properties["resources"][self._resource_node]["data"][
            "provider"
        ] = "uri"

    # ----------------------------------------------------------------------
    def _update_image_data(self, new_image):
        # Check if new_image is url or path
        if _parse.urlparse(new_image).scheme == "https":
            self._update_url_data(new_image)
        else:
            self._update_file_path_data(new_image)
        # Set new path
        return new_image

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Image360:
    """
    Class representing a 360 degree image in a Story or Briefing created from a url or file.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    path                    Required String. The file path or url to the 360 image that will be added.
    ==================      ====================================================================
    """

    def __init__(self, path: str | None = None, **kwargs) -> None:
        self._story = kwargs.pop("story", None)  # storymap or briefing
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # If node exists in the story, then create from resources and node dictionary provided.
        # If the node doesn't already exist, create a new instance.
        self._existing = self._check_node()

        if self._existing:
            # Get the resource node id
            self._resource_node = self._story._properties["nodes"][self._node]["data"][
                "image360"
            ]

            # Path differs whether from file path or URL originally
            self._path = self._story._properties["resources"][self._resource_node][
                "data"
            ]["resourceId"]
        else:
            # Create a new instance of Image360
            # Check path meets requirements
            self._check_image(path)
            self._path = path
            self._resource_node = utils.create_unique_id(resource=True)

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Image360(image='{self.image}')"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    def _check_image(self, path):
        """
        Check that the image meets the requirements for 360 images.
        """
        size_bytes = os.path.getsize(path)
        size_mb = size_bytes / (1024 * 1024)
        if size_mb > 25:
            raise ValueError("The image must be less than 25MB.")

        # The aspect ration needs to be between 1.5:1 and 3:1
        width, height = utils.get_image_dimensions(path)
        aspect_ratio = width / height
        if aspect_ratio < 1.5 or aspect_ratio > 3.0:
            raise ValueError("The image aspect ratio must be between 1.5:1 and 3:1.")

    # ----------------------------------------------------------------------
    @property
    def image(self) -> str:
        """
        Get/Set the image property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        image               String. The new image path.
        ==================  ========================================
        """
        return self._path

    # ----------------------------------------------------------------------
    @image.setter
    def image(self, path: str):
        if self._existing:
            self._update_image_data(path)
        self._path = path

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the image.

        The Image must be part of a story or briefing to add a caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Image.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the image.

        The Image must be a part of a story or briefing to add alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Image.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text
            return self.alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set display for image.

        The Image must be a part of a story or briefing to change display.

        Values for Storymap: `standard` | `wide` | `full` | `float`
        Values for Briefings: `fill` | `fit`
        """
        if self._existing is True and isinstance(self._story, sm_module.StoryMap):
            return self._story._properties["nodes"][self._node]["config"].get("size")
        elif self._existing is True and isinstance(self._story, sm_module.Briefing):
            return (
                self._story._properties["nodes"][self._node]["config"]
                .get("placement", {})
                .get("type")
            )

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display):
        if self._existing is True and isinstance(self._story, sm_module.StoryMap):
            self._story._properties["nodes"][self._node]["config"]["size"] = display
        elif self._existing is True and isinstance(self._story, sm_module.Briefing):
            # For briefings, display is set in placement
            self._story._properties["nodes"][self._node]["config"]["placement"][
                "type"
            ] = display

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story, **kwargs):
        # Assign the story
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", None)

        # Make an add resource call with the image path
        utils.add_resource(self._story, self._path)

        # Create image nodes. This is similar for file path and url
        self._story._properties["nodes"][self._node] = {
            "type": "image360",
            "data": {
                "image360": self._resource_node,
                "caption": caption,
                "alt": alt_text,
            },
        }
        if isinstance(self._story, sm_module.StoryMap):
            self._story._properties["nodes"][self._node]["config"] = {
                "size": "standard" if display is None else display
            }
        elif isinstance(self._story, sm_module.Briefing):
            self._story._properties["nodes"][self._node].setdefault("config", {})[
                "placement"
            ] = {
                "type": "fit",
                "fill": {"x": 0.5, "y": 0.5},
                "fit": {"color": "backgroundColor"},
            }

        # Get image properties and create the resourceId that corresponds to the resource added
        width, height = utils.get_image_dimensions(self._path)
        self._story._properties["resources"][self._resource_node] = {
            "type": "image",
            "data": {
                "resourceId": os.path.basename(os.path.normpath(self._path)),
                "provider": "item-resource",
                "width": width,
                "height": height,
            },
        }

    # ----------------------------------------------------------------------
    def _get_image_dimensions(self, image_source):
        # Assume the source is a local file path
        with open(image_source, "rb") as f:
            image_data = f.read()

        # Use puremagic to get MIME type
        mime_info = puremagic.magic_string(image_data)[0]

        # Check if it's an image
        if mime_info.mime_type.startswith("image/"):
            # Use BytesIO to create a file-like object for both local files and fetched data
            with io.BytesIO(image_data) as image_file:
                # Read the first few bytes to identify the image format
                header = image_file.read(32)

                if header.startswith(
                    b"\xff\xd8\xff\xe0\x00\x10JFIF"
                ) or header.startswith(
                    b"\x00\x00\x00 ftypavif\x00\x00\x00\x00avifmif1miafMA1B"
                ):  # JPEG
                    # Extract dimensions from the APP0 segment
                    width, height = struct.unpack(">HH", header[7:11])
                    return width, height

                elif header.startswith(b"\x89PNG\r\n\x1a\n"):  # PNG
                    # Extract dimensions from the IHDR chunk
                    width, height = struct.unpack(">II", header[16:24])
                    return width, height

                else:
                    try:
                        width, height = struct.unpack(">HH", header[7:11])
                        return width, height
                    except Exception:
                        pass

        return None

    # ----------------------------------------------------------------------
    def _get_resource_id(self):
        return (
            self._story._properties["resources"][self._resource_node]["data"][
                "resourceId"
            ]
            if "resourceId"
            in self._story._properties["resources"][self._resource_node]["data"]
            else None
        )

    # ----------------------------------------------------------------------
    def _update_file_path_data(self, new_image):
        # Update the height and width for the image
        # Use puremagic to get image dimensions
        self._check_image(new_image)
        width, height = utils.get_image_dimensions(new_image)
        self._update_dimensions(width, height)

        # Update resource dictionary
        resource_id = self._get_resource_id()
        # Update where file path is held
        self._story._properties["resources"][self._resource_node]["data"][
            "resourceId"
        ] = os.path.basename(os.path.normpath(new_image))
        # Delete path if item was previously a url
        if "src" in self._story._properties["resources"][self._resource_node]["data"]:
            del self._story._properties["resources"][self._resource_node]["data"]["src"]
        # Update provider
        self._story._properties["resources"][self._resource_node]["data"][
            "provider"
        ] = "item-resource"
        # Update the resource by removing old and adding new
        if resource_id:
            utils.remove_resource(self._story, resource_id)
        utils.add_resource(self._story, new_image)

    # ----------------------------------------------------------------------
    def _update_dimensions(self, width, height):
        self._story._properties["resources"][self._resource_node]["data"][
            "height"
        ] = height
        self._story._properties["resources"][self._resource_node]["data"][
            "width"
        ] = width

    # ----------------------------------------------------------------------
    def _update_resource_data(self, new_image):
        # Update resource dictionary
        # Do not need to make a resource
        self._story._properties["resources"][self._resource_node]["data"][
            "src"
        ] = new_image
        # Delete if the image was previously a file path
        if (
            "resourceId"
            in self._story._properties["resources"][self._resource_node]["data"]
        ):
            del self._story._properties["resources"][self._resource_node]["data"][
                "resourceId"
            ]
        # Update provider
        self._story._properties["resources"][self._resource_node]["data"][
            "provider"
        ] = "uri"

    # ----------------------------------------------------------------------
    def _update_image_data(self, new_image):
        # Check if new_image is url or path
        self._update_file_path_data(new_image)
        # Set new path
        return new_image

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Video:
    """
    Class representing `Video` content in a Story, or Briefing created from a url or file.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    path                    Required String. The file path or embed url to the video that will
                            be added.

                            .. note::
                                URL must be an embed url.
                                Example: "https://www.youtube.com/embed/G6b7Kgvd0iA"

    ==================      ====================================================================
    """

    def __init__(self, path: str | None = None, **kwargs):
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._is_url = False
        self._existing = self._check_node()

        if self._existing:
            # Coming from a story, so get the resource node and path
            if self._story._properties["nodes"][self._node]["type"] == "video":
                self._resource_node = self._story._properties["nodes"][self._node][
                    "data"
                ]["video"]
                self._path = self._story._properties["resources"][self._resource_node][
                    "data"
                ]["resourceId"]
            else:
                self._resource_node = None
                self._path = self._story._properties["nodes"][self._node]["data"]["url"]
                self._is_url = True
        else:
            # Create a new instance
            self._path = path
            if _parse.urlparse(path).scheme == "https":
                self._is_url = True
                self._resource_node = None
            else:
                self._resource_node = utils.create_unique_id(resource=True)

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Video(path='{self._path}')"

    def __repr__(self) -> str:
        return str(self)

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get properties for the Video.

        :return:
            A dictionary depicting the node dictionary and resource
            dictionary for the video.
            If nothing is returned, make sure the content is part of the story.

        .. note::
            To change various properties of the Video use the other property setters.
        """
        if self._existing is True:
            vid_dict = {
                "node_dict": self._story._properties["nodes"][self._node],
            }
            if self._resource_node:
                vid_dict["resource_dict"] = (
                    self._story._properties["resources"][self._resource_node],
                )
            return vid_dict

    # ----------------------------------------------------------------------
    @property
    def video(self) -> str:
        """
        Get/Set the video property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        video               String. The new video path for the Video.
        ==================  ========================================

        :return:
            The video that is being used.
        """
        return self._path

    # ----------------------------------------------------------------------
    @video.setter
    def video(self, path: str):
        if self._existing is True:
            # update existing path and properties
            self._update_video(path)
        else:
            # setup so when video is added to story all info is correct
            self._path = path
            if _parse.urlparse(path).scheme == "https":
                self._is_url = True
                self._resource_node = None
            else:
                # Need to create a resource node if one does not exist
                self._resource_node = (
                    utils.create_unique_id(resource=True)
                    if self._resource_node is None
                    else self._resource_node
                )

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the video.

        The Video must be a part of a story to add a caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Video.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        else:
            return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the video.

        The Video must be a part of a story to add alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Video.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        else:
            return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text
            return self.alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set display for the video.

        Values: `small` | `wide` | `full` | `float`

        .. note::
            Cannot change display when video is created from a url
        """
        if self._existing is True:
            if self._is_url is True:
                return self._story._properties["nodes"][self._node]["data"]["display"]
            else:
                return self._story._properties["nodes"][self._node]["config"]["size"]

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display):
        if self._existing is True:
            if self._is_url is True:
                self._story._properties["nodes"][self._node]["data"][
                    "display"
                ] = display
        return self.display

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(
        self,
        story=None,
        **kwargs,
    ):
        # Add the story to the node
        self._story = story
        self._existing = True
        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", None)

        if not self._is_url:
            # Make an add resource call since it is a file path
            utils.add_resource(self._story, self._path)

            # Create video nodes for file path
            self._create_video_node(caption, alt_text, display)

            # Create resource node for file path
            self._create_resource_node()
        else:
            # Path is a URL, so create an embed node
            self._create_embed_node(caption=caption, alt_text=alt_text)

    # ----------------------------------------------------------------------
    def _create_video_node(self, caption, alt_text, display):
        """
        Create a video node for a file path.
        """
        self._story._properties["nodes"][self._node] = {
            "type": "video",
            "data": {
                "video": self._resource_node,
                "caption": caption or "",
                "alt": alt_text or "",
            },
            "config": {
                "size": display,
            },
        }

    # ----------------------------------------------------------------------
    def _create_resource_node(self):
        """
        Create a resource node for a file path.
        """
        self._story._properties["resources"][self._resource_node] = {
            "type": "video",
            "data": {
                "resourceId": os.path.basename(os.path.normpath(self._path)),
                "provider": "item-resource",
            },
        }

    # ----------------------------------------------------------------------
    def _create_embed_node(self, caption=None, alt_text=None):
        """
        Create an embed node for a URL.
        """
        self._story._properties["nodes"][self._node] = {
            "type": "embed",
            "data": {
                "url": self._path,
                "embedType": "video",
                "caption": caption or "",
                "alt": alt_text or "",
                "display": "inline",
                "aspectRatio": 1.778,
                "addedAsEmbedCode": True,
            },
        }

    # ----------------------------------------------------------------------
    def _update_video(self, new_video):
        # Node structure depends if new_video is a file path or URL

        # Changes are made, and the add video call is done since it's easier than restructuring
        self._path = new_video
        if self._resource_node:
            # If resource node present, remove resource from item.
            resource_id = self._story._properties["resources"][self._resource_node][
                "data"
            ]["resourceId"]
            utils.remove_resource(self._story, resource_id)
            # Remove the resource node since it should not exist for a URL. It will be added back if it's a file path.
            del self._story._properties["resources"][self._resource_node]

        video_scheme = _parse.urlparse(new_video).scheme

        if video_scheme == "https":
            # New video is a URL
            self._is_url = True
            self._resource_node = None
            # Update the node by making the add video call with correct parameters
            self._update_video_url()
        else:
            # If the node was not a file path before, need to create a resource id
            if self._resource_node is None:
                self._resource_node = utils.create_unique_id(resource=True)
            # display depends on self._is_url so get it before
            display = self.display
            self._is_url = False
            # Update the node by making the add video call with correct parameters
            self._update_video_file(display)

    # ----------------------------------------------------------------------
    def _update_video_url(self):
        """
        Update video node with a new URL.
        """
        self._add_to_story(
            caption=self.caption,
            alt_text=self.alt_text,
            story=self._story,
            node_id=self._node,
        )

    # ----------------------------------------------------------------------
    def _update_video_file(self, display):
        """
        Update video node with a new file path.
        """
        self._add_to_story(
            caption=self.caption,
            alt_text=self.alt_text,
            display=display,
            story=self._story,
            node_id=self._node,
            resource_node=self._resource_node,
        )

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Audio:
    """
    This class represents `Audio` content in a Story created from a file.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    path                    Required String. The file path to the audio that will be added.
    ==================      ====================================================================

    """

    def __init__(self, path: str | None = None, **kwargs):

        # Assign audio node properties
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())

        # If the node does not exist yet, create a new instance
        self._existing = self._check_node()
        if self._existing:
            # Get existing resource node
            self._resource_node = self._story._properties["nodes"][self._node]["data"][
                "audio"
            ]
            # Get existing audio path
            self._path = self._story._properties["resources"][self._resource_node][
                "data"
            ]["resourceId"]
        else:
            # Can be created from scratch or already exist in story
            if not path or _parse.urlparse(path).scheme in ["https", "http"]:
                # Audio cannot be added by URL at this time.
                raise ValueError(
                    "To add an audio from an embedded URL, use the Embed content class."
                )
            # Create a new instance
            self._path = path
            self._resource_node = utils.create_unique_id(resource=True)

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Audio(path='{self._path}')"

    def __repr__(self) -> str:
        return str(self)

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get properties for the Audio.

        :return:
            A dictionary depicting the node dictionary and resource
            dictionary for the audio.

            If nothing is returned, make sure the content is part of the story.

        """
        if self._existing is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
                "resource_dict": self._story._properties["resources"][
                    self._resource_node
                ],
            }

    # ----------------------------------------------------------------------
    @property
    def audio(self) -> str:
        """
        Get/Set the audio path.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        audio               String. The new audio path.
        ==================  ========================================

        :return:
            The audio that is being used.
        """
        return self._path

    # ----------------------------------------------------------------------
    @audio.setter
    def audio(self, path: str):
        if _parse.urlparse(path).scheme == "https":
            raise ValueError(
                "To add an audio from an embedded url, use the Embed content class. Update audio with file path only."
            )
        if self._existing is True:
            # Update in the story
            self._update_audio(path)
        else:
            self._path = path

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the audio.

        The Audio must be a part of a story to add a caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Audio.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        else:
            return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption: str):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the audio.

        The Audio must be a part of a story to add alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Audio.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        else:
            return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set display for audio.

        The Audio must be a part of a story to change display.

        Values: `small` | `wide` | float`
        """
        if self._existing is True:
            return self._story._properties["nodes"][self._node]["config"]["size"]

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display: str):
        if self._check_node() is True:
            self._story._properties["nodes"][self._node]["config"]["size"] = display
            return self.display

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(
        self,
        story=None,
        **kwargs,
    ):
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", None)

        # Make an add resource call
        utils.add_resource(self._story, self._path)

        # Create audio nodes
        self._create_audio_node(caption, alt_text, display)

        # Create resource node
        self._create_resource_node()

    # ----------------------------------------------------------------------
    def _create_audio_node(self, caption, alt_text, display):
        """
        Create an audio node in the story.
        """
        self._story._properties["nodes"][self._node] = {
            "type": "audio",
            "data": {
                "audio": self._resource_node,
                "caption": caption or "",
                "alt": alt_text or "",
            },
            "config": {"size": display},
        }

    # ----------------------------------------------------------------------
    def _create_resource_node(self):
        """
        Create a resource node for the audio.
        """
        self._story._properties["resources"][self._resource_node] = {
            "type": "audio",
            "data": {
                "resourceId": os.path.basename(os.path.normpath(self._path)),
                "provider": "item-resource",
            },
        }

    # ----------------------------------------------------------------------
    def _update_audio(self, new_audio):
        """
        Update an audio node in the story with a new audio file.

        Parameters:
        - new_audio: The new audio file path.
        """
        # Assign new path
        self._path = new_audio

        # Assign new resource id, get old one to delete resource
        resource_id = self._story._properties["resources"][self._resource_node]["data"][
            "resourceId"
        ]
        self._story._properties["resources"][self._resource_node]["data"][
            "resourceId"
        ] = os.path.basename(os.path.normpath(self._path))

        # Add new resource and remove old one
        utils.add_resource(self._story, self._path)
        utils.remove_resource(self._story, resource_id)

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Embed:
    """
    Class representing `Embed` content in a Storymap or Briefing. This is either a webpage, video, or audio embed.
    Embed will show as a card in the story.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    path                    Required String. The url that will be added as a webpage, video, or
                            audio embed into the story.
    ==================      ====================================================================
    """

    def __init__(self, path: str | None = None, **kwargs):
        # Can be created from scratch or already exist in story
        # Embed is not an immersive node
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # If node doesn't already exist, create new instance
        self._existing = self._check_node()
        if self._existing is True:
            # Get the link path
            self._path = self._story._properties["nodes"][self._node]["data"]["url"]

            # check if offline dependent
            if "dependents" in self._story._properties["nodes"][self._node]:
                self._offline_dependent = self._story._properties["nodes"][self._node][
                    "dependents"
                ]["offline"]
        else:
            # Create new instance, notice no resource node is needed for embed
            self._path = path
        self._offline_dependent = None

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Embed(link='{self.link}')"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get properties for the Embed.

        .. note::
            To change various properties of the Embed use the other property setters.

        :return:
            A dictionary depicting the node dictionary for the embed.
            If nothing is returned, make sure the content is part of the story.
        """
        if self._existing is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
            }

    # ----------------------------------------------------------------------
    @property
    def offline_media(self):
        """
        Get/Set the offline media property for the embed.

        The Embed must be a part of a story to add offline media.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        offline_media       Image or Video. The new offline_media for the Embed.
        ==================  ========================================

        :return:
            The offline media that is being used.
        """
        if self._existing:
            if self._offline_dependent:
                return utils.assign_node_class(
                    story=self._story, node_id=self._offline_dependent
                )
        return None

    # ----------------------------------------------------------------------
    @offline_media.setter
    def offline_media(self, value: Image | Video):
        if self._existing:
            # can only set for briefing
            if isinstance(self._story, sm_module.Briefing):
                if isinstance(value, Image) or isinstance(value, Video):
                    value._add_to_story(story=self._story)
                    self._story._properties["nodes"][self._node]["dependents"] = {
                        "offline": value._node
                    }
                    self._offline_dependent = value._node
                else:
                    raise ValueError("offline_media must be an Image or Video")
            else:
                raise ValueError("offline_media can only be set for a Briefing")
        else:
            raise ValueError(
                "offline_media can only be set for an Embed that has been added to a Briefing."
            )

    # ----------------------------------------------------------------------
    @property
    def link(self) -> str:
        """
        Get/Set the link property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        link                String. The new url for the Embed.
        ==================  ========================================

        :return:
            The embed that is being used.
        """
        return self._path

    # ----------------------------------------------------------------------
    @link.setter
    def link(self, path: str):
        self._path = path
        if self._existing is True:
            self._update_link(path)

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the webpage.

        The Embed must be a part of a story to add a caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Embed.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        else:
            return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption: str):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the embed.

        The Embed must be a part of a story to add alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Embed.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        else:
            return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set display for embed.

        The Embed must be a part of a story to change display.

        Values: `card` | `inline`
        """
        if self._existing is True:
            return self._story._properties["nodes"][self._node]["data"]["display"]

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display: str):
        if self._existing:
            self._story._properties["nodes"][self._node]["data"]["display"] = display

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", "card")

        sections = _parse.urlparse(self._path)
        # Create embed node, no resource node needed
        self._create_link_node(caption, alt_text, display, sections)

    # ----------------------------------------------------------------------
    def _create_link_node(self, caption, alt_text, display, sections):
        """
        Create a link node in the story.
        """
        self._story._properties["nodes"][self._node] = {
            "type": "embed",
            "data": {
                "url": self._path,
                "embedType": "link",
                "title": sections.netloc,
                "description": caption or "",
                "providerUrl": sections.netloc,
                "alt": alt_text or "",
                "display": display or "inline",
                "embedSrc": self._path,
            },
        }

    # ----------------------------------------------------------------------
    def _update_link(self, new_link):
        # check new link has http or https
        if _parse.urlparse(new_link).scheme not in ["https", "http"]:
            new_link = "https://" + new_link
        # parse new url
        sections = _parse.urlparse(new_link)
        # set new path
        self._path = new_link
        # update dictionary properties
        self._story._properties["nodes"][self._node]["data"]["url"] = self._path
        self._story._properties["nodes"][self._node]["data"]["embedSrc"] = self._path
        self._story._properties["nodes"][self._node]["data"]["title"] = sections.netloc
        self._story._properties["nodes"][self._node]["data"][
            "providerUrl"
        ] = sections.netloc

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class App(Embed):
    """
    Integrating other ArcGIS apps into stories and briefings can enrich your geospatial storytelling with tools that
    offer specialized functionality. Whether you're crowdsourcing field data using ArcGIS Survey123, presenting
    location-based analytics with ArcGIS Dashboards, sharing interactive maps using ArcGIS Instant Apps, or
    immersing your readers in a scene with ArcGIS Experience Builder, adding an app can dynamically enhance your
    readers' understanding and bridge the gap between storytelling and decision-making.
    """

    def __init__(self, item: arcgis.gis.Item | None = None, **kwargs):
        super().__init__(**kwargs)
        if self._existing:
            self._resource_node = self._story._properties["nodes"][self._node][
                "data"
            ].get("embedResourceId")
            item_id = self._story._properties["resources"][self._resource_node][
                "data"
            ].get("itemId")
            self._resource_item = (
                arcgis.env.active_gis.content.get(item_id) if item_id else None
            )
        else:
            if item is None:
                raise ValueError(
                    "An ArcGIS Item must be provided to create an App instance."
                )
            self._resource_node = utils.create_unique_id(resource=True)
            self._resource_item = item

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"App(item='{self._resource_item}')"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def item(self) -> arcgis.gis.Item:
        """
        Get the ArcGIS Item associated with this App.

        :return:
            The ArcGIS Item that is being used.
        """
        return self._resource_item

    # ----------------------------------------------------------------------
    @item.setter
    def item(self, item: arcgis.gis.Item):
        if self._existing is True:
            self._update_item(item)
        else:
            self._resource_item = item

    # ----------------------------------------------------------------------
    def _update_item(self, new_item: arcgis.gis.Item):
        self._resource_item = new_item
        item_id = new_item.id
        self._story._properties["resources"][self._resource_node]["data"][
            "itemId"
        ] = item_id

    # ----------------------------------------------------------------------
    @property
    def use_smart_embed(self) -> bool:
        """
        Get/Set whether to use smart embed for the ArcGIS App.

        :return:
            A boolean indicating whether smart embed is used.
        """
        if self._existing is True:
            return self._story._properties["nodes"][self._node]["data"].get(
                "useSmartEmbed", True
            )
        return True

    # ----------------------------------------------------------------------
    @use_smart_embed.setter
    def use_smart_embed(self, value: bool):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"][
                "useSmartEmbed"
            ] = value

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        display = kwargs.pop("display", "card")

        sections = _parse.urlparse(self._resource_item.url)
        # Create embed node, no resource node needed
        self._create_app_node(caption, display, sections)

        # Create resource node
        self._create_resource_node()

    # ----------------------------------------------------------------------
    def _create_app_node(self, caption, display, sections):
        """
        Create a link node in the story.
        """
        self._story._properties["nodes"][self._node] = {
            "type": "embed",
            "data": {
                "url": self._resource_item.url,
                "embedType": "link",
                "title": self._resource_item.title,
                "providerUrl": sections.netloc,
                "caption": caption or self._resource_item.description or "",
                "display": display or "inline",
                "embedSrc": self._resource_item.url,
                "embedResourceId": self._resource_node,
                "useSmartEmbed": True,
                "isEmbedSupported": True,
                "allowSmallEmbeds": True,
            },
        }

    # ----------------------------------------------------------------------
    def _create_resource_node(self):
        """
        Create a resource node for the ArcGIS App.
        """
        self._story._properties["resources"][self._resource_node] = {
            "type": "portal-item",
            "data": {
                "itemId": self._resource_item.id,
                "itemType": self._resource_item.type,
            },
        }


###############################################################################################################
class Map:
    """
    Class representing a `webmap` or `webscene` for the story.

    =================       ====================================================================
    **Parameter**            **Description**
    -----------------       --------------------------------------------------------------------
    item                    An Item of type :class:`~arcgis.map.Map` or
                            :class:`~arcgis.map.Scene`.
    =================       ====================================================================
    """

    def __init__(self, item: arcgis.gis.Item | None = None, **kwargs):
        try:
            _imports.get_arcgis_map_mod(True)
        except Exception as e:
            warnings.warn(
                f"Failed to import arcgis.map module: {e}. This module is needed to work with the Map class."
            )
        # Can be created from scratch or already exist in story
        # Map is not an immersive node
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._existing = self._check_node()

        if self._existing:
            self._initialize_from_existing()
        else:
            self._initialize_from_new(item)

    # ----------------------------------------------------------------------
    def _initialize_from_existing(self):
        self._resource_node = self._story._properties["nodes"][self._node]["data"][
            "map"
        ]
        self._path = self._resource_node[2:]

        rdata = self._story._properties["resources"][self._resource_node]["data"]
        ndata = self._story._properties["nodes"][self._node]["data"]

        self._map_layers = ndata.get("mapLayers", rdata.get("mapLayers"))
        self._extent = ndata.get("extent", rdata.get("extent", {}))
        self._center = ndata.get("center", rdata.get("center"))
        self._viewpoint = ndata.get(
            "viewpoint",
            rdata.get("viewpoint", {"rotation": 0, "scale": -1, "targetGeometry": {}}),
        )
        self._zoom = ndata.get("zoom", rdata.get("zoom", 2))

        self._type = rdata["itemType"]
        if self._type == "Web Scene":
            self._lighting_date = self._story._properties["resources"][
                self._resource_node
            ]["data"]["lightingDate"]

        # check if offline dependents exist
        if "dependents" in self._story._properties["nodes"][self._node]:
            self._offline_dependent = self._story._properties["nodes"][self._node][
                "dependents"
            ]["offline"]
        else:
            self._offline_dependent = None

    # ----------------------------------------------------------------------
    def _initialize_from_new(self, item):
        item_id = (
            item.id
            if isinstance(item, arcgis.gis.Item)
            else arcgis.env.active_gis.content.get(item).id
        )
        self._resource_node = "r-" + item_id
        self._path = item_id
        self._offline_dependent = None

        if item.type == "Web Map":
            self._initialize_web_map(item)
        elif item.type == "Web Scene":
            self._initialize_web_scene(item)
        else:
            raise ValueError("Item must be of Type Web Map or Web Scene")

    # ----------------------------------------------------------------------
    def _initialize_web_map(self, item):
        map_item = arcgis_map.Map(item=item)
        self._type = item.type
        self._extent = map_item.extent
        self._center = (
            map_item.center
            if map_item.center
            else {
                "spatialReference": dict(self._extent["spatialReference"]),
                "x": (self._extent["xmin"] + self._extent["xmax"]) / 2,
                "y": (self._extent["ymin"] + self._extent["ymax"]) / 2,
            }
        )
        self._zoom = map_item.zoom
        self._viewpoint = {
            "rotation": map_item.rotation,
            "scale": map_item.scale,
            "targetGeometry": self._center,
        }
        self._map_layers = self._create_layer_dictionary(
            map_item._webmap.operational_layers
        )

    # ----------------------------------------------------------------------
    def _initialize_web_scene(self, item):
        map_item = arcgis_map.Scene(item=item)
        self._type = item.type
        self._map_layers = self._create_layer_dictionary(
            map_item._webscene.operational_layers
        )
        self._extent = None
        self._center = map_item._webscene.initial_state.viewpoint.camera.position.dict()
        self._zoom = map_item.zoom
        self._viewpoint = map_item._webscene.initial_state.viewpoint.dict()
        self._camera = map_item._webscene.initial_state.viewpoint.camera.dict()

    # ----------------------------------------------------------------------
    def _create_layer_dictionary(self, layers):
        return [
            {
                "id": layer.id,
                "title": layer.title,
                "visible": layer.visibility,
            }
            for layer in layers
        ]

    # ----------------------------------------------------------------------
    def __str__(self):
        return f"Map(item='{self._path}', type='{self._type}')"

    def __repr__(self):
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get properties for the Map.

        :return:
            A dictionary depicting the node dictionary and resource
            dictionary for the map. The resource dictionary depicts the
            original map settings. The node dictionary depicts the current map settings.
            If nothing it returned, make sure the content is part of the story.

        .. note::
            To change various properties of the Map use the other property setters.
        """
        if self._check_node() is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
                "resource_dict": self._story._properties["resources"][
                    self._resource_node
                ],
            }

    # ----------------------------------------------------------------------
    @property
    def map(self) -> arcgis.gis.Item:
        """
        Get/Set the map property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        map                 One of three choices:

                            * String being an item id for an Item of type
                            :class:`~arcgis.map.Map`
                            or :class:`~arcgis.map.Scene`.

                            * An :class:`~arcgis.gis.Item` of type
                            :class:`~arcgis.map.Map`
                            or :class:`~arcgis.map.Scene`.
        ==================  ========================================

        .. note::
            Only replace a Map with a new map of same type. Cannot replace a
            2D map with 3D.

        :return:
            The item id for the map that is being used.
        """
        if self._story:
            return self._story._gis.content.get(self._path)
        else:
            gis = arcgis.env.active_gis
            return gis.content.get(self._path)

    # ----------------------------------------------------------------------
    @map.setter
    def map(self, map: str | arcgis.gis.Item):
        if self._existing is True:
            self._update_map(map)
        else:
            self._initialize_from_new(map)

    # ----------------------------------------------------------------------
    @property
    def map_layers(self):
        """
        Get the map layers present.
        :return:
            The map layers that are being used.
        """
        return self._map_layers

    # ----------------------------------------------------------------------
    def update_map_layers(self, layer_id: str | int, visible: bool):
        """
        Update the visibility of the map layers.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        layer_id            Required String or integer index. The id of the layer to update. You can find the id in the map layers property.
        ------------------  ----------------------------------------
        visible             Required Boolean. True if the layer should be visible, False otherwise.
        ==================  ========================================

        :return:
            The updated map layers that are being used.
        """
        if self._existing is True:
            for i, layer in enumerate(
                self._story._properties["resources"][self._resource_node]["data"][
                    "mapLayers"
                ]
            ):
                if layer["id"] == layer_id:
                    self._story._properties["resources"][self._resource_node]["data"][
                        "mapLayers"
                    ][i]["visible"] = visible
                    break
        self._map_layers = self._story._properties["resources"][self._resource_node][
            "data"
        ]["mapLayers"]
        return self._map_layers

    # ----------------------------------------------------------------------
    @property
    def viewpoint(self) -> dict:
        """Get the viewpoint of the map. To change the viewpoint use the `set_viewpoint` method."""
        return self._viewpoint

    # ----------------------------------------------------------------------
    def set_viewpoint(self, extent: dict = None, scale: Scales = None) -> dict:
        """
        Set the extent and/or scale for the map in the story.

        If you have an extent to use from a bookmark,
        find this extent by using the `bookmarks` property in
        the :class:`~arcgis.map.Map` Class.
        The `map` property on this class will return the Web Map
        Item being used. By passing this item into
        the :class:`~arcgis.map.Map` Class you can retrieve a list of all
        bookmarks and their extents with the `bookmarks` property.

        To see the current viewpoint call the `properties` property on the Map
        node.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        extent              Optional dictionary representing the extent of
                            the map. This will update the extent, center and viewpoint
                            accordingly.

                            Example:
                                {'spatialReference': {'latestWkid': 3857, 'wkid': 102100},
                                'xmin': -609354.6306080809,
                                'ymin': 2885721.2797636474,
                                'xmax': 6068184.160383142,
                                'ymax': 6642754.094035632}
        ------------------  ----------------------------------------
        scale               Optional Scales enum class value or dict with 'scale' and 'zoom' keys.

                            Scale is a unit-less way of describing how any distance on the map translates
                            to a real-world distance. For example, a map at a 1:24,000 scale communicates that 1 unit
                            on the screen represents 24,000 of the same unit in the real world.
                            So one inch on the screen represents 24,000 inches in the real world.
        ==================  ========================================

        :return: The current viewpoint dictionary
        """
        # Ensure existing viewpoint information is initialized
        self._initialize_viewpoint()

        change_made = False

        # Set new extent if specified
        if extent:
            self._update_extent_and_viewpoint(extent)
            change_made = True

        # Set new scale if specified
        if scale:
            self._update_scale(scale)
            change_made = True
        if self._existing is True and change_made:
            # Once the update is made, remove the original information from resources
            self._update_resource_data(
                rdata_dict=self._story._properties["resources"][self._resource_node][
                    "data"
                ]
            )

            return self._viewpoint

    # ----------------------------------------------------------------------
    def _initialize_viewpoint(self):
        # Initialize viewpoint information if not present
        if (
            self._existing
            and "viewpoint" not in self._story._properties["nodes"][self._node]["data"]
        ):
            self._story._properties["nodes"][self._node]["data"]["viewpoint"] = {
                "rotation": 0,
                "scale": -1,
                "targetGeometry": {},
            }

        if self._viewpoint is None:
            self._viewpoint = {
                "rotation": 0,
                "scale": -1,
                "targetGeometry": {},
            }

    # ----------------------------------------------------------------------
    def _calculate_z_value(self, scale: int = None):
        import math

        # Calculate the camera height (z-coordinate)
        # We assume a 45-degree field of view vertically
        fov = 45  # degrees
        fov_radians = math.radians(fov)

        # Calculate camera height based on meters per pixel
        z_value = scale / (2 * math.tan(fov_radians / 2))

        return z_value

    # ----------------------------------------------------------------------
    def _update_extent_and_viewpoint(self, extent):

        # check extent
        if not all(k in extent for k in ("xmin", "xmax", "ymin", "ymax")):
            raise ValueError(
                "Extent dictionary missing one or more of these keys: 'xmin', 'xmax', 'ymin', 'ymax'"
            )

        # create center
        center_x = (extent["xmin"] + extent["xmax"]) / 2
        center_y = (extent["ymin"] + extent["ymax"]) / 2
        new_center = {
            "spatialReference": extent.get("spatialReference", {"wkid": 4326}),
            "x": center_x,
            "y": center_y,
        }
        # get z if web scene
        if self._type == "Web Scene":
            # Need to account for z value
            if "zmin" and "zmax" in extent:
                center_z = (extent["zmin"] + extent["zmax"]) / 2
            else:
                # z based on scale
                center_z = self._calculate_z_value(self._viewpoint["scale"])
            new_center["z"] = center_z
            self._center = new_center
            self._viewpoint["camera"]["position"] = new_center

        # set the extent and target geom
        self._extent = extent
        self._viewpoint["targetGeometry"] = new_center

        if self._existing is True:
            # In order to correctly edit, the viewpoint, extent, and center must be updated.
            # update extent
            self._story._properties["nodes"][self._node]["data"]["extent"] = extent

            if self._type == "Web Map":
                self._story._properties["nodes"][self._node]["data"][
                    "center"
                ] = new_center
            else:
                self._story._properties["nodes"][self._node]["data"][
                    "center"
                ] = new_center
                # update the camera with the new center
                self._story._properties["nodes"][self._node]["data"]["viewpoint"][
                    "camera"
                ]["position"] = new_center
            # update viewpoint
            self._story._properties["nodes"][self._node]["data"]["viewpoint"][
                "targetGeometry"
            ] = new_center

    # ----------------------------------------------------------------------
    def _update_scale(self, scale):
        # Update scale and zoom

        # get the scale value if enum
        scale_value = (
            scale.value["scale"] if isinstance(scale, Scales) else scale["scale"]
        )
        # set viewpoint scale and zoom on class
        self._viewpoint["scale"] = scale_value
        self._zoom = scale.value.get("zoom") or scale.get("zoom", None)

        # update z value if web scene on class values
        if self._type == "Web Scene":
            new_z = self._calculate_z_value(scale_value)
            self._viewpoint["camera"]["position"]["z"] = new_z
            self._viewpoint["targetGeometry"]["z"] = new_z
            self._center["z"] = new_z

        # updates made in story structure
        if self._existing is True:
            # set in story
            self._story._properties["nodes"][self._node]["data"]["viewpoint"][
                "scale"
            ] = scale_value
            self._story._properties["nodes"][self._node]["data"]["zoom"] = (
                scale.value.get("zoom") or scale.get("zoom", None)
            )

            if self._type == "Web Scene":
                # update the z value if we have a web scene
                self._story._properties["nodes"][self._node]["data"]["viewpoint"][
                    "camera"
                ]["position"]["z"] = new_z
                self._story._properties["nodes"][self._node]["data"]["viewpoint"][
                    "targetGeometry"
                ]["z"] = new_z
                self._story._properties["nodes"][self._node]["data"]["center"][
                    "z"
                ] = new_z

    # ----------------------------------------------------------------------
    def _update_resource_data(self, rdata_dict):
        # Remove the original information from resources
        # Once the update made, remove the original information from resources so
        # that the new information is used.
        rdata_dict.pop("extent", None)
        rdata_dict.pop("center", None)
        rdata_dict.pop("viewpoint", None)
        rdata_dict.pop("zoom", None)
        rdata_dict["type"] = "minimal"
        self._story._properties["resources"][self._resource_node]["data"] = rdata_dict

    # ----------------------------------------------------------------------
    @property
    def show_legend(self) -> bool:
        """Get/Set the showing legend toggle. True if enabled and False if disabled"""
        if self._existing is True:
            if (
                "isShowingLegend"
                in self._story._properties["nodes"][self._node]["data"]
            ):
                return self._story._properties["nodes"][self._node]["data"][
                    "isShowingLegend"
                ]
        return False

    # ----------------------------------------------------------------------
    @show_legend.setter
    def show_legend(self, value: bool):
        self._story._properties["nodes"][self._node]["data"]["isShowingLegend"] = value

    # ----------------------------------------------------------------------
    @property
    def legend_pinned(self) -> bool:
        """
        Get/Set the legend pinned toggle. True if enabled and False if disabled.

        .. note::
            If set to True, make sure `show_legend` is also True. Otherwise, you will not
            see the legend pinned.
        """
        if self._existing is True:
            if "legendPinned" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"][
                    "legendPinned"
                ]
        return False

    # ----------------------------------------------------------------------
    @legend_pinned.setter
    def legend_pinned(self, value: bool):
        self._story._properties["nodes"][self._node]["data"]["legendPinned"] = value

    # ----------------------------------------------------------------------
    @property
    def show_search(self) -> bool:
        """Get/Set the search toggle. True if enabled and False if disabled"""
        if self._existing is True:
            if "search" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["search"]
        return False

    # ----------------------------------------------------------------------
    @show_search.setter
    def show_search(self, value: bool):
        self._story._properties["nodes"][self._node]["data"]["search"] = value

    # ----------------------------------------------------------------------
    @property
    def time_slider(self) -> bool:
        """Get/Set the time slider toggle. True if enabled and False if disabled"""
        if self._existing is True:
            if "timeSlider" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"][
                    "timeSlider"
                ]
        return False

    # ----------------------------------------------------------------------
    @time_slider.setter
    def time_slider(self, value: bool):
        self._story._properties["nodes"][self._node]["data"]["timeSlider"] = value

    # ----------------------------------------------------------------------
    @property
    def pinned_popup(self):
        """
        Get/Set the pinned popup. You must know the layer id and the featureId name and value that represents
        the popup you want to pin. You can find the layer id by looking at the `map_layers` property.

        This is considered a more advance workflow as you must know the layer data to pin the popup.

        ==================  ================================================
        **Parameter**        **Description**
        ------------------  ------------------------------------------------
        pinned_popup_info   The new pinned popup info for the Map. This is a
                            dictionary containing the following keys:
                            - `layerId`: String. The layer id of the feature layer. You can find this value in the `map_layers` property.
                            - `idFieldName`: String. The field name that represents the id of the feature.
                            - `idFieldValue`: Integer. The id of the feature you want to show.

                            Example:
                                | {
                                |   "layerId": "0",
                                |   "idFieldName": "OBJECTID",
                                |   "idFieldValue": 1
                                | }

                            If you want to remove the pinned popup, set this to None.
        ==================  ================================================
        """
        if self._existing is True:
            if (
                "pinnedPopupInfo"
                in self._story._properties["nodes"][self._node]["data"]
            ):
                return self._story._properties["nodes"][self._node]["data"][
                    "pinnedPopupInfo"
                ]
        return None

    # ----------------------------------------------------------------------
    @pinned_popup.setter
    def pinned_popup(self, value: dict | None):
        # Check if the dictionary has the correct keys
        if value is None:
            self._story._properties["nodes"][self._node]["data"].pop(
                "pinnedPopupInfo", None
            )
        elif all(k in value for k in ("layerId", "idFieldName", "idFieldValue")):
            self._story._properties["nodes"][self._node]["data"][
                "pinnedPopupInfo"
            ] = value

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the map.

        The Map must be a part of a story to add a caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Map.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption: str):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the map.

        The Map must be a part of a story to add alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Map.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set the display type of the map.

        The Map must be a part of a story to change display.

        Values: `standard` | `wide` | `full` | `float right` | `float left`
        """
        if self._existing is True:
            if "config" in self._story._properties["nodes"][self._node]:
                return self._story._properties["nodes"][self._node]["config"]["size"]
        return None

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display: str):
        if self._existing is True:
            if "float" in display.lower():
                self._story._properties["nodes"][self._node]["config"]["size"] = "float"
                if "right" in display.lower():
                    self._story._properties["nodes"][self._node]["config"][
                        "floatAlignment"
                    ] = "end"
                else:
                    self._story._properties["nodes"][self._node]["config"][
                        "floatAlignment"
                    ] = "start"
            else:
                self._story._properties["nodes"][self._node]["config"][
                    "size"
                ] = display.lower()
                self._story._properties["nodes"][self._node]["config"].pop(
                    "floatAlignment", None
                )

    # ----------------------------------------------------------------------
    @property
    def popup_docked(self) -> bool:
        """
        Get/Set the popup docked toggle. True if enabled and False if disabled.
        """
        if self._existing is True:
            if "popupDocked" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"][
                    "popupDocked"
                ]
        return False

    # ----------------------------------------------------------------------
    @popup_docked.setter
    def popup_docked(self, value: bool):
        self._story._properties["nodes"][self._node]["data"]["popupDocked"] = value

    # ----------------------------------------------------------------------
    @property
    def offline_media(self):
        """
        Get/Set the offline media. This is an alternative version of this media
        for offline viewing using the ArcGIS StoryMaps Briefings app.

        .. note::
            This property is only available for ArcGIS StoryMaps Briefings and
            the map must be part of the Briefing before setting this property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        offline_media       The new offline media for the Map or Scene.
                            This can either be the item of
                            a Mobile Map Package or Mobile Scene Package or it
                            can be an item of type Image or Video from Story Contents.
        ==================  ========================================

        :return: The offline media that is being used. If None then no offline media is being used.
        """
        # find the type of dependent based on the type of the dependent
        # either an Image, Video, or ArcGIS Item.
        if self._existing is True:
            if self._offline_dependent:
                # Find it in the story
                node = self._story._properties["nodes"][self._offline_dependent]
                # Find the type of dependent
                if node["type"] in ["image", "video"]:
                    return utils.assign_node_class(
                        story=self._story, node_id=self._offline_dependent
                    )
                else:
                    # Find the itemId of the dependent
                    resource = self._story._properties["resources"][
                        node["data"]["package"]
                    ]
                    item_id = resource["data"]["itemId"]
                    return self._story._gis.content.get(item_id)
        return None

    # ----------------------------------------------------------------------
    @offline_media.setter
    def offline_media(self, value: arcgis.gis.Item | Image | Video):
        if self._existing:
            if not isinstance(self._story, sm_module.Briefing):
                raise ValueError("offline_media can only be set for a Briefing")
            if isinstance(value, arcgis.gis.Item):
                # check if item is a MMPK or MSPK
                if value.type in ["Mobile Map Package", "Mobile Scene Package"]:
                    # create new node
                    self._create_offline_node(value)
                    # update dependent
                    self._story._properties["nodes"][self._node]["dependents"] = {
                        "offline": self._offline_dependent
                    }
                else:
                    raise ValueError(
                        "Item must be of type Mobile Map Package or Mobile Scene Package"
                    )
            elif isinstance(value, Image) or isinstance(value, Video):
                value._add_to_story(story=self._story)
                self._offline_dependent = value._node
                # update dependent
                self._story._properties["nodes"][self._node]["dependents"] = {
                    "offline": self._offline_dependent
                }
            else:
                raise ValueError("Value must be an Item, Image, or Video")

    # ----------------------------------------------------------------------
    def _create_offline_node(self, item):
        """
        Create an offline node in the story.
        """
        self._offline_dependent = utils.create_unique_id()
        self._story._properties["nodes"][self._offline_dependent] = {
            "type": "mobile-package",
            "data": {
                "package": "r-" + item.id,
                "title": item.title,
            },
        }
        self._story._properties["resources"]["r-" + item.id] = {
            "type": "portal-item",
            "data": {
                "itemId": item.id,
                "itemType": item.type,
            },
        }

    # ----------------------------------------------------------------------
    def delete(self):
        """
        Delete the Map from the Storymap or Briefing.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", None)

        # Add WebMap nodes
        self._add_map_nodes(caption, alt_text, display)

        # Add resource node
        self._add_map_resource()

    # ----------------------------------------------------------------------
    def _add_map_nodes(self, caption, alt_text, display):
        """Add WebMap nodes to the story."""
        self._story._properties["nodes"][self._node] = {
            "type": "webmap",
            "data": {
                "map": self._resource_node,
                "caption": caption or "",
                "alt": alt_text or "",
            },
            "config": {"size": display},
        }

    # ----------------------------------------------------------------------
    def _add_map_resource(self):
        """Add resource node for the WebMap."""
        self._story._properties["resources"][self._resource_node] = {
            "type": "webmap",
            "data": {
                "extent": self._extent,
                "center": self._center,
                "zoom": self._zoom,
                "mapLayers": self._map_layers,
                "viewpoint": self._viewpoint,
                "itemId": self._path,
                "itemType": self._type,
                "type": "minimal",
            },
        }

        # Additional updates for Web Scene
        if self._type == "Web Scene":
            self._add_web_scene_updates()

    # ----------------------------------------------------------------------
    def _add_web_scene_updates(self):
        """Additional updates for Web Scene (3D Map)."""
        self._story._properties["resources"][self._resource_node]["data"][
            "camera"
        ] = self._camera
        self._story._properties["nodes"][self._node]["data"]["camera"] = self._camera

    # ----------------------------------------------------------------------
    def _update_map(self, new_map):
        _imports.get_arcgis_map_mod(True)
        # Check for error.
        if (
            self._type
            != self._story._properties["resources"][self._resource_node]["data"][
                "itemType"
            ]
        ):
            raise ValueError("New Map must be of the same type as the existing map.")

        # Update resource node and dictionary properties
        self._replace_resource_node(new_map)

        # Extra necessary updates for Web Scene (3D Map)
        if self._type == "Web Scene":
            self._update_web_scene_properties(new_map)

    # ----------------------------------------------------------------------
    def _replace_resource_node(self, new_map):
        """Replace the existing resource node with the new map's resource node."""
        self._story._properties["resources"][new_map._resource_node] = (
            self._story._properties["resources"].pop(self._resource_node)
        )
        self._resource_node = new_map._resource_node
        self._add_web_scene_updates(new_map)

    # ----------------------------------------------------------------------
    def _update_node_dictionary(self, new_map):
        """Update path to resource node in the node dictionary."""
        self._story._properties["nodes"][self._node]["data"][
            "map"
        ] = new_map._resource_node

    # ----------------------------------------------------------------------
    def _update_web_scene_properties(self, new_map):
        """Update additional properties for Web Scene (3D Map)."""
        self._story._properties["resources"][self._resource_node]["data"][
            "camera"
        ] = new_map._camera
        self._story._properties["nodes"][self._node]["data"]["camera"] = new_map._camera

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Text:
    """
    Class representing `Text` in a Storymap or Briefing. Text can be of different styles and sizes.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    text                    Required String. The text that will be shown in the story.

                            .. code-block:: python

                                # Usage Example for paragraph:

                                >>> text = Text('''Paragraph with <strong>bold</strong>, <em>italic</em>
                                                and <a href=\"https://www.google.com\" rel=\"noopener noreferrer\"
                                                target=\"_blank\">hyperlink</a> and a <span
                                                class=\"sm-text-color-080\">custom color</span>''')

                                # Usage Example for numbered list:

                                >>> text = Text("<li>List Item1</li> <li>List Item2</li> <li>List Item3</li>")

                                # Usage Example to link item in org:
                                >>> text = Text("<span data-action-type="attachment-action" id="a-CmrIH8">Testing Linked Item Text</span>", style = TextStyles.PARAGRAPH)

    ------------------      --------------------------------------------------------------------
    style                   Optional TextStyles type. There are 7 different styles of text that can be
                            added to a story.

                            Values: PARAGRAPH | NUMBERLIST | BULLETLIST |
                            HEADING1 | HEADING2 | HEADING3 | QUOTE
    ------------------      --------------------------------------------------------------------
    custom_color            Optional String. The hex color value without the #.
                            Only available when type is either 'paragraph', 'bullet-list', or
                            'numbered-list'.


                            Ex: custom_color = "080"
    -------------------     --------------------------------------------------------------------
    size                    Optional String. Used for 'paragraph', 'bullet-list', or 'numbered-list'.
                            The size of the text. For a Storymap it can be 'large' or 'medium'.
                            For a Briefing it can be 'large', 'medium', or 'small'.
    ==================      ====================================================================


    Properties of the different text types:

    ===================     ====================================================================
    **Type**                **Text**
    -------------------     --------------------------------------------------------------------
    paragraph               String can contain the following tags for text formatting:
                            <strong>, <em>, <a href="{link}" rel="noopener noreferer" target="_blank"
                            and a class attribute to indicate color formatting:
                            class=sm-text-color-{values} attribute in the <strong> | <em> | <a> | <span> tags

                            Values: `themeColor1` | `themeColor2` | `themeColor3` | `customTextColors`
    -------------------     --------------------------------------------------------------------
    heading                 String can only contain <em> tag
    -------------------     --------------------------------------------------------------------
    subheading              String can only contain <em> tag
    -------------------     --------------------------------------------------------------------
    bullet-list             String can contain the following tags for text formatting:
                            <strong>, <em>, <a href="{link}" rel="noopener noreferer" target="_blank"
                            and a class attribute to indicate color formatting:
                            class=sm-text-color-{values} attribute in the <strong> | <em> | <a> | <span> tags

                            Values: `themeColor1` | `themeColor2` | `themeColor3` | `customTextColors`
    -------------------     --------------------------------------------------------------------
    numbered-list           String can contain the following tags for text formatting:
                            <strong>, <em>, <a href="{link}" rel="noopener noreferer" target="_blank"
                            and a class attribute to indicate color formatting:
                            class=sm-text-color-{values} attribute in the <strong> | <em> | <a> | <span> tags

                            Values: `themeColor1` | `themeColor2` | `themeColor3` | `customTextColors`
    -------------------     --------------------------------------------------------------------
    quote                   String can only contain <strong> and <em> tags
    ===================     ====================================================================

    """

    def __init__(
        self,
        text: str | None = None,
        style: TextStyles = TextStyles.PARAGRAPH,
        color: str = None,
        size: str = None,
        **kwargs,
    ):
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())

        self._existing = self._check_node()
        if self._existing is True:
            self._text = self._story._properties["nodes"][self._node]["data"]["text"]
            self._style = self._story._properties["nodes"][self._node]["data"]["type"]
            self._size = (
                self._story._properties["nodes"][self._node]["data"]["textSize"]
                if "textSize" in self._story._properties["nodes"][self._node]["data"]
                else None
            )
        else:
            self._text = text

            if isinstance(style, TextStyles):
                self._style = style.value
            else:
                raise ValueError("Invalid style. Please use a valid TextStyles value.")

            # Color only applies to certain styles
            if self._style in [
                "paragraph",
                "bullet-list",
                "numbered-list",
            ]:
                self._color = color
            else:
                self._color = None

            # Size only applies to certain styles
            if self._style in [
                "paragraph",
                "bullet-list",
                "numbered-list",
            ]:
                self._size = size
            else:
                self._size = None

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Text(text={self._text or ''})"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get the properties for the text.

        :return:
            The Text dictionary for the node.
            If nothing is returned, make sure the content is part of the story.
        """
        if self._existing is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
            }

    # ----------------------------------------------------------------------
    @property
    def text(self) -> str:
        """
        Get/Set the text itself for the text node.

        ==================  ==================================================
        **Parameter**        **Description**
        ------------------  --------------------------------------------------
        text                Optional String. The new text to be displayed.
        ==================  ==================================================

        :return:
            The text for the node.
            If nothing is returned, make sure the content is part of the story.
        """
        return self._text

    # ----------------------------------------------------------------------
    @text.setter
    def text(self, text: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["text"] = text
        self._text = text

    # ----------------------------------------------------------------------
    @property
    def size(self):
        """
        Get/Set the size for the text node.

        ==================  ==================================================
        **Parameter**        **Description**
        ------------------  --------------------------------------------------
        size                Optional String. The new size to be displayed.
                            Applicable for Paragraph, Bullet List, and Numbered List.

                            Values: `small` | `medium` | `large`

                            .. note::
                                "small" can only be used in a Briefing.
        ==================  ==================================================

        :return:
            The size for the node.
            If nothing is returned, make sure the content is part of the story.
        """
        return self._size

    # ----------------------------------------------------------------------
    @size.setter
    def size(self, size):
        if self._existing is True:
            # check for common errors
            if size not in ["small", "medium", "large"]:
                raise ValueError("Size must be 'small', 'medium', or 'large'")
            if size == "small" and not isinstance(self._story, sm_module.Briefing):
                raise ValueError("Size 'small' can only be used in a Briefing")

            self._story._properties["nodes"][self._node]["data"]["textSize"] = size

        self._size = size

    # ----------------------------------------------------------------------
    def add_attachment(
        self, content: arcgis.gis.Item | Image | Video, text: str = None
    ) -> bool:
        """
        Add a text action to your text. You can specify the data of the action.
        This can only be used within a Briefing

        The text must be part of the Briefing before adding an attachment.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        content             Required content that can be added as an attachment.
                            Content can be:
                            * An Item object of type: Web Map, Image, StoryMap, Collection, Dashboard,
                            Web Experience, or other arcgis Apps.
                            * A story content of type Image or Video
        ---------------     --------------------------------------------------------------------
        text                Optional String. The part of the text that the attachment will be linked to. The text
                            must already exist in the text node.

                            For example, if the entire text is "Look at this dog." and you want to link the word "dog"
                            to the attachment, then the text parameter would be "dog".
        ===============     ====================================================================

        :return: True if successful.
        """
        if self._existing is True and isinstance(self._story, sm_module.Briefing):
            content_node = None
            content_type = None

            # First determine what type of content we are dealing with.
            if isinstance(content, arcgis.gis.Item):
                # Need to check the item type.
                # If Web Map we create a Map instance, otherwise we create a custom embed dictionary
                if content.type == "Web Map":
                    # create the map
                    content = Map(content)
                    content_node = content._node
                    content_type = "Web Map"
                else:
                    # content gets added to story in custom method
                    content_type = "collection"
                    content_node = self._create_item_embed(content)
                    content = "custom embed"
            elif isinstance(content, (Image, Video)):
                content_node = content._node
                content_type = content._type

            if content_node is None:
                # It means it didn't go through the if statement above
                raise ValueError(
                    "Content is not of type: Web Map, Image, StoryMap, Collection, Dashboard, Web Experience, or other arcgis Apps. Or a story content of type Image or Video."
                )

            if content != "custom embed":
                # Now content is either type Map, Image, or Video
                content._add_to_story(story=self._story)
            action_id = "a-" + uuid.uuid4().hex[0:6]
            action_dict = {
                "origin": self._node,
                "trigger": "InlineAction_Apply",
                "target": self._story._properties["root"],
                "event": "Briefing_ShowAttachment",
                "data": {
                    "actionId": action_id,
                    "attachment": content_node,
                    "attachmentType": content_type,
                },
            }

            # Need to edit the text so that the format is: <span data-action-type="attachment-action" id="a-Mr9KE4">This is an attachment to ArcGIS Content</span>
            # There are two cases:
            # 1. The text is the entire text of the node
            # 2. The text is a part of the text of the node
            # Case 1:
            if text is None:
                # Add the action to the text
                new_text = (
                    f'<span data-action-type="attachment-action" id="{action_id}">'
                    + self.text
                    + "</span>"
                )
            # Case 2:
            else:
                # First get the text
                full_text = self.text
                if text not in full_text:
                    raise ValueError("The text must be part of the text of the node.")
                new_text = full_text.replace(
                    text,
                    f'<span data-action-type="attachment-action" id="{action_id}">{text}</span>',
                )
            # Now update the text
            self.text = new_text

            # add to actions list in story properties
            if "actions" in self._story._properties:
                self._story._properties["actions"].append(action_dict)
            else:
                self._story._properties["actions"] = [action_dict]

            return True
        else:
            raise ValueError(
                "This can only be used within a Briefing and the Text must exist in a Block."
            )

    # ----------------------------------------------------------------------
    def remove_attachment(self, text: str = None):
        """
        Remove an attachment from the text. If text_to_remove is None, remove all attachments.
        This can only be used within a Briefing.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        text                Optional String. The part of the text that the attachment will be removed from.
                            The text must already exist in the text class. If text is None, then all
                            attachments will be removed.
        ===============     ====================================================================

        :return: True if successful.
        """
        if self._existing is True and isinstance(self._story, sm_module.Briefing):
            # First get the text
            full_text = self.text
            # Initialize an empty list to store removed action IDs
            removed_action_ids = []

            if text:
                # Remove the specified attachment if text_to_remove is provided
                if '<span data-action-type="attachment-action" id="' in text:
                    # Get the action id to remove it from the dictionary
                    action_id = text.split('id="')[1].split('">')[0]
                    # Remove the action from the text
                    full_text = full_text.replace(
                        f'<span data-action-type="attachment-action" id="{action_id}">',
                        "",
                    ).replace("</span>", "")
                    # Add the removed action ID to the list
                    removed_action_ids.append(action_id)
            else:
                # Remove all attachments if text_to_remove is not provided
                while '<span data-action-type="attachment-action" id="' in full_text:
                    # Get the action id to remove it from the dictionary
                    action_id = full_text.split('id="')[1].split('">')[0]
                    # Remove the action from the text
                    full_text = full_text.replace(
                        f'<span data-action-type="attachment-action" id="{action_id}">',
                        "",
                    ).replace("</span>", "")
                    # Add the removed action ID to the list
                    removed_action_ids.append(action_id)

            # Now update the text
            self.text = full_text

            # Remove the corresponding actions from the actions list in the story properties
            if "actions" in self._story._properties:
                self._story._properties["actions"] = [
                    action
                    for action in self._story._properties["actions"]
                    if action["data"]["actionId"] not in removed_action_ids
                ]
        else:
            return False

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _create_item_embed(self, item):
        """
        Create the embed dictionary when adding an item as a text attachment.
        """
        # first create resource dictionary
        resource_id = utils.create_unique_id(resource=True)
        resource_dict = {
            "type": "portal-item",
            "data": {
                "itemId": item.id,
            },
        }
        # add the resource to the resources
        self._story._properties["resources"][resource_id] = resource_dict

        # second create the embed dictionary
        embed_dict = {
            "type": "embed",
            "data": {
                "embedResourceId": resource_id,
                "url": item.homepage,
                "isInteractiveByDefault": True,
                "display": "inline",
            },
        }

        # add the embed dict to the nodes
        # create node id
        node_id = utils.create_unique_id()
        # add to nodes
        self._story._properties["nodes"][node_id] = embed_dict
        # return the node id
        return node_id

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True
        self._story._properties["nodes"][self._node] = {
            "type": "text",
            "data": {
                "type": self._style,
                "text": self._text,
            },
        }
        if self._color is not None:
            self._story._properties["nodes"][self._node]["data"]["customTextColors"] = [
                self._color
            ]
        if self._size is not None:
            # if story is not a briefing and size is 'small' then set to 'medium'
            if (
                not isinstance(self._story, sm_module.Briefing)
                and self._size == "small"
            ):
                self._size = "medium"
            self._story._properties["nodes"][self._node]["data"][
                "textSize"
            ] = self._size

    # ----------------------------------------------------------------------
    def _check_node(self):
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Button:
    """
    Class representing a `Button` in a Storymap.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    link                    Required String. When user clicks on button, they will be brought to
                            the link.
    ------------------      --------------------------------------------------------------------
    text                    Required String. The text that shows on the button.
    ==================      ====================================================================

    """

    def __init__(self, link: str | None = None, text: str | None = None, **kwargs):
        # Can be created from scratch or already exist in story
        # Button is not an immersive node
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # Check if node exists else create new instance
        self._existing = self._check_node()
        if self._existing is True:
            self._link = self._story._properties["nodes"][self._node]["data"]["link"]
            self._text = self._story._properties["nodes"][self._node]["data"]["text"]
        else:
            self._link = link
            self._text = text

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Button(link='{self._link}', text='{self._text}')"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get the properties for the button.

        :return:
            The Button dictionary for the node.
            If nothing is returned, make sure the content is part of the story.
        """
        if self._existing is True:
            return {"node_dict": self._story._properties["nodes"][self._node]}

    # ----------------------------------------------------------------------
    @property
    def text(self) -> str:
        """
        Get/Set the text for the button.

        ==================  ==================================================
        **Parameter**        **Description**
        ------------------  --------------------------------------------------
        text                Optional String. The new text to be displayed.
        ==================  ==================================================

        :return:
            The text for the node.
            If nothing is returned, make sure the content is part of the story.
        """
        return self._text

    # ----------------------------------------------------------------------
    @text.setter
    def text(self, text: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["text"] = text
        self._text = text

    # ----------------------------------------------------------------------
    @property
    def link(self) -> str:
        """
        Get/Set the link for the button.

        ==================  ==================================================
        **Parameter**        **Description**
        ------------------  --------------------------------------------------
        link                Optional String. The new path for the button.
        ==================  ==================================================

        :return:
            The link being used.
            If nothing is returned, make sure the content is part of the story.
        """
        return self._link

    # ----------------------------------------------------------------------
    @link.setter
    def link(self, link: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["link"] = link
        self._link = link

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story, **kwargs):
        self._story = story
        self._existing = True
        self._story._properties["nodes"][self._node] = {
            "type": "button",
            "data": {"text": self._text, "link": self._link},
        }

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Gallery:
    """
    Class representing an `Image Gallery` within a Storymap.

    To begin with a new gallery, simply call the class. You can add up to 12 images.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    images                  Optional list of images of type Image. (see: :class:`~arcgis.apps.storymap.Image`)
    ==================      ====================================================================

    .. code-block:: python

        # Images to add to the gallery.
        >>> image1 = Image(<url or path>)
        >>> image2 = Image(<url or path>)
        >>> image3 = Image(<url or path>)

        # Create a gallery with images. Add a third image later.
        >>> gallery = Gallery([image1, image2])
        >>> my_story.add(gallery)
        >>> gallery.add_images([image3])
    """

    def __init__(self, images: list[Image] | None = None, **kwargs):
        # Can be created from scratch or already exist in story
        # Gallery is not an immersive node
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # Check if node exists, else create new empty instance
        self._existing = self._check_node()
        if self._existing is True:
            children = self._story._properties["nodes"][self._node]["children"]
            self._images = [
                utils.assign_node_class(story=self._story, node_id=child)
                for child in children
            ]
        else:
            # Create new empty instance
            self._children = []
            if images:
                if len(images) > 12:
                    raise ValueError("Maximum amount of images permitted is 12.")
                for image in images:
                    if not isinstance(image, Image):
                        raise ValueError("Images must be of type Image.")
                self._images = images
            else:
                self._images = []

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"ImageGallery(num_images={len(self.images)})"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def properties(self):
        """
        Get properties of the Gallery object

        :return:
            A dictionary depicting the node in the story.
            If nothing is returned, make sure the gallery is part of the story.
        """
        if self._existing is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
            }

    # ----------------------------------------------------------------------
    @property
    def images(self) -> list[Image]:
        """
        Get list of images in the image gallery.

        :return:
            A list of `class:`~arcgis.apps.storymap.Image` objects.
        """
        return self._images

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the swipe.

        The Gallery must be part of a Storymap before editing the caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Gallery.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        else:
            return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption: str):
        if isinstance(caption, str):
            self._story._properties["nodes"][self._node]["data"]["caption"] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the swipe.

        The Gallery must be part of a Storymap before editing the alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Gallery.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        else:
            return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text: str):
        self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text

    # ----------------------------------------------------------------------
    @property
    def display(self) -> str:
        """
        Get/Set the display type of the Gallery.

        The Gallery must be part of a Storymap before editing the display type.

        Values: `jigsaw` | `square-dynamic`
        """
        if self._existing is True:
            return self._story._properties["nodes"][self._node]["config"]["size"]

    # ----------------------------------------------------------------------
    @display.setter
    def display(self, display: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["config"]["size"] = display

    # ----------------------------------------------------------------------
    def add_images(self, images: list[Image]) -> list[Image]:
        """
        ==================      ====================================================================
        **Parameter**            **Description**
        ------------------      --------------------------------------------------------------------
        images                  Required list of images of type Image.
        ==================      ====================================================================

        :return: A list of `class:`~arcgis.apps.storymap.Image` objects.
        """
        if len(self.images) == 12:
            raise Warning(
                "Maximum amount of images permitted is 12. Use Gallery.delete(image_node) to remove images before adding."
            )

        if self._existing:
            if images is not None:
                for image in images:
                    if image._node in self._story._properties["nodes"]:
                        image._node = utils.create_unique_id()
                    image._add_to_story(story=self._story)
                    self._story._properties["nodes"][self._node]["children"].append(
                        image._node
                    )
                    self._images.append(image)
        else:
            if images:
                for image in images:
                    if isinstance(image, Image):
                        self._images.append(image)
        return self.images

    # ----------------------------------------------------------------------
    def delete_image(self, image: list[Image] | Image) -> bool:
        """
        The delete_image method is used to delete one image from the gallery. To see a list of images
        used in the gallery, use the :meth:`~arcgis.apps.storymap.story_content.Gallery.images` property.

        ==================      ====================================================================
        **Parameter**            **Description**
        ------------------      --------------------------------------------------------------------
        image                   Required Image or list of Images to remove from the gallery.
        ==================      ====================================================================

        :return: True if successful.
        """
        if not isinstance(image, list) and isinstance(image, Image):
            image = [image]

        if self._existing:
            # update the story properties
            image_nodes = []
            for img in image:
                image_nodes.append(img._node)
            for img in image_nodes:
                self._story._properties["nodes"][self._node]["children"].remove(img)
                utils.delete(self._story, img)
            children = self._story._properties["nodes"][self._node]["children"]
            self._images = [
                utils.assign_node_class(story=self._story, node_id=child)
                for child in children
            ]
            return True
        else:
            # just update the self._image list
            for img in image:
                self._images.remove(img)
            return True

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", "jigsaw")

        # Create image nodes
        self._story._properties["nodes"][self._node] = {
            "type": "gallery",
            "data": {
                "galleryLayout": display,
                "caption": "" if caption is None else caption,
                "alt": "" if alt_text is None else alt_text,
            },
            "children": [im._node for im in self._images],
        }
        if self._images:
            for image in self._images:
                image._add_to_story(story=self._story)

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the Gallery from the Storymap.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Swipe:
    """
    Represents a `Swipe` within a Storymap or Briefing. A swipe can have up to 2 items and they must be
    of the same type (Image or Map).

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    content             Optional list of Image or Map instances. The content that will be
                        displayed in the swipe. There can be up to 2 items in a swipe. The items
                        must be of the same type (Image or Map). If you want to add content to only
                        one side of the swipe, use None for the other side.
    ===============     ====================================================================

    .. code-block:: python

        >>> my_story.contents #use to find swipe node id

        # Method 1: Use the Swipe Class
        >>> image1 = Image(<url or path>)
        >>> image2 = Image(<url or path>)
        >>> swipe = Swipe([image1, image2])

    """

    def __init__(self, content: list[Map | Image] | None = None, **kwargs):
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._existing = self._check_node()

        if self._existing:
            # swipe exists in story
            if "data" in self._story._properties["nodes"][self._node]:
                self._left_node = self._story._properties["nodes"][self._node]["data"][
                    "contents"
                ]["0"]
                self._right_node = self._story._properties["nodes"][self._node]["data"][
                    "contents"
                ]["1"]
                self._left_content = (
                    utils.assign_node_class(story=self._story, node_id=self._left_node)
                    if self._left_node
                    else None
                )
                self._right_content = (
                    utils.assign_node_class(story=self._story, node_id=self._right_node)
                    if self._right_node
                    else None
                )
                # Get the media type since has to be same for both sides
                if self._left_node is not None:
                    node = self._left_node
                else:
                    node = self._right_node
                if self._story._properties["nodes"][node]["type"] == "image":
                    self._media_type = "image"
                elif self._story._properties["nodes"][node]["type"] in [
                    "webmap",
                    "expressmap",
                ]:
                    self._media_type = "webmap"
            else:
                self._right_node = ""
                self._left_node = ""
                self._media_type = ""
        else:
            if content is not None:
                # set the content and media type
                if len(content) > 2:
                    raise ValueError("Swipe can only have up to 2 items.")
                if isinstance(content[0], Image):
                    self._media_type = "image"
                elif isinstance(content[0], Map):
                    self._media_type = "webmap"
                else:
                    raise ValueError("Swipe can only accept Image or Map content.")
                self._left_node = content[0]._node if content[0] is not None else ""
                self._left_content = content[0]
                if len(content) == 2:
                    self._right_node = (
                        content[1]._node if content[1] is not None else ""
                    )
                    self._right_content = content[1]
            else:
                # empty swipe
                self._right_node = ""
                self._left_node = ""
                self._media_type = ""
                self._left_content = None
                self._right_content = None

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Swipe(type='{self._media_type}')"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(deprecated_in="2.4.2")
    def node(self) -> str:
        """
        Get the node id

        return: string representing the node id
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    def content(self) -> list[Image | Map]:
        """
        Get the content that is in the swipe. There can be up to 2 items in a swipe.

        The content will be returned as their class instance.

        ==================  ==================================================
        **Parameter**        **Description**
        ------------------  --------------------------------------------------
        content             List of Image or Map instances. The content that will be
                            displayed in the swipe. There can be up to 2 items in a swipe. The items
                            must be of the same type (Image or Map). If you want to add content to only
                            one side of the swipe, use None for the other side.
        ==================  ==================================================

        :return:
            A list of class:`~arcgis.apps.storymap.Image` or class:`~arcgis.apps.storymap.Map` instances.
        """
        return [self._left_content, self._right_content]

    # ----------------------------------------------------------------------
    @content.setter
    def content(self, content: list[Image | Map]):
        if len(content) > 2:
            raise ValueError("Swipe can only have up to 2 items.")
        if isinstance(content[0], Image):
            self._media_type = "image"
        elif isinstance(content[0], Map):
            self._media_type = "webmap"
        else:
            raise ValueError("Swipe can only accept Image or Map content.")

        self._left_node = content[0]._node if content[0] is not None else ""
        self._left_content = content[0]
        if len(content) == 2:
            self._right_node = content[1]._node if content[1] is not None else ""
            self._right_content = content[1]

        if self._existing:
            # if the nodes are not in the story, add them
            if self._left_node not in self._story._properties["nodes"]:
                self._left_content._add_to_story(story=self._story)
            if self._right_node not in self._story._properties["nodes"]:
                self._right_content._add_to_story(story=self._story)

            # change in the story properties as well
            self._story._properties["nodes"][self._node]["data"]["contents"][
                "0"
            ] = self._left_node
            self._story._properties["nodes"][self._node]["data"]["contents"][
                "1"
            ] = self._right_node

    # ----------------------------------------------------------------------
    @deprecated(
        deprecated_in="2.4.0",
        details="Use the content property to get and set.",
    )
    @property
    def properties(self):
        """
        Get properties of the Swipe object

        :return:
            A dictionary depicting the node in the story.
        """
        if self._existing is True:
            return {
                "node_dict": self._story._properties["nodes"][self._node],
            }
        else:
            return None

    # ----------------------------------------------------------------------
    @property
    def caption(self) -> str:
        """
        Get/Set the caption property for the swipe.

        The Swipe must be part of a Storymap before editing the caption.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        caption             String. The new caption for the Swipe.
        ==================  ========================================

        :return:
            The caption that is being used.
        """
        if self._existing is True:
            if "caption" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["caption"]
        else:
            return None

    # ----------------------------------------------------------------------
    @caption.setter
    def caption(self, caption: str):
        if self._existing is True:
            if isinstance(caption, str):
                self._story._properties["nodes"][self._node]["data"][
                    "caption"
                ] = caption

    # ----------------------------------------------------------------------
    @property
    def alt_text(self) -> str:
        """
        Get/Set the alternate text property for the swipe.

        The Swipe must be part of a Storymap before editing the alternate text.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        alt_text            String. The new alt_text for the Swipe.
        ==================  ========================================

        :return:
            The alternate text that is being used.
        """
        if self._existing is True:
            if "alt" in self._story._properties["nodes"][self._node]["data"]:
                return self._story._properties["nodes"][self._node]["data"]["alt"]
        else:
            return None

    # ----------------------------------------------------------------------
    @alt_text.setter
    def alt_text(self, alt_text: str):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["alt"] = alt_text

    # ----------------------------------------------------------------------
    @deprecated(
        deprecated_in="2.4.0",
        details="Use the content property to get and set.",
    )
    def edit(
        self,
        content: Image | Map | None = None,
        position: str = "right",
    ):
        """
        Deprecated. Use the `content` property to get and set Swipe content.
        This method now sets the content using the property, where position 'right' is index 1 and 'left' is index 0.

        Edit the media content of a Swipe item. To save your edits and see them
        in the StoryMap's builder, make sure to save the story.

        Use this method to add new content if your swipe is empty. You can specify the content to add
        and which side of the swipe it should be on.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        content             Required story content of type: :class:`~arcgis.apps.storymap.story_content.Image`
                            or :class:`~arcgis.apps.storymap.story_content.Map`. Must be the same media type
                            on both panels.
        ---------------     --------------------------------------------------------------------
        position            Optional String. Either "right" or "left". Default is "right" so content
                            will be added to right panel.
        ===============     ====================================================================

        :return: True if successful
        """
        if not self._existing:
            raise KeyError(
                "The instance of Swipe must first be added to the story before you can start editing."
            )
        if content is None:
            raise ValueError("Content must be provided.")
        # Determine index based on position
        idx = 1 if position == "right" else 0
        # Get current content list, fill with None if needed
        current = self.content
        if not isinstance(current, list) or len(current) < 2:
            current = [None, None]
        # Set the content at the correct position
        current[idx] = content
        self.content = current
        return True

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the Swipe from the Storymap or Briefing.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True

        # Get parameters
        caption = kwargs.pop("caption", None)
        alt_text = kwargs.pop("alt_text", None)
        display = kwargs.pop("display", None)

        if self._left_content is not None:
            self._left_content._add_to_story(story=self._story)
        if self._right_content is not None:
            self._right_content._add_to_story(story=self._story)

        # Create swipe node
        self._story._properties["nodes"][self._node] = {
            "type": "swipe",
            "data": {
                "contents": {"0": self._left_node, "1": self._right_node},
                "caption": "" if caption is None else caption,
                "alt": "" if alt_text is None else alt_text,
            },
        }
        if display:
            self._story._properties["nodes"][self._node]["config"] = {"size": display}

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class SidecarSlide:
    """
    A `Sidecar Slide` is a slide that is found in a Sidecar. Using a series of slides, you can
    integrate media with text to create a simple scrolling experience.

    You can add and edit content on the slide by using the various properties and methods in the class.
    """

    def __init__(
        self,
        content: list | None = None,
        media: Map | Image | Video | Embed | Swipe | Code | None = None,
        **kwargs,
    ):
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._sidecar = kwargs.pop("sidecar", None)
        self._story = self._sidecar._story if self._sidecar else None

        self._existing = self._check_node()

        self._content = None
        self._media = None
        if self._existing:
            nodes = self._story._properties["nodes"][self._node]["children"]
            self._content = self._create_content_list(nodes)
            if len(nodes) > 1:
                self._media = utils.assign_node_class(self._story, nodes[1])
            else:
                self._media = None
        else:
            # holds the content for the narrative panel
            self._content = content
            # holds the media for the media panel
            self._media = media

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "SidecarSlide()"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def media(self) -> Map | Image | Video | Embed | Swipe | Code | None:
        """
        Get the media content of the slide.

        You can use the setter to set a new media. Only one media can exists on a slide at a time.
        Valid media types are: Map, Image, Video, Embed, Swipe, and Code. Create an instance of the media type
        and then set it to the slide.

        :return: The media content of the slide.
        """
        # check that media exists in the sidecar
        return self._media

    # ----------------------------------------------------------------------
    @media.setter
    def media(self, content: Map | Image | Video | Embed | Swipe | Code):
        # check that the media is a valid type
        if not isinstance(content, (Map, Image, Video, Embed, Swipe, Code)):
            raise ValueError("Invalid media type. Please use a valid media type.")

        # first we need to remove the existing media if any exists
        if self._media is not None:
            utils.delete(self._story, self._media._node)
        # now we can add the new media
        content._add_to_story(story=self._story)
        if len(self._story._properties["nodes"][self._node]["children"]) == 2:
            self._story._properties["nodes"][self._node]["children"][1] = content._node
        else:
            self._story._properties["nodes"][self._node]["children"].append(
                content._node
            )
        self._media = content

    # ----------------------------------------------------------------------
    @property
    def contents(
        self,
    ) -> (
        list[
            Image
            | Video
            | Embed
            | Button
            | Text
            | Map
            | Code
            | MediaAction
            | Separator
            | Audio
            | Timeline
        ]
        | None
    ):
        """
        Get the content of the slide. This is only the content found in the
        narrative panel. The media content is not included.

        :return: The content of the slide.
        """
        return self._content

    # ----------------------------------------------------------------------
    def _create_content_list(self, nodes):
        # the content is a list of nodes that need to be found in the story
        if len(nodes) > 0 and "children" in self._story._properties["nodes"][nodes[0]]:
            # the first node will be the narrative panel. This holds the children as list
            narrative_panel_contents = self._story._properties["nodes"][nodes[0]][
                "children"
            ]
            content = []
            for child in narrative_panel_contents:
                content.append(utils.assign_node_class(self._story, child))

            return content

    # ----------------------------------------------------------------------
    @contents.setter
    def contents(
        self,
        content: list[
            Image
            | Video
            | Embed
            | Button
            | Text
            | Map
            | Code
            | MediaAction
            | Separator
            | Audio
            | Timeline
        ],
    ):
        if self._existing:
            # check that the content is a list
            if not isinstance(content, list):
                content = [content]

            # first create a list of the content nodes to assign to narrative panel children
            # in this loop, check if content is in story, if not add to story
            content_nodes = []
            for item in content:
                if item._node not in self._story._properties["nodes"]:
                    if isinstance(item, MediaAction):
                        item._add_to_story(slide=self)
                    else:
                        item._add_to_story(story=self._story)
                content_nodes.append(item._node)

            # assign the children to the narrative panel children
            nodes = self._story._properties["nodes"][self._node]["children"]
            self._story._properties["nodes"][nodes[0]]["children"] = content_nodes
        # assign to content property
        self._content = content

    # ----------------------------------------------------------------------
    @property
    def transition(self) -> str:
        """
        Get/Set the transition type of the slide.

        Values: `fade` | `fade-slow`
        """
        if self._existing is True:
            return self._story._properties["nodes"][self._node]["data"]["transition"]
        return None

    # ----------------------------------------------------------------------
    @transition.setter
    def transition(self, transition: str):
        if self._existing:
            self._story._properties["nodes"][self._node]["data"][
                "transition"
            ] = transition
        return None

    # ----------------------------------------------------------------------
    def _add_to_story(self, sidecar: Sidecar = None, **kwargs):
        self._story = sidecar._story
        self._existing = True

        narrative_panel_node = utils.create_unique_id()
        self._story._properties["nodes"][narrative_panel_node] = {
            "type": "immersive-narrative-panel",
            "children": [],
            "data": {"position": "start", "size": "small", "panelStyle": "themed"},
        }
        self._story._properties["nodes"][self._node] = {
            "type": "immersive-slide",
            "children": [narrative_panel_node],
            "data": {"transition": "fade"},
        }

        # now that it exists, add the content to the narrative panel
        self.contents = self._content
        # now that it exists, add the media
        self.media = self._media

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Sidecar:
    """
    A class that represents a `Sidecar` which can be found in a Storymap.

    A sidecar is composed of slides. Slides are composed of two sub structures: a narrative panel and a media panel.
    The media node can be a(n): Image, Video, Embed, Map, or Swipe.
    The narrative panel can contain multiple types of content including Image, Video, Embed, Button, Text, Map, and more.

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    style               Optional string that depicts the sidecar style.
                        Values: 'floating-panel' | 'docked-panel' | 'slideshow'
    ===============     ====================================================================

    .. code-block:: python

        # Create a sidecar with a style
        >>> my_story = Storymap(<storymap_id>)
        >>> my_story.contents #use to find sidecar instance
        >>> sidecar = Sidecar(style='floating-panel')
        >>> my_story.add(sidecar)

    """

    def __init__(self, style: str | None = None, **kwargs) -> None:
        self._story = kwargs.get("story")
        self._node = kwargs.get("node_id") or utils.create_unique_id()
        self._existing = self._check_node()

        if not self._existing:
            self._initialize_new_sidecar(style)
        else:
            self._initialize_existing_sidecar()

    # ----------------------------------------------------------------------
    def _initialize_new_sidecar(self, style):
        self._style = style or "floating-panel"
        self._slides = []

    # ----------------------------------------------------------------------
    def _initialize_existing_sidecar(self):
        self._style = self._story._properties["nodes"][self._node]["data"]["subtype"]
        self._slides = self._story._properties["nodes"][self._node]["children"]

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Sidecar(num_slides={len(self._slides)})"

    def __repr__(self) -> str:
        return str(self)

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        return self._node

    # ----------------------------------------------------------------------
    def _add_to_story(
        self,
        story=None,
        **kwargs,
    ):
        # Add the story to the node
        self._story = story
        self._existing = True
        # Create timeline nodes
        self._story._properties["nodes"][self._node] = {
            "type": "immersive",
            "data": {
                "type": "sidecar",
                "subtype": self._style,
                "narrativePanelPosition": "start",
                "narrativePanelSize": "medium",
            },
            "children": [],
        }

        # Add the slides to the sidecar
        for slide in self._slides:
            slide._add_to_story(sidecar=self)

        # Assign the children to the sidecar children
        self._story._properties["nodes"][self._node]["children"] = [
            slide._node for slide in self._slides
        ]

        # Update the property
        self._slides = self._story._properties["nodes"][self._node]["children"]

    # ----------------------------------------------------------------------
    @property
    def slides(self) -> list[SidecarSlide]:
        """
        Get a list of all the content within the sidecar in order of appearance.
        Each element will contain the content found in the narrative panel and the media content for a slide.

        :return: A list of SidecarSlide instances.
        """
        contents = []
        for slide in self._slides:
            contents.append(SidecarSlide(sidecar=self, node_id=slide))
        return contents

    # ----------------------------------------------------------------------
    @slides.setter
    def slides(self, slides: list[SidecarSlide]):
        """
        Set the slides for the sidecar. The slides must be a list of SidecarSlide instances.
        """
        if self._existing:
            # check that the slides is a list
            if not isinstance(slides, list):
                slides = [slides]

            # first create a list of the slide nodes to assign to sidecar children
            # in this loop, check if slide is in story, if not add to story
            slide_nodes = []
            for item in slides:
                if item._node not in self._story._properties["nodes"]:
                    item._add_to_story(sidecar=self)
                slide_nodes.append(item._node)

            # assign the children to the sidecar children
            self._story._properties["nodes"][self._node]["children"] = slide_nodes
        self._slides = slides

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the Sidecar from the Storymap.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _remove_associated(self, slide):
        # Get narrative panel, always first child of the slide
        narrative_panel: str = self._story._properties["nodes"][slide]["children"][0]
        # Delete the children of the narrative panel
        if "children" in self._story._properties["nodes"][narrative_panel]:
            children: list = self._story._properties["nodes"][narrative_panel][
                "children"
            ]
            for child in children:
                utils.delete(self._story, child)
        # Delete the narrative panel itself
        utils.delete(self._story, narrative_panel)

        # Remove media item and resource node if one exists
        if len(self._story._properties["nodes"][slide]["children"]) >= 1:
            media_item: str = self._story._properties["nodes"][slide]["children"][0]
            utils.delete(self._story, media_item)

    # ----------------------------------------------------------------------
    def _check_node(self):
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        # Node is not in the story if no story or node id is present
        return self._story is not None and self._node is not None


###############################################################################################################
class TimelineSpacer:
    """
    Represents a spacer in a timeline. A spacer is a blank space with some graphics that can be used to separate events.
    """

    def __init__(self, **kwargs):
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._timeline = kwargs.pop("timeline", None)
        self._story = self._timeline._story if self._timeline else None

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "TimelineSpacer()"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    def _add_to_story(self, timeline: Timeline = None, **kwargs):
        self._timeline = timeline
        self._story = timeline._story
        self._story._properties["nodes"][self._node] = {
            "type": "timeline-spacer",
        }


###############################################################################################################
class TimelineEvent:
    """
    An event belongs to a timeline. It can contain up to 3 items: A header, a body, and an image.
    You can only have one of each item in an event. If you try to add a second item of the same type,
    it will replace the existing item.
    """

    def __init__(self, contents: list[Text, Image] | None = None, **kwargs):
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._timeline = kwargs.pop("timeline", None)
        self._story = self._timeline._story if self._timeline else None
        self._existing = self._check_node()

        self._content = []
        self._children = []

        if self._existing:
            if "children" in self._story._properties["nodes"][self._node]:
                self._children = self._story._properties["nodes"][self._node][
                    "children"
                ]
        else:
            if contents:
                if len(contents) > 3:
                    raise ValueError("Timeline Event can only have up to 3 items.")
                for content in contents:
                    if isinstance(content, Text):
                        if content._style not in ["h3", "paragraph"]:
                            raise ValueError("Text style must be h3 or paragraph.")
                        self._content.append(content)
                    elif isinstance(content, Image):
                        self._content.append(content)

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "TimelineEvent()"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def contents(self) -> list[Image | Text]:
        """
        Get the content that is in the event. There can be up to 3 items in an event.

        The content will be returned as their class instance.

        :return: A list of class:`~arcgis.apps.storymap.Image` or class:`~arcgis.apps.storymap.Text` instances.
        """
        if self._existing:
            content = []
            for item in self._children:
                if self._story._properties["nodes"][item]["type"] == "image":
                    content.append(Image(story=self._story, node_id=item))
                elif self._story._properties["nodes"][item]["type"] == "text":
                    content.append(Text(story=self._story, node_id=item))
            return content
        else:
            return self._content

    # ----------------------------------------------------------------------
    @contents.setter
    def contents(self, content: list[Image | Text]):
        if len(content) > 3:
            raise ValueError("Timeline Event can only have up to 3 items.")

        if self._existing:
            for item in content:
                if not isinstance(item, (Image, Text)):
                    raise ValueError(
                        "Timeline Event can only accept Image or Text content."
                    )
                self._edit_content(item)
                self._children = self._story._properties["nodes"][self._node][
                    "children"
                ]
        else:
            self._content = content

    # ----------------------------------------------------------------------
    def _edit_content(self, content: Image | Text):
        position = self._find_position_content(content)
        if content._node not in self._story._properties["nodes"]:
            content._add_to_story(story=self._story)

        if isinstance(content, Text):
            if position is not None:
                old_text_node = self._story._properties["nodes"][self._node][
                    "children"
                ].pop(position)
                utils.delete(self._story, old_text_node)
                self._story._properties["nodes"][self._node]["children"].insert(
                    position, content._node
                )
            else:
                self._story._properties["nodes"][self._node]["children"].append(
                    content._node
                )
        elif isinstance(content, Image):
            if position is not None:
                old_image_node = self._story._properties["nodes"][self._node][
                    "children"
                ].pop(position)
                utils.delete(self._story, old_image_node)
                self._story._properties["nodes"][self._node]["children"].insert(
                    position, content._node
                )
            else:
                self._story._properties["nodes"][self._node]["children"].append(
                    content._node
                )

    # ----------------------------------------------------------------------
    def _find_position_content(self, content):
        content_type = "text" if isinstance(content, Text) else "image"
        subtype = content._style if isinstance(content, Text) else None
        position = None
        for child in self._story._properties["nodes"][self._node]["children"]:
            if (
                self._story._properties["nodes"][child]["type"] == content_type
                and content_type == "image"
            ):
                position = self._story._properties["nodes"][self._node][
                    "children"
                ].index(child)
                return position
            elif (
                self._story._properties["nodes"][child]["type"] == content_type
                and self._story._properties["nodes"][child]["data"]["type"] == subtype
            ):
                position = self._story._properties["nodes"][self._node][
                    "children"
                ].index(child)
                return position
            else:
                position = None
        return position

    # ----------------------------------------------------------------------
    def _add_to_story(self, timeline=None, **kwargs):
        self._timeline = timeline
        self._story = timeline._story
        self._story._properties["nodes"][self._node] = {
            "type": "timeline-event",
            "children": [],
        }

        if self._content:
            for content in self._content:
                self._edit_content(content)

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Timeline:
    """
    This block provides a fun and intuitive way to add chronological visualizations to your story in a more flexible
    and dynamic presentation than static images or purely text-based lists can offer.

    Storytellers can enter up to 20 “events” in a vertical chain, and can accompany each event with an image,
    if desired. You can also add a spacer in between events if you want to indicate that a particular lapse
    in time is longer relative to others.

    .. note::
        Once you create a Timeline instance you must add it to the story to be able to edit it further.

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    events              Optional list of TimelineEvent or TimelineSpacer instances. The events that will be
                        displayed in the timeline. There can be up to 20 items in a timeline.
    ---------------     --------------------------------------------------------------------
    style               Optional string that depicts the timeline style.
                        Values: 'waterfall' | 'timeline'
    ===============     ====================================================================
    """

    def __init__(
        self,
        events: list[TimelineSpacer | TimelineEvent] | None = None,
        style: str | None = None,
        **kwargs,
    ) -> None:
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._existing = self._check_node()

        if self._existing:
            self._initialize_existing_timeline()
        else:
            self._initialize_new_timeline(events, style)

    def _initialize_new_timeline(self, events, style):
        self._style = style or "waterfall"
        self._events: list[TimelineEvent | TimelineSpacer] = []
        for event in events:
            if isinstance(event, TimelineEvent) or isinstance(event, TimelineSpacer):
                self._events.append(event)
            else:
                raise ValueError(
                    "Timeline can only accept TimelineEvent or TimelineSpacer content."
                )

    def _initialize_existing_timeline(self):
        self._style = self._story._properties["nodes"][self._node]["data"]["type"]
        self._events: list[TimelineEvent | TimelineSpacer] = self._load_events()

    # ----------------------------------------------------------------------
    def _load_events(self):
        events_list = []
        if self._story is not None:
            for event_node_id in self._story._properties["nodes"][self._node][
                "children"
            ]:
                if (
                    self._story._properties["nodes"][event_node_id]["type"]
                    == "timeline-event"
                ):
                    event = TimelineEvent(timeline=self, node_id=event_node_id)
                else:
                    event = TimelineSpacer(timeline=self, node_id=event_node_id)
                events_list.append(event)
        return events_list

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Timeline(style={self._style})"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @deprecated(
        deprecated_in="2.4.0",
    )
    @property
    def node(self) -> str:
        """
        Get the node id of the timeline.
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    def events(self) -> list[TimelineEvent | TimelineSpacer]:
        if self._existing:
            return self._load_events()
        else:
            return self._events

    # ----------------------------------------------------------------------
    @events.setter
    def events(self, events: list[TimelineEvent | TimelineSpacer]):
        if self._existing:
            # check if the event list is longer than 20
            if len(events) > 20:
                raise ValueError("Timeline can only have up to 20 items.")
            # check if event already exists in the story
            event_ids = []
            for event in events:
                event_ids.append(event._node)
                if event._node not in self._story._properties["nodes"]:
                    event._add_to_story(timeline=self)
            # assign the children to the timeline children
            self._story._properties["nodes"][self._node]["children"] = event_ids
        else:
            self._events = events

    # ----------------------------------------------------------------------
    @property
    def style(self) -> str:
        return self._style

    # ----------------------------------------------------------------------
    @style.setter
    def style(self, style: str):
        self._style = style
        self._story._properties["nodes"][self._node]["data"]["type"] = style

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True
        self._story._properties["nodes"][self._node] = {
            "type": "timeline",
            "data": {
                "type": self._style,
            },
            "children": [],
        }

        # add each event to the story
        for event in self._events:
            event._add_to_story(timeline=self)

        # add the list of node ids to the timeline
        self._story._properties["nodes"][self._node]["children"] = [
            event._node for event in self._events
        ]

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class MapTour:
    """
    Create a MapTour object from a pre-existing `maptour` in Storymap.
    """

    def __init__(self, **kwargs):
        """
        Initialize the MapTour instance.
        """
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._existing = self._check_node()

        if self._existing:
            self._map = self._story._properties["nodes"][self._node]["data"]["map"]
            if self._story._properties["nodes"][self._node]["type"] != "tour":
                raise ValueError("This node is not of type tour.")
            self._places = self._story._properties["nodes"][self._node]["data"][
                "places"
            ]
        else:
            raise ValueError(
                "You cannot create a Map Tour from scratch at this time. Please use an existing Map Tour."
            )

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        """Return a string representation of the MapTour."""
        return f"MapTour(style={self.style})"

    def __repr__(self) -> str:
        """Return a string representation of the MapTour."""
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def style(self):
        """Get the type and subtype of the map tour."""
        return (
            self._story._properties["nodes"][self._node]["data"]["type"]
            + " - "
            + self._story._properties["nodes"][self._node]["data"]["subtype"]
        )

    # ----------------------------------------------------------------------
    @property
    def places(self):
        """List all places on the map."""
        places = []
        for place in self._places:
            places.append(Places(place, tour=self))
        return places

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Places:
    """
    In a Map Tour the different places are represented by a series of points on a map. They contain a title, media, and
    content.
    """

    def __init__(self, place_dict: dict, **kwargs):
        self._id = place_dict["id"]
        self._tour = kwargs.pop("tour", None)
        self._story = self._tour._story if self._tour else None
        self._contents = place_dict["contents"] if "contents" in place_dict else []
        self._media = place_dict["media"] if "media" in place_dict else None
        self._title = place_dict["title"] if "title" in place_dict else None

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Place(title={self.title.text})" if self.title else "Place()"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def title(self):
        """Get the title of the place."""
        if self._title:
            return utils.assign_node_class(self._story, self._title)
        else:
            return None

    # ----------------------------------------------------------------------
    @property
    def media(self):
        """Get the media of the place."""
        if self._media:
            return utils.assign_node_class(self._story, self._media)
        else:
            return None

    # ----------------------------------------------------------------------
    @property
    def content(self):
        """Get the contents of the place."""
        contents = []
        for content in self._contents:
            contents.append(utils.assign_node_class(self._story, content))
        return contents


###############################################################################################################
class MediaAction:
    """
    Within the sidecar block, there are stationary media panels and scrolling narrative panels works hand in hand
    to deliver an immersive experience. If the media panel consists of a web map or web scene, the map actions
    functionality allows authors to include options for further interactivity.
    Simply put, map actions are buttons that change something on the map or scene when toggled.
    These buttons can be configured to modify the map extent, the visibility of different layers etc., and this can be
    useful to include additional details without deviating from the primary narrative.

    There are two main types: Inline text map actions and map action blocks in sidecar.


    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    slide_number        Required Integer. The slide that the map action will be added to. First slide is 1.
    ---------------     --------------------------------------------------------------------
    text                Required String. The map action button text
    ---------------     --------------------------------------------------------------------
    viewpoint           Optional Dictionary. The viewpoint to be set. The minimum keys to include are
                        an x and y center point in the target geometry.

                        Set the viewpoint, extent, and map layers if you want the action to be a map action.

                        Example:
                            viewpoint = {
                                "rotation": 0,
                                "scale": 18055.954822,
                                "targetGeometry": {
                                    "spatialReference": {
                                        "latestWkid": 3857,
                                        "wkid": 102100
                                    },
                                    "x": -8723429.856341356,
                                    "y": 4019095.847955684
                                }
                            }
    ---------------     --------------------------------------------------------------------
    extent              Optional Dictionary. The extent of the map that will be shown when
                        the action button is used.

                        Example:
                            extent = {
                                "spatialReference": {
                                    "latestWkid": 3857,
                                    "wkid": 102100
                                },
                                "xmin": -8839182.968379805,
                                "ymin": 3907027.5240857545,
                                "xmax": -8824335.075635428,
                                "ymax": 3915378.269425899
                            }
    ---------------     --------------------------------------------------------------------
    map_layers          Optional list of dictionaries. Each dictionary represents a map layer
                        and the parameters set on the map layer.

                        Example:
                            map_layers = [
                                {
                                    "id": "18511776c33-layer-2",
                                    "title": "USA Forest Type",
                                    "visible": true
                                }
                            ]
    ---------------     --------------------------------------------------------------------
    media               Optional item that is a story content item of type Image, Video, or Embed.
                        Set the media if you want the action to be an action on a media.
    ===============     ====================================================================

    """

    def __init__(
        self,
        text: str | None = None,
        viewpoint: dict | None = None,
        extent: dict | None = None,
        map_layers: list[dict] | None = None,
        media: Image | Video | Embed | None = None,
        **kwargs,
    ) -> None:
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._story = kwargs.pop("story", None)

        self._existing = self._check_node()

        if self._existing:
            self._text = self._story._properties["nodes"][self._node]["data"]["text"]
            self._viewpoint = (
                self._story._properties["nodes"][self._node]["data"]["viewpoint"]
                if "viewpoint" in self._story._properties["nodes"][self._node]["data"]
                else None
            )
            self._extent = (
                self._story._properties["nodes"][self._node]["data"].get("extent", None)
                if "extent" in self._story._properties["nodes"][self._node]["data"]
                else None
            )
            self._map_layers = (
                self._story._properties["nodes"][self._node]["data"].get(
                    "mapLayers", None
                )
                if "mapLayers" in self._story._properties["nodes"][self._node]["data"]
                else None
            )
            self._media = (
                self._story._properties["nodes"][self._node]["data"].get("media", None)
                if "media" in self._story._properties["nodes"][self._node]["data"]
                else None
            )
        else:
            self._text = text
            self._viewpoint = viewpoint
            self._extent = extent
            self._map_layers = map_layers
            self._media = media

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        """Return a string representation of the Media."""
        return f"MediaAction(text={self._text})" if self._text else "MediaAction()"

    def __repr__(self) -> str:
        """Return a string representation of the MediaAction."""
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def viewpoint(self) -> dict:
        """Get the viewpoint dictionary for the map action."""
        return self._viewpoint

    # ----------------------------------------------------------------------
    @property
    def media(self):
        """
        Get the media node id for the media action.
        """
        # If existing, the media will be a node_id else it's the item class
        if self._existing:
            return utils.assign_node_class(self._story, self._media)
        return self._media

    # ----------------------------------------------------------------------
    @media.setter
    def media(self, media: Image | Video | Embed):
        if not isinstance(media, (Image, Video, Embed)):
            raise TypeError("Media must be of type Image, Video, or Embed.")
        if self._existing:
            if media._node not in self._story._properties["nodes"]:
                media._add_to_story(story=self._story)
                self._media = media._node
            for idx, action in enumerate(self._story._properties["actions"]):
                if action["origin"] == self._node:
                    self._story._properties["actions"][idx]["data"] = {
                        "media": media._node
                    }
        else:
            self._media = media

    # ----------------------------------------------------------------------
    @property
    def text(self) -> str:
        """Get/Set the button text for a map action button."""
        return self._text

    # ----------------------------------------------------------------------
    @text.setter
    def text(self, text: str) -> None:
        """Set the button text for a map action button."""
        if not isinstance(text, str):
            raise TypeError("Text must be of type string.")
        if self._existing:
            self._story._properties["nodes"][self._node]["data"]["text"] = text
        self._text = text

    # ----------------------------------------------------------------------
    @deprecated(
        deprecated_in="2.4.0",
        details="Use the setter on the media property instead.",
    )
    def set_media(self, media: Image | Video | Embed):
        """
        Set the media for the map action.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        media               Required item that is a story content item.
                            Item type for the media node can be: Image, Video, or Embed.
        ==================  ========================================

        :return: The media node id for the media action.
        """
        if media._node not in self._story._properties["nodes"]:
            media._add_to_story(story=self._story)

        # Assign new media to action and update story properties
        for idx, action in enumerate(self._story._properties["actions"]):
            if action["origin"] == self._node:
                self._story._properties["actions"][idx]["data"] = {"media": media._node}
        self._story._properties["nodes"][self._node]["dependents"] = {
            "actionMedia": media._node
        }
        return self.media

    # ----------------------------------------------------------------------
    def set_viewpoint(
        self, target_geometry: dict, scale: Scales, rotation: int | None = None
    ) -> dict:
        """
        Set the extent and/or scale for the map action in the story.

        To see the current viewpoint, call the `viewpoint` property on the Map Action node.

        ==================     ====================================================================
        **Parameter**           **Description**
        ------------------     --------------------------------------------------------------------
        target_geometry         Required Dictionary. The viewpoint to be set. The minimum keys to include are
                                an x and y center point in the target geometry.

                                Example:

                                    target_geometry = {
                                        "spatialReference": {
                                            "latestWkid": 3857,
                                            "wkid": 102100
                                        },
                                        "x": -8723429.856341356,
                                        "y": 4019095.847955684
                                    }
        ------------------     --------------------------------------------------------------------
        scale                   Required Integer or Scales Enum Class value. The scale of the map action.
                                If using an integer, the scale must be in the same units as the spatial
                                reference of the target geometry.

                                Example:

                                        scale = 18055.954822
        ------------------     --------------------------------------------------------------------
        rotation                Optional Integer. The rotation of the map action. If not provided, the
                                rotation will be set to 0.

                                Example:

                                    rotation = 0
        ==================     ====================================================================

        :returns: The viewpoint dictionary that was set.

        """
        if not isinstance(target_geometry, dict):
            raise TypeError("Target geometry must be of type dictionary.")
        if not isinstance(scale, (int, Scales)):
            raise TypeError("Scale must be of type int or Scales enum class value.")
        if rotation is not None and not isinstance(rotation, (int, float)):
            raise TypeError("Rotation must be of type int or float.")

        if isinstance(scale, Scales):
            scale = scale.value

        if self._existing:
            for idx, action in enumerate(self._story._properties["actions"]):
                if action["origin"] == self._node:
                    if rotation is None:
                        rotation = action["data"]["viewpoint"].get("rotation", 0)

                    new_viewpoint = {
                        "rotation": rotation,
                        "scale": scale,
                        "targetGeometry": target_geometry,
                    }

                    self._story._properties["actions"][idx]["data"][
                        "viewpoint"
                    ] = new_viewpoint

                    self._viewpoint = new_viewpoint
        else:
            self._viewpoint = {
                "rotation": rotation if rotation else 0,
                "scale": scale,
                "targetGeometry": target_geometry,
            }

        return self._viewpoint

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """Delete the map action from the story."""
        for idx, action in enumerate(self._story._properties["actions"]):
            if action["origin"] == self._node:
                del self._story._properties["actions"][idx]
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(
        self,
        slide: SidecarSlide,
    ):
        """
        Add a map action button to a slide. You can specify the data of the action.

        """
        self._story = slide._story
        self._existing = True

        # compose the action dict
        if self._viewpoint or self._extent:
            action_dict = {
                "origin": self._node,
                "trigger": "ActionButton_Apply",
                "target": slide._children[1],
                "event": (
                    "ExpressMap_UpdateData"
                    if not isinstance(self.media, Map)
                    else "WebMap_UpdateData"
                ),
                "data": {},
            }
            if self._extent and not self._viewpoint:
                action_dict["data"]["extent"] = self._extent
                x_center = (self._extent["xmin"] + self._extent["xmax"]) / 2
                y_center = (self._extent["ymin"] + self._extent["ymax"]) / 2
                viewpoint = {
                    "rotation": 0,
                    "targetGeometry": {
                        "spatialReference": (
                            self._extent["spatialReference"]
                            if "spatialReference" in self._extent
                            else {"latestWkid": 3857, "wkid": 102100}
                        ),
                        "x": x_center,
                        "y": y_center,
                    },
                }
                self._viewpoint = viewpoint
            if self._map_layers:
                action_dict["data"]["mapLayers"] = self._map_layers
            if self._viewpoint:
                action_dict["data"]["viewpoint"] = self._viewpoint

        else:
            # check if media node part of story
            if self._media._node not in self._story._properties["nodes"]:
                self._media._add_to_story(story=self._story)
                self._media = self._media._node

            # compose the action dict
            action_dict = {
                "origin": self._node,
                "trigger": "ActionButton_Apply",
                "target": slide._node,
                "event": "ImmersiveSlide_ReplaceMedia",
                "data": {"media": self._media._node},
            }

        # Add action to story properties
        self._story._properties.setdefault("actions", []).append(action_dict)

        # compose the node dict in story properties
        slide._story._properties["nodes"][self._node] = {
            "type": "action-button",
            "data": {"text": self._text},
            "config": {"size": "wide"},
        }

        if self._media:
            slide._story._properties["nodes"][self._node]["dependents"] = {
                "actionMedia": self._media._node
            }

        # add to the narrative panel
        slide._story._properties["nodes"][slide._children[0]]["children"].append(
            self._node
        )

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the node exists."""
        return self._story is not None and self._node is not None


###############################################################################################################
@deprecated(
    deprecated_in="2.4.0",
    details="Use MediaAction class instead. This will have the same methods and properties but the class name has changed.",
)
class MapAction:
    """
    Within the sidecar block, there are stationary media panels and scrolling narrative panels works hand in hand
    to deliver an immersive experience. If the media panel consists of a web map or web scene, the map actions
    functionality allows authors to include options for further interactivity.
    Simply put, map actions are buttons that change something on the map or scene when toggled.
    These buttons can be configured to modify the map extent, the visibility of different layers etc., and this can be
    useful to include additional details without deviating from the primary narrative.

    There are two main types: Inline text map actions and map action blocks in sidecar.

    To create a map action you must use the `create_action` method found in the sidecar.

    ===============     ====================================================================
    **Parameter**        **Description**
    ---------------     --------------------------------------------------------------------
    node_id             Required String. The node id for the map tour type.
    ---------------     --------------------------------------------------------------------
    story               Required :class:`~arcgis.apps.storymap.story.StoryMap` that the map tour belongs to.
    ===============     ====================================================================

    """

    def __init__(self, **kwargs) -> None:
        node = kwargs.pop("node_id", None)
        story = kwargs.pop("story", None)
        if node:
            self._node = node
            self._story = story
            actions = story._properties["actions"]
            for action in actions:
                if action["origin"] == node:
                    self.target = action["target"]
                    self.properties = action
        else:
            self._node = utils.create_unique_id()
            self._story = story

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "MapAction()"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return "MapAction()"

    # ----------------------------------------------------------------------
    @property
    def viewpoint(self) -> dict:
        for action in self._story._properties["actions"]:
            if action["origin"] == self._node:
                return action["data"]["viewpoint"]

    # ----------------------------------------------------------------------
    @property
    def text(self) -> str:
        """
        Get/Set the button text for a map action button.
        """
        node_dict = self._story._properties["nodes"][self._node]
        if "text" in node_dict["data"]:
            return node_dict["data"]["text"]
        return ""

    # ----------------------------------------------------------------------
    @text.setter
    def text(self, text: str) -> None:
        """"""
        if isinstance(text, str):
            self._story._properties["nodes"][self._node]["data"]["text"] = text
        else:
            raise TypeError("Text must be of type string.")

    # ----------------------------------------------------------------------
    def set_viewpoint(
        self, target_geometry: dict, scale: Scales, rotation: int | None = None
    ):
        """
        Set the extent and/or scale for the map action in the story.

        To see the current viewpoint call the `viewpoint` property on the Map Action
        node.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        target_geometry     Required dictionary representing the target geometry of the
                            viewpoint.

                            Example:
                                | {'spatialReference': {'latestWkid': 3857, 'wkid': 102100},
                                | 'x': -609354.6306080809,
                                | 'y': 2885721.2797636474}
        ------------------  ----------------------------------------
        scale               Required Scales enum class value or int.

                            Scale is a unit-less way of describing how any distance on the map translates
                            to a real-world distance. For example, a map at a 1:24,000 scale communicates that 1 unit
                            on the screen represents 24,000 of the same unit in the real world.
                            So one inch on the screen represents 24,000 inches in the real world.
        ------------------  ----------------------------------------
        rotation            Optional float. Determine the rotation for an
                            action on a 3D map.
        ==================  ========================================

        :return: The current viewpoint dictionary
        """
        for idx, action in enumerate(self._story._properties["actions"]):
            if action["origin"] == self._node:
                if rotation is None:
                    if "viewpoint" in self._story._properties["actions"][idx]["data"]:
                        rotation = (
                            self._story._properties["actions"][idx]["data"][
                                "viewpoint"
                            ]["rotation"]
                            if "rotation"
                            in self._story._properties["actions"][idx]["data"][
                                "viewpoint"
                            ]
                            else 0
                        )
                if isinstance(scale, Scales):
                    scale = scale.value
                self._story._properties["actions"][idx]["data"]["viewpoint"] = {
                    "rotation": rotation,
                    "scale": scale,
                    "targetGeometry": target_geometry,
                }
        return self.viewpoint

    # ----------------------------------------------------------------------
    def delete(self):
        """
        Delete the map action.
        """
        for idx, action in enumerate(self._story._properties["actions"]):
            if action["origin"] == self._node:
                del self._story._properties["actions"][idx]
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _check_node(self):
        # Node is not in the story if no story or node id is present
        return self._story is not None and self._node is not None


###############################################################################################################
class ExpressMap:
    """
    Class representing an ExpressMap.

    .. note::
        You can only create an ExpressMap from a pre-existing `expressmap` in a story or briefing. You cannot create
        an ExpressMap from scratch.
    """

    def __init__(self, **kwargs):
        # Content must already exist in the story
        # ExpressMap is not an immersive node
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", None)
        self._existing = self._check_node()

        if self._existing:
            self._map_resource = self._story._properties["nodes"][self._node]["data"][
                "map"
            ]
            # check if offline dependent
            if "dependents" in self._story._properties["nodes"][self._node]:
                if (
                    "offline"
                    in self._story._properties["nodes"][self._node]["dependents"]
                ):
                    self._offline_dependent = self._story._properties["nodes"][
                        self._node
                    ]["dependents"]["offline"]
                else:
                    self._offline_dependent = None
                if (
                    "media"
                    in self._story._properties["nodes"][self._node]["dependents"]
                ):
                    self._media_dependents = self._story._properties["nodes"][
                        self._node
                    ]["dependents"]["media"]
                else:
                    self._media_dependents = []
        else:
            raise ValueError(
                "You cannot create an ExpressMap from scratch at this time. Please use an existing ExpressMap."
            )

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "ExpressMap()"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return "ExpressMap()"

    # ----------------------------------------------------------------------
    @deprecated(
        deprecated_in="2.4.0",
    )
    @property
    def node(self):
        """
        Get the node id of the ExpressMap.

        :return: The node id of the ExpressMap.
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    def offline_media(self):
        """
        Get/Set the offline media property for the embed.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        offline_media       Image or Video. The new offline_media for the Embed.
        ==================  ========================================

        :return:
            The offline media that is being used.
        """
        if self._existing is True:
            if self._offline_dependent:
                return utils.assign_node_class(
                    story=self._story, node_id=self._offline_dependent
                )
        return None

    # ----------------------------------------------------------------------
    @offline_media.setter
    def offline_media(self, value: Image | Video):
        if self._existing:
            # can only set for briefing
            if isinstance(self._story, sm_module.Briefing):
                if isinstance(value, Image) or isinstance(value, Video):
                    value._add_to_story(story=self._story)
                    self._story._properties["nodes"][self._node]["dependents"] = {
                        "offline": value._node
                    }
                    self._offline_dependent = value._node
                else:
                    raise ValueError("offline_media must be an Image or Video")
            else:
                raise ValueError("offline_media can only be set for a Briefing")
        else:
            raise ValueError(
                "offline_media can only be set for an ExpressMap that has been added to a Briefing."
            )

    # ----------------------------------------------------------------------
    @property
    def media(self):
        """
        Get/Set the media property for the embed.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        media               Image or Video. The new media for the Embed.
        ==================  ========================================

        :return:
            The media that is being used.
        """
        if self._existing is True:
            if self._media_dependents:
                return [
                    utils.assign_node_class(story=self._story, node_id=md)
                    for md in self._media_dependents
                ]
        return None

    # ----------------------------------------------------------------------
    def delete(self):
        """
        Delete the expressmap from the story.
        """
        for idx, action in enumerate(self._story._properties["actions"]):
            if action["origin"] == self._node:
                del self._story._properties["actions"][idx]
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _check_node(self):
        # Node is not in the story if no story or node id is present
        return self._story is not None and self._node is not None


###############################################################################################################
class Infographic:
    """
    Class representing an `infographic block`.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    title                   Optional String. The title of the infographic block.
    ------------------      --------------------------------------------------------------------
    description             Optional String. The description of the infographic block.
    ------------------      --------------------------------------------------------------------
    icon                    Optional String. The icon of the infographic block.
                            Currently supports calcite icon names: https://developers.arcgis.com/calcite-design-system/icons/

                            example: "esri pin"
    ------------------      --------------------------------------------------------------------
    icon_position           Optional String. The position of the icon in the infographic block.
    ------------------      --------------------------------------------------------------------
    link                    Optional String. The link of the infographic block which will be shown when a user hovers over it.
    ==================      ====================================================================
    """

    def __init__(self, **kwargs):
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        self._existing = self._check_node()

        if self._existing:
            self._title = self._story._properties["nodes"][self._node]["data"].get(
                "title", ""
            )
            self._description = self._story._properties["nodes"][self._node][
                "data"
            ].get("description", "")
            self._icon = self._story._properties["nodes"][self._node]["data"].get(
                "icon", ""
            )
            self._icon_position = self._story._properties["nodes"][self._node].get(
                "iconPosition", ""
            )
            self._attribution = self._story._properties["nodes"][self._node][
                "data"
            ].get("attribution", "")
        else:
            self._title = kwargs.pop("title", "")
            self._description = kwargs.pop("description", "")
            self._icon = kwargs.pop("icon", "")
            self._icon_position = kwargs.pop(
                "icon_position", "top" if self._icon else ""
            )
            self._attribution = kwargs.pop("link", "")

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Infographic(title={self._title}, description={self._description}, icon={self._icon}, icon_position={self._icon_position})"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def title(self) -> str:
        """
        Get/Set the title of the infographic block.

        ===================     ========================================
        **Parameter**           **Description**
        ------------------      ----------------------------------------
        title                   String. The new title for the infographic block.
        ===================     ========================================

        :return: String title of the infographic block.
        """
        return self._title

    # ----------------------------------------------------------------------
    @title.setter
    def title(self, title: str):
        if self._existing:
            self._story._properties["nodes"][self._node]["data"]["title"] = title
        self._title = title

    # ----------------------------------------------------------------------
    @property
    def description(self) -> str:
        """
        Get/Set the description of the infographic block.

        ===================     ========================================
        **Parameter**           **Description**
        ------------------      ----------------------------------------
        description             String. The new description for the infographic block.
        ===================     ========================================

        :return: String description of the infographic block.
        """
        return self._description

    # ----------------------------------------------------------------------
    @description.setter
    def description(self, description: str):
        if self._existing:
            self._story._properties["nodes"][self._node]["data"][
                "description"
            ] = description
        self._description = description

    # ----------------------------------------------------------------------
    @property
    def icon(self) -> str:
        """
        Get/Set the icon of the infographic block.

        ===================     ========================================
        **Parameter**           **Description**
        ------------------      ----------------------------------------
        icon                    String. The new icon for the infographic block.
                                Currently supports calcite icon names: https://developers.arcgis.com/calcite-design-system/icons/

                                example: "esri pin"
        ===================     ========================================

        :return: String icon of the infographic block.
        """
        return self._icon

    # ----------------------------------------------------------------------
    @icon.setter
    def icon(self, icon: str):
        if self._existing:
            self._story._properties["nodes"][self._node]["data"]["icon"] = icon
        self._icon = icon

    # ----------------------------------------------------------------------
    @property
    def icon_position(self) -> str:
        """
        Get/Set the icon position of the infographic block.

        ===================     ========================================
        **Parameter**           **Description**
        ------------------      ----------------------------------------
        icon_position           String. The new icon position for the infographic block.
                                Accepted values are: "top", "start"
        ===================     ========================================

        :return: String icon position of the infographic block.
        """
        return self._icon_position

    # ----------------------------------------------------------------------
    @icon_position.setter
    def icon_position(self, icon_position: str):
        if icon_position not in ["top", "start"]:
            raise ValueError(
                "Icon position must be one of the following values: 'top', 'start'."
            )
        if self._existing:
            self._story._properties["nodes"][self._node]["iconPosition"] = icon_position
        self._icon_position = icon_position

        # if icon is not set, add a random icon
        if not self._icon:
            self.icon = "esri pin"

    # ----------------------------------------------------------------------
    @property
    def alignment(self) -> str:
        """
        Get/Set the alignment of the infographic block. This can only be set when the infographic is created.

        ===================     ========================================
        **Parameter**           **Description**
        ------------------      ----------------------------------------
        alignment               String. The new alignment for the infographic block.
                                Accepted values are: "left", "center", "right"
        ===================     ========================================

        :return: String alignment of the infographic block.
        """
        if self._existing:
            return self._story._properties["nodes"][self._node].get(
                "alignment", "center"
            )

    # ----------------------------------------------------------------------
    @alignment.setter
    def alignment(self, alignment: str):
        if self._existing:
            if alignment in ["left", "center", "right"]:
                self._story._properties["nodes"][self._node]["alignment"] = alignment
            else:
                raise ValueError(
                    "Alignment must be one of the following values: 'left', 'center', 'right'."
                )

    # ----------------------------------------------------------------------
    @property
    def link(self) -> str:
        """
        Get/Set the link seen when hovering over the infographic block.

        ===================     ========================================
        **Parameter**           **Description**
        ------------------      ----------------------------------------
        link                    String. The new link for the infographic block.
        ===================     ========================================

        :return: String link seen when hovering over the infographic block.
        """
        return self._attribution

    # ----------------------------------------------------------------------
    @link.setter
    def link(self, link: str):
        if self._existing:
            self._story._properties["nodes"][self._node]["data"]["attribution"] = link
        self._attribution = link

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        """
        Add the infographic block to the story.
        """
        self._story = story
        self._existing = True

        # compose the node dict in story properties
        story._properties["nodes"][self._node] = {
            "type": "large-number",
            "data": {
                "title": self._title,
                "description": self._description,
                "alignment": "center",
            },
        }
        if self._icon:
            story._properties["nodes"][self._node]["data"]["icon"] = self._icon
            story._properties["nodes"][self._node]["data"][
                "iconPosition"
            ] = self._icon_position
        if self._attribution:
            story._properties["nodes"][self._node]["data"][
                "attribution"
            ] = self._attribution

    # ----------------------------------------------------------------------
    def _check_node(self):
        # Node is not in the story if no story or node id is present
        return self._story is not None and self._node is not None


###############################################################################################################
class Code:
    """
    Class representing `Code` content in a Storymap.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    content                 Required String. The code content to have in the block.
    ------------------      --------------------------------------------------------------------
    language                Required Language or String. The coding language of the content provided.
                            For values see Language Enum Class.
    ==================      ====================================================================
    """

    def __init__(
        self,
        content: str | None = None,
        language: Language | str | None = None,
        **kwargs,
    ):
        # Can be created from scratch or already exist in story
        # Code is not an immersive node
        self._story = kwargs.pop("story", None)
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # If node doesn't already exist, create new instance
        self._existing = self._check_node()
        if self._existing is True:
            # Get the content and language
            self._content = self._story._properties["nodes"][self._node]["data"][
                "content"
            ]
            if "lang" in self._story._properties["nodes"][self._node]["data"]:
                self._language = self._story._properties["nodes"][self._node]["data"][
                    "lang"
                ]
            else:
                self._language = "txt"
        else:
            # Create new instance, notice no resource node is needed for code
            self._content = content

            if isinstance(language, Language):
                self._language = language.value
            elif isinstance(language, str) and language in [e.value for e in Language]:
                self._language = language
            else:
                raise ValueError(
                    "Language provided is not part of the accepted languages. Please make sure to provide one from the list."
                )

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Code(language={self.language})"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @deprecated(
        deprecated_in="2.4.0",
    )
    @property
    def node(self) -> str:
        """
        Get the node id of the Code block.

        :return: The node id of the Code block.
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    def content(self) -> str:
        """
        Get/Set the content property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        content             String. The new content for the code block.
        ==================  ========================================

        :return:
            The content that is being used.
        """
        return self._content

    # ----------------------------------------------------------------------
    @content.setter
    def content(self, content: str):
        if self._existing is True:
            self._update_content(content)
        else:
            self._content = content

    # ----------------------------------------------------------------------
    @property
    def language(self) -> str:
        """
        Get/Set the language property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        language            Language value. The new language for the code block.
        ==================  ========================================

        :return:
            The language that is being used.
        """
        return self._language

    # ----------------------------------------------------------------------
    @language.setter
    def language(self, language: Language | str):
        if self._existing is True:
            # Figure out correct language
            if isinstance(language, Language):
                language = language.value
            elif isinstance(language, str) and language in Language:
                language = language
            else:
                raise ValueError(
                    "The language provided is not a valid value. Please see the Language Enum class for valid values."
                )

            # Change the language
            self._story._properties["nodes"][self._node]["data"]["lang"] = language
            if language in ["html", "json"]:
                self._story._properties["nodes"][self._node]["data"]["isEncoded"] = True
                # reassign content so it gets encoded correctly
                # known limit: this will cause an issue if a user goes from html to json or vise versa
                self.content = self._content
            else:
                self._story._properties["nodes"][self._node]["data"][
                    "isEncoded"
                ] = False
        self._language = language

    # ----------------------------------------------------------------------
    @property
    def line_number(self) -> bool:
        """
        Get/Set whether line number property is set.

        The Code must be added to the story before you can set this property.

        ==================  ========================================
        **Parameter**        **Description**
        ------------------  ----------------------------------------
        enabled             Bool. Set to True if you want line numbers, False otherwise.
        ==================  ========================================

        :return:
            True if line numbers are enabled and False if not.
        """
        if self._existing is True:
            return self._story._properties["nodes"][self._node]["data"]["lineNumbers"]

    # ----------------------------------------------------------------------
    @line_number.setter
    def line_number(self, enabled: bool):
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"][
                "lineNumbers"
            ] = enabled

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the content from the Storymap.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True
        # Create embed node, no resource node needed
        self._story._properties["nodes"][self._node] = {
            "type": "code",
            "data": {
                "lineNumbers": False,
                "content": self._content,
                "lang": self._language,
                "isEncoded": True if self._language in ["html", "json"] else False,
            },
        }

    # ----------------------------------------------------------------------
    def _update_content(self, content):
        if self._language in ["html", "json"]:
            # same encoding for html and json
            content = html.escape(content)
        # set new content
        self._content = content
        # update dictionary properties
        self._story._properties["nodes"][self._node]["data"]["content"] = content

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class BriefingSlide:
    """
    Represents a Slide for a Briefing.

    ===================     ====================================================================
    **Parameter**           **Description**
    -------------------     --------------------------------------------------------------------
    layout                  Required LayoutType or string, the layout type of the slide.
                            Values: 'flexible' | 'titleless-flexible' | 'section-single' | 'section-double' | 'full'
    -------------------     --------------------------------------------------------------------
    num_blocks              Optional int, for flexible layouts. Determines how many content blocks
                            to generate (1-6).
    -------------------     --------------------------------------------------------------------
    sublayout               Optional SubLayoutType or string, the sublayout type of the slide.
                            Only applicable when the layout is "double" or "titleless-double".
                            ** deprecated **
    -------------------     --------------------------------------------------------------------
    title                   Optional string or :class:`~arcgis.apps.storymap.story_content.Text` object, the title of the slide.
                            Text can only be of type heading (h2).
    -------------------     --------------------------------------------------------------------
    subtitle                Optional string or :class:`~arcgis.apps.storymap.story_content.Text` object, the subtitle of the slide.
                            Text can only be of type paragraph.
    -------------------     --------------------------------------------------------------------
    section_position        Optional string, the title panel position of the section slide. Only
                            applicable for "section-double".
                            Values: 'start' | 'end'
    ===================     ====================================================================

    """

    # ------------------------------------------------------------------
    # Class-level mapping for flexible layouts
    # ------------------------------------------------------------------
    _FLEXIBLE_LAYOUT_MAP: dict[int, tuple[int, int, list[dict[str, int]]]] = {
        1: (1, 1, [{"colStart": 0, "colEnd": 1, "rowStart": 0, "rowEnd": 1}]),
        2: (
            2,
            1,
            [
                {"colStart": 0, "colEnd": 1, "rowStart": 0, "rowEnd": 1},
                {"colStart": 1, "colEnd": 2, "rowStart": 0, "rowEnd": 1},
            ],
        ),
        3: (
            3,
            1,
            [
                {"colStart": 0, "colEnd": 1, "rowStart": 0, "rowEnd": 1},
                {"colStart": 1, "colEnd": 2, "rowStart": 0, "rowEnd": 1},
                {"colStart": 2, "colEnd": 3, "rowStart": 0, "rowEnd": 1},
            ],
        ),
        4: (
            2,
            2,
            [
                {"colStart": 0, "colEnd": 1, "rowStart": 0, "rowEnd": 1},
                {"colStart": 1, "colEnd": 2, "rowStart": 0, "rowEnd": 1},
                {"colStart": 0, "colEnd": 1, "rowStart": 1, "rowEnd": 2},
                {"colStart": 1, "colEnd": 2, "rowStart": 1, "rowEnd": 2},
            ],
        ),
        5: (
            3,
            2,
            [
                {"colStart": 0, "colEnd": 1, "rowStart": 0, "rowEnd": 1},
                {"colStart": 0, "colEnd": 1, "rowStart": 1, "rowEnd": 2},
                {"colStart": 1, "colEnd": 2, "rowStart": 0, "rowEnd": 2},
                {"colStart": 2, "colEnd": 3, "rowStart": 0, "rowEnd": 1},
                {"colStart": 2, "colEnd": 3, "rowStart": 1, "rowEnd": 2},
            ],
        ),
        6: (
            3,
            2,
            [
                {"colStart": 0, "colEnd": 1, "rowStart": 0, "rowEnd": 1},
                {"colStart": 1, "colEnd": 2, "rowStart": 0, "rowEnd": 1},
                {"colStart": 2, "colEnd": 3, "rowStart": 0, "rowEnd": 1},
                {"colStart": 0, "colEnd": 1, "rowStart": 1, "rowEnd": 2},
                {"colStart": 1, "colEnd": 2, "rowStart": 1, "rowEnd": 2},
                {"colStart": 2, "colEnd": 3, "rowStart": 1, "rowEnd": 2},
            ],
        ),
    }

    # ------------------------------------------------------------------
    def __init__(self, **kwargs):
        """
        Constructor is intentionally kwargs-based to preserve backward compatibility
        with existing usage (including internal calls from Briefing.add).
        """
        # Core identifiers
        self._story: sm_module.Briefing | None = kwargs.pop("story", None)
        self._type: str = "briefing-slide"
        self._node: str | None = kwargs.pop("node_id", None)

        # Internal state (populated later)
        self._layout: str | None = None
        self._sublayout: str | dict | None = None
        self._title: Text | None = None
        self._subtitle: Text | None = None
        self._display_title: str | None = None
        self._section_position: str | None = None
        self._children: dict | list | None = None

        # Existing vs new slide
        self._existing: bool = self._check_node()

        if self._existing:
            # Existing slide: load everything from the story properties
            self._initialize_existing_slide()
            return

        # New slide path
        layout: SlideLayout | str = kwargs.pop("layout", "flexible")
        num_blocks: int = kwargs.pop("num_blocks", 1)
        title: Text | str | None = kwargs.pop("title", None)
        subtitle: Text | str | None = kwargs.pop("subtitle", None)
        section_position: str | None = kwargs.pop("section_position", None)
        children = kwargs.pop("children", None)
        sublayout = kwargs.pop("sublayout", None)

        # 'sublayout' was never actually honored previously, but was accepted and
        # documented as deprecated. We now explicitly warn and ignore it for new slides.
        if sublayout is not None:
            warnings.warn(
                "`sublayout` is deprecated as of 2.5.0 and will be removed in 3.0.0. "
                "Briefing slides now always use flexible layouts.",
                DeprecationWarning,
                stacklevel=2,
            )

        # Any remaining unexpected kwargs are ignored to preserve previous behavior.

        self._initialize_new_slide(
            layout=layout,
            num_blocks=num_blocks,
            title=title,
            subtitle=subtitle,
            section_position=section_position,
            children=children,
        )

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------
    def _initialize_existing_slide(self) -> None:
        """Initialize this instance based on an existing node in the story."""
        node = self._story._properties["nodes"][self._node]
        node_data = node.get("data", {})

        self._children = node_data.get("contents", {}) or {}
        self._layout = node_data.get("layout", None)
        self._sublayout = node_data.get("sublayout", None)

        # Subtitle
        subtitle_id = node_data.get("subtitle", None)
        if subtitle_id:
            self._subtitle = utils.assign_node_class(
                story=self._story, node_id=subtitle_id
            )
        else:
            self._subtitle = None

        # Title
        title_id = node_data.get("title", None)
        if title_id:
            self._title = utils.assign_node_class(self._story, title_id)
        else:
            self._title = None

        # Display title
        self._display_title = node_data.get("displayTitle", None)

        # Section position (stored in the data as 'sectionPosition' for existing slides)
        self._section_position = node_data.get("sectionPosition", None)

    # ------------------------------------------------------------------
    def _initialize_new_slide(
        self,
        layout: SlideLayout | str,
        num_blocks: int,
        title: Text | str | None,
        subtitle: Text | str | None,
        section_position: str | None,
        children: dict | None,
    ) -> None:
        """Initialize a new slide that is not yet attached to any story."""
        # Ensure we have a node id
        self._node = self._node or utils.create_unique_id()
        self._children = children or {}

        # Layout and structure
        self._apply_layout(layout, num_blocks, section_position)

        # Title: for new slides, strings become Text with SUBHEADING style
        # (matches previous behavior)
        self._title = self._coerce_text_for_new(
            value=title,
            default_style=TextStyles.SUBHEADING,
        )

        if self._title:
            # Set the display title based on the title, user can change this later
            self._display_title = title if isinstance(title, str) else self._title.text
        else:
            self._display_title = None

        # Subtitle for new slides: strings become Text with PARAGRAPH style
        self._subtitle = self._coerce_text_for_new(
            value=subtitle,
            default_style=TextStyles.PARAGRAPH,
        )

    # ------------------------------------------------------------------
    def _apply_layout(
        self,
        layout: SlideLayout | str,
        num_blocks: int,
        section_position: str | None,
    ) -> None:
        """
        Normalize and apply layout, sublayout, and section position settings
        for a new slide.
        """
        # Normalize layout from enum or string
        if isinstance(layout, SlideLayout):
            layout_value = layout.value
        else:
            layout_value = layout

        # Accept only known layouts
        allowed = {
            "single",
            "double",
            "titleless-single",
            "titleless-double",
            "full",
            "section-single",
            "section-double",
            "flexible",
            "titleless-flexible",
            "cover",
        }
        if layout_value not in allowed:
            raise ValueError(f"Invalid layout type: {layout_value}")

        self._layout = layout_value

        # Handle legacy layouts by converting to flexible layouts
        if self._layout in {"single", "double", "titleless-single", "titleless-double"}:
            warnings.warn(
                f"Layout type '{self._layout}' is deprecated as of 2.5.0 and will be "
                f"removed in 3.0.0. Converting to flexible layout.",
                DeprecationWarning,
                stacklevel=2,
            )
            # If num_blocks is not explicitly set, infer based on legacy layout
            if not num_blocks:
                num_blocks = 2 if "double" in self._layout else 1

            self._layout = (
                "flexible" if "titleless" not in self._layout else "titleless-flexible"
            )

        # Determine sublayout for flexible layouts only
        self._sublayout = self._create_sublayout(num_blocks)

        # Section position applies only to "section-double"
        if self._layout == "section-double" and section_position:
            self._section_position = section_position
        else:
            self._section_position = None

    # ------------------------------------------------------------------
    def _coerce_text_for_new(
        self,
        value: Text | str | None,
        default_style: TextStyles,
    ) -> Text | None:
        """
        For new slides (not yet attached to a story), coerce strings into Text
        instances but do not add them to the story yet. This mirrors previous
        behavior where Text nodes were only added in _add_to_story.
        """
        if value is None:
            return None
        if isinstance(value, Text):
            return value
        if isinstance(value, str):
            return Text(value, default_style)
        raise TypeError(
            f"Expected Text or str or None, got {type(value).__name__!r} instead."
        )

    # ------------------------------------------------------------------
    def _ensure_text_in_story(
        self,
        text: Text,
        required_style: TextStyles | None = None,
    ) -> Text:
        """
        Ensure a Text node is attached to the story and (optionally) enforce
        a required style.
        """
        if (
            required_style is not None
            and getattr(text, "_style", None) != required_style
        ):
            raise ValueError(
                f"Text must be of style {required_style!r}. "
                f"Please change the style."
            )

        # If the Text node is not yet part of the story, add it
        if getattr(text, "_existing", False) is False:
            text._add_to_story(story=self._story)

        return text

    # ------------------------------------------------------------------
    def _create_flexible_layout(self, num_blocks: int) -> dict:
        """Create the flexible layout configuration for 1–6 blocks."""
        if not (1 <= num_blocks <= 6):
            raise ValueError(
                f"Invalid number of blocks: {num_blocks}. Must be between 1 and 6."
            )

        cols, rows, items = self._FLEXIBLE_LAYOUT_MAP[num_blocks]
        return {"cols": cols, "rows": rows, "items": items}

    # ------------------------------------------------------------------
    def _create_sublayout(self, num_blocks: int) -> dict | None:
        """
        Create the sublayout dictionary depending on the number of blocks the user wants
        to have in the slide. This can be between 1 to 6 blocks.
        """
        if self._layout in ["flexible", "titleless-flexible"]:
            return self._create_flexible_layout(num_blocks)
        # Other layouts do not have a sublayout
        return None

    # ------------------------------------------------------------------
    def _set_block_children(self) -> None:
        """
        Ensure the 'contents' structure in the node data is in a usable form
        for editing. Certain layouts require special normalization.
        """
        if not self._story or not self._node:
            return

        # set the default of contents as an empty dict if not present
        self._story._properties["nodes"][self._node]["data"].setdefault("contents", {})

        # Each block is a key in the content dicts, add the correct number of keys
        num_blocks = len(
            self._story._properties["nodes"][self._node]["data"]["sublayout"]["items"]
        )
        for num in range(num_blocks):
            # each block is empty to begin with
            self._story._properties["nodes"][self._node]["data"]["contents"][
                str(num)
            ] = []
        self._children = self._story._properties["nodes"][self._node]["data"][
            "contents"
        ]

    # ------------------------------------------------------------------
    def _delete_keys(self, start_value: int, contents: dict) -> None:
        """delete the keys starting at the value and upwards (currently only 1)"""
        for key in range(start_value, 2):
            try:
                del contents[str(key)]
            except KeyError:
                pass

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"BriefingSlide(layout={self._layout})"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def cover(self):
        """
        Get the cover of the briefing. The cover is the first slide in the briefing.
        """
        # property only accessed through the cover slide
        if self._layout != "cover":
            warnings.warn(
                "This is not a cover slide. The cover class can only be accessed through the cover slide."
            )
            return None
        # The storycover in a Briefing is the child of the first slide
        cover = self._story._properties["nodes"][self._node]["children"][0]
        # create a class from the node id
        return utils.assign_node_class(self._story, cover)

    # ----------------------------------------------------------------------
    @property
    def blocks(self) -> list[Block]:
        """
        Get blocks of the Slide. Blocks hold content of various types such as
        Text, Image, Map, Swipe, etc. If you want to edit the content you can access
        the `add_content`, `delete_content` method of the block.

        :return:
            A list of blocks in the slide
        """
        # TODO: make it so this is not needed
        if not self._existing:
            raise Exception(
                "Slide must be added to a briefing before accessing blocks and adding content."
            )
        # If the slide is a cover slide, then the children are the contents
        if self._story._properties["nodes"][self._node]["data"]["layout"] == "cover":
            # self._children is a list of node ids in this case
            return [
                utils.assign_node_class(self._story, node_id)
                for node_id in (self._children or [])
            ]

        # Slide is not a cover slide and has contents, even if empty
        contents = []
        for key, _ in (self._children or {}).items():
            # the key will be "0", "1" depending on the layout
            contents.append(Block(block_index=key, slide=self, story=self._story))
        return contents

    # ----------------------------------------------------------------------
    @property
    def title(self) -> str | None:
        """
        Get/Set the title of the slide.

        .. note::
            To get or change the title of the cover slide, use the `cover` method in the Briefing class.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        title               Text instance or string depicting the title of the slide.
        ===============     ====================================================================
        """
        return self._title.text if self._title else None

    # ----------------------------------------------------------------------
    @title.setter
    def title(self, title: Text | str):
        if self._layout in [
            "titleless-single",
            "titleless-double",
            "full",
            "titleless-flexible",
        ]:
            raise Exception("This slide does not have a title.")

        # For existing slides, we must ensure the underlying Text node is present in the story
        if self._existing is True:
            # If string then need to create text node and add to story
            if isinstance(title, str):
                title = Text(title, TextStyles.HEADING)
            if isinstance(title, Text):
                title = self._ensure_text_in_story(
                    text=title,
                    required_style=TextStyles.HEADING,
                )
                # Set the title node id in data of slide
                self._story._properties["nodes"][self._node]["data"][
                    "title"
                ] = title._node
        elif isinstance(title, str):
            # New slide, not yet in story: just coerce to Text and defer adding
            title = Text(title, TextStyles.HEADING)

        self._title = title

    # ----------------------------------------------------------------------
    @property
    def subtitle(self) -> str | None:
        """Get/Set the subtitle when the layout is either 'section-single' or 'section-double'."""
        return self._subtitle.text if self._subtitle else None

    # ----------------------------------------------------------------------
    @subtitle.setter
    def subtitle(self, subtitle: Text | str):
        if self._layout not in ["section-single", "section-double"]:
            raise Exception("This slide does not have a subtitle.")

        # If string then need to create text node and add to story
        if isinstance(subtitle, str):
            subtitle = Text(subtitle, TextStyles.PARAGRAPH)

        if isinstance(subtitle, Text):
            subtitle = self._ensure_text_in_story(text=subtitle)

            # Set the subtitle node id in data of slide
            self._story._properties["nodes"][self._node]["data"][
                "subtitle"
            ] = subtitle._node

        # If there was an existing subtitle, delete it
        if self._subtitle:
            self._subtitle.delete()

        # assign new subtitle
        self._subtitle = subtitle

    # ----------------------------------------------------------------------
    @property
    def display_title(self) -> str | None:
        """
        Get/Set the display title of the slide. This is the title that will be shown in the
        briefing when the slide is displayed.

        :return:
            A string of the display title if it exists, otherwise None.
        """
        return self._display_title

    # ----------------------------------------------------------------------
    @display_title.setter
    def display_title(self, title: str):
        """
        Set the display title of the slide. This is the title that will be shown in the
        briefing when the slide is displayed.

        :param title: A string of the display title.
        """
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"]["displayTitle"] = title
        self._display_title = title

    # ----------------------------------------------------------------------
    @property
    def layout(self) -> str:
        """
        Get the layout of the slide.

        .. note::
            Once a slide is created, the layout cannot be changed.

        :return:
            A string of the layout type.
        """
        return self._layout

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.0",
    )
    def sublayout(self) -> str:
        """
        Get/Set the sublayout when the layout is "double". This determines
        the proportion of the slide that the content takes up.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        sublayout           SlideSubLayout value or String depicting the sublayout type of the slide.
                            Only applicable when the layout is "double" or "titleless-double".
        ===============     ====================================================================
        """
        return self._sublayout

    # ----------------------------------------------------------------------
    @sublayout.setter
    def sublayout(self, sublayout: str | SlideSubLayout):
        warnings.warn(
            "`sublayout` is deprecated as of 2.5.0 and will be removed in 3.0.0. "
            "Changing the sublayout is not supported for flexible layouts.",
            DeprecationWarning,
            stacklevel=2,
        )

        if self.layout in ["flexible", "titleless-flexible"]:
            raise Exception("Changing the sublayout is not supported at this time.")

        if sublayout not in SlideSubLayout.__members__.values() and not isinstance(
            sublayout, str
        ):
            raise ValueError(
                "Invalid sublayout value. Please provide a string or SlideSubLayout value."
            )

        if sublayout in SlideSubLayout.__members__.values():
            sublayout = sublayout.value

        # assign to the property
        self._sublayout = sublayout

        # update the story
        if self._existing is True:
            layout = self._story._properties["nodes"][self._node]["data"]["layout"]
            if layout in ["double", "titleless-double"]:
                self._story._properties["nodes"][self._node]["data"][
                    "sublayout"
                ] = sublayout

    # ----------------------------------------------------------------------
    @property
    def section_position(self) -> str:
        """
        Get/Set the title panel position for a section-double layout slide.

        Values: 'start' or 'end'
        """
        return self._section_position

    # ----------------------------------------------------------------------
    @section_position.setter
    def section_position(self, position: str):
        if self._layout != "section-double":
            raise Exception("This slide does not have a section position.")
        if position not in ["start", "end"]:
            raise ValueError("Invalid position value. Please provide 'start' or 'end'.")

        self._section_position = position
        if self._existing is True:
            self._story._properties["nodes"][self._node]["data"][
                "titlePanelPosition"
            ] = position

    # ----------------------------------------------------------------------
    @property
    def hidden(self) -> bool:
        """
        Get/Set the visibility of the slide.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        hide                Bool. Set to True if you want the slide to be hidden, False otherwise.
        ===============     ====================================================================
        """
        if self._existing is False:
            return False
        node = self._story._properties["nodes"][self._node]
        if "config" in node:
            return node["config"].get("isHidden", False)

    # ----------------------------------------------------------------------
    @hidden.setter
    def hidden(self, hide: bool):
        if not self._existing:
            raise warnings.warn(
                "Slide must be added to the briefing before setting hidden property."
            )
        node = self._story._properties["nodes"][self._node]
        config = node.setdefault("config", {})
        config["isHidden"] = hide

    # ----------------------------------------------------------------------
    def duplicate(self) -> "BriefingSlide":
        """
        Duplicate the slide and gets added to the briefing.
        The slide must already be in the story to duplicate.

        :return:
            A new BriefingSlide object that is a duplicate of the current slide.
        """
        slide = BriefingSlide(
            layout=self._layout,
            sublayout=self._sublayout,  # still accepted, but ignored for new flexible slides
            title=self._title,
            subtitle=self._subtitle,
            section_position=self._section_position,
            children=self._children,
        )
        slide._add_to_story(story=self._story)
        return slide

    # ----------------------------------------------------------------------
    def delete(self) -> bool:
        """
        Delete the slide from it's Briefing.

        :return: True if successful.
        """
        if self._existing is True:
            return utils.delete(self._story, self._node)
        else:
            return False

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        """
        Attach this slide to a story. This method is used internally by the Briefing
        and by the Briefing.add method.
        """
        self._story = story
        self._existing = True

        # Create slide node
        node_data = {
            "type": self._type,
            "data": {"layout": self._layout, "contents": self._children or {}},
        }
        self._story._properties["nodes"].setdefault(self._node, node_data)

        data = self._story._properties["nodes"][self._node]["data"]

        # Set sublayout if it exists
        if self._sublayout:
            data["sublayout"] = self._sublayout

        # add section position
        if self._section_position:
            data["titlePanelPosition"] = self._section_position

        # Add display title if it exists
        if self._display_title:
            data["displayTitle"] = self._display_title

        # Add title if it exists
        if self._title:
            # For new slides, Text nodes may not yet exist in the story
            self._ensure_text_in_story(
                text=self._title,
                required_style=None,  # style validation handled elsewhere
            )
            data["title"] = self._title._node

        # Add subtitle if it exists
        if self._subtitle:
            self._ensure_text_in_story(text=self._subtitle)
            data["subtitle"] = self._subtitle._node

        # set hidden to False
        self.hidden = False
        # For editing purposes, have children even if empty
        self._set_block_children()

    # ----------------------------------------------------------------------
    def _check_node(self) -> bool:
        """Check if the slide exists in the briefing."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Block:
    """
    Represents a block in a briefing slide. The block is what holds the content of a slide such as an Image, Text, or more.
    One or more Text contents can be added to a block, but only one of the other content types such as Image, Map, Video, etc.

    .. note::
        Blocks are automatically created when you create a new slide. You can access the blocks
        through the `blocks` property of the slide. Do not create this class directly.
    """

    def __init__(self, **kwargs) -> None:
        self._index: int = kwargs.get("block_index")
        self._slide: BriefingSlide = kwargs.get("slide")
        self._story = kwargs.get("story")
        # list of strings or single node as string
        self._content: list[str] | str = self._story._properties["nodes"][
            self._slide._node
        ]["data"]["contents"][str(self._index)]

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return (
            f"Block(content={self.content}, index={self._index})"
            if self.content
            else "Block(empty)"
        )

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def content(self) -> list:
        """
        Get the contents of the block. This will return a list of the content
        objects in the block. The content objects can be of type Text, Image, Map, etc.

        :return:
            A list of content objects in the block.
        """
        if isinstance(self._content, list) and len(self._content) > 0:
            # This is a list of content items
            return [
                utils.assign_node_class(self._story, node_id)
                for node_id in self._content
            ]
        elif isinstance(self._content, list) and len(self._content) == 0:
            # There are no contents in the block
            return []
        else:
            # There is only one content in the block
            return [utils.assign_node_class(self._story, self._content)]

    # ----------------------------------------------------------------------
    def add_content(
        self,
        content: (
            Text
            | Image
            | Video
            | Embed
            | Map
            | Swipe
            | Gallery
            | Code
            | Table
            | Infographic
        ),
    ) -> bool:
        """
        Add content to the block.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        content             Required content object to be added to the block. The content
                            object can be of type Text, Image, Video, Embed, Map, Swipe, Gallery,
                            Code, Table, or Infographic.
                            There can be more than one Text contents in the same block but only one of the
                            other types of content.
                            Setting an Image, Video, Embed, Map, or Swipe content will overwrite the
                            current content. Setting a Text content will add the text to the block.
        ===============     ====================================================================

        :return:
            The Content object that was added to the block.
        """
        # check that the content is not None
        if content is None:
            raise Exception(
                "The content cannot be None. To remove content use the delete_content method."
            )
        # check that the content is of the correct type
        if not isinstance(
            content,
            (Text, Image, Video, Embed, Map, Swipe, Gallery, Code, Table, Infographic),
        ):
            raise Exception(
                "The content must be of type Text, Image, Video, Embed, Map, Swipe, Gallery, Code, Table, or Infographic."
            )

        content._add_to_story(story=self._story)
        # If content is text and the current content is a list, append to the list
        if isinstance(content, Text) and isinstance(self._content, list):
            self._content.append(content._node)
        # If content is text and the current content is not a list, create a list and append
        elif isinstance(content, Text) and not isinstance(self._content, list):
            # check the type of the current content
            current = self.content[0]
            if isinstance(current, Text):
                # There can be multiple text contents in a block
                self._content = [self._content, content._node]
            else:
                # There can only be one of the other types of contents
                self._content = content._node
        # If another type, then assign to content's node id, this overwrites what is currently there
        else:
            self._content = content._node

        # Add to the slide in the story
        self._story._properties["nodes"][self._slide._node]["data"]["contents"][
            str(self._index)
        ] = self._content
        return content

    # ----------------------------------------------------------------------
    def delete_content(self, index: int | None = None) -> bool:
        """
        Delete content from the block.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        index               Optional integer, the index of the content to be deleted. If not
                            specified, all content will be deleted.
        ===============     ====================================================================

        :return: True if successful.
        """
        if index is None:
            # delete all content
            self._content = []
        elif isinstance(index, int):
            # delete content at index
            if isinstance(self._content, list) and len(self._content) > 0:
                if 0 <= index < len(self._content):
                    del self._content[index]
                else:
                    raise Exception("Index is out of range.")
            else:
                raise Exception("There is no content at the specified index.")
        else:
            raise Exception("The index must be an integer.")

        # Update the story with the modified content
        self._story._properties["nodes"][self._slide._node]["data"]["contents"][
            str(self._index)
        ] = self._content

        return True


###############################################################################################################
class Table:
    """
    Class representing a `table block`.
    Table will show as a gridded table in your Storymap.

    ==================      ====================================================================
    **Parameter**            **Description**
    ------------------      --------------------------------------------------------------------
    rows                    Optional int. The number of rows in the table. Table supports a maximum
                            of 10 rows. Minimum of 2 rows supported.
    ------------------      --------------------------------------------------------------------
    columns                 Optional int. The number of columns in the table. Table supports a
                            maximum of 8 columns. Minimum of 1 column supported.
    ------------------      --------------------------------------------------------------------
    df                      Optional pandas DataFrame. The content of the table as a pandas
                            DataFrame. The index of the DataFrame will be the row headers and
                            the columns of the DataFrame will be the column headers.
                            The cell values are held within a dictionary where the 'value' key
                            is the text of the cell. The other key that can be included in
                            the dictionary is the 'textAlignment' key. Columns and rows must
                            be sequential strings starting from 0.

                            Example:
                            .. code-block:: python

                                import pandas as pd
                                from arcgis.apps.storymap import Text, Table

                                df = pd.DataFrame.from_dict(
                                    {
                                        "0": {
                                            "0": {"value": "row1"},
                                            "1": {"value": "row2"},
                                        },
                                        "1": {
                                            "0": {"value": "row1"},
                                            "1": {"value": "row2"},
                                        },
                                    },
                                    orient="index",
                                )

                                table = Table(df=df)
                                print(table.content)
    ==================      ====================================================================
    """

    def __init__(
        self,
        rows: int | None = None,
        columns: int | None = None,
        df: pd.DataFrame | None = None,
        **kwargs,
    ):
        # Can be created from scratch or already exist in story
        # Code is not an immersive node
        self._story = kwargs.pop("story", None)
        self._type = "table"
        self._node = kwargs.pop("node_id", utils.create_unique_id())
        # If node doesn't already exist, create new instance
        self._existing = self._check_node()
        if self._existing is True:
            self._numRows = self._story._properties["nodes"][self._node]["data"][
                "numRows"
            ]
            self._numColumns = self._story._properties["nodes"][self._node]["data"][
                "numColumns"
            ]
            self._cells = (
                self._story._properties["nodes"][self._node]["data"]["cells"]
                if "cells" in self._story._properties["nodes"][self._node]["data"]
                else {}
            )
        else:
            # Create new instance, notice no resource node is needed for code
            self._numRows = rows if rows and (rows > 2 and rows <= 10) else 2
            self._numColumns = (
                columns if columns and (columns > 1 and columns <= 8) else 1
            )
            self._cells = {}

            if df is not None:
                self._cells: dict = df.to_dict(orient="index")
                self._cells = self.validate_and_fix_dictionary_structure(self._cells)
                self.content = df

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id of the table. This is the unique identifier for the table in the story.
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    def content(self):
        """
        Get the content of the table as a panda's DataFrame.
        Each cell content is held within a dictionary where the
        'value' key is the text of the cell. The other key that can be included in
        the dictionary is the 'textAlignment' key.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        content             Required pandas DataFrame. The content of the table as a pandas
                            DataFrame. The index of the DataFrame will be the row headers and
                            the columns of the DataFrame will be the column headers.
        ===============     ====================================================================

        """
        df = pd.DataFrame.from_dict(
            self._cells,
            orient="index",
            columns=[f"{i}" for i in range(self._numColumns)],
        )
        if self._existing is True:
            # Iterate through the DataFrame
            for column in df.columns:
                for index, cell_value in enumerate(df[column]):
                    # Check if the cell value is a dictionary and has the key "value"
                    if isinstance(cell_value, dict) and "value" in cell_value:
                        # Update the value key to be an instance of the text class
                        df.at[str(index), column]["value"] = Text(
                            cell_value["value"]
                        )._text
        return df

    # ----------------------------------------------------------------------
    @content.setter
    def content(self, content: pd.DataFrame):
        if isinstance(content, pd.DataFrame):
            # check that the number of rows and columns didn't change, if so update
            if (
                content.shape[0] != self._numRows
                or content.shape[1] != self._numColumns
            ):
                # add check that rows are not more than 10 and columns are not more than 8.
                if content.shape[0] > 10 or content.shape[0] < 2:
                    raise ValueError("A table can only have between 2-10 rows.")
                if content.shape[1] > 8 or content.shape[1] < 1:
                    raise ValueError("A table can only have between 1-8 columns.")

                # Update the number of rows and columns
                self._numRows = content.shape[0]
                self._numColumns = content.shape[1]

                if self._existing:
                    # update rows and columns in story properties
                    self._story._properties["nodes"][self._node]["data"][
                        "numRows"
                    ] = self._numRows
                    self._story._properties["nodes"][self._node]["data"][
                        "numColumns"
                    ] = self._numColumns
            # First go through each cell and if the value is a text instance, keep only the text
            for column in content.columns:
                for index, cell_value in enumerate(content[column]):
                    if not isinstance(cell_value, dict):
                        raise ValueError(
                            "The content of each cell must be a dictionary. The text is held in the key 'value'."
                        )
                    if isinstance(cell_value["value"], Text):
                        content.at[str(index), column]["value"] = cell_value[
                            "value"
                        ]._text
            # convert the dataframe to a dictionary
            self._cells = content.to_dict(orient="index")
            self._cells = self.validate_and_fix_dictionary_structure(self._cells)
            if self._existing:
                # update the cells in the story properties
                self._story._properties["nodes"][self._node]["data"][
                    "cells"
                ] = self._cells

    def validate_and_fix_dictionary_structure(self, data):
        if not isinstance(data, dict):
            raise ValueError("Input is not a dictionary")

        fixed_data = {}
        expected_column_keys = set(map(str, range(len(data))))
        for col_key, col_value in data.items():
            if not isinstance(col_value, dict):
                raise ValueError("Each column should be a dictionary")
            if col_key not in expected_column_keys:
                raise ValueError(
                    "Column keys should be sequential integers starting from 0"
                )

            fixed_col_value = {}
            expected_row_keys = set(map(str, range(len(col_value))))
            for row_key, row_value in col_value.items():
                if not isinstance(row_value, dict):
                    raise ValueError("Each row should be a dictionary")
                if row_key not in expected_row_keys:
                    raise ValueError(
                        "Row keys should be sequential integers starting from 0"
                    )

                if (
                    len(row_value) != 1
                    or "value" not in row_value
                    or not isinstance(row_value["value"], str)
                ):
                    row_value = {
                        "value": str(row_value)
                    }  # Fix the row value if it's not in the correct format

                fixed_col_value[row_key] = row_value

            fixed_data[col_key] = fixed_col_value

        return fixed_data

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return f"Table(size={self._numRows}x{self._numColumns})"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    def delete(self):
        """
        Delete the Table from the Storymap.

        :return: True if successful.
        """
        return utils.delete(self._story, self._node)

    # ----------------------------------------------------------------------
    def _add_to_story(self, story=None, **kwargs):
        self._story = story
        self._existing = True
        # Create embed node, no resource node needed
        self._story._properties["nodes"][self._node] = {
            "type": "table",
            "data": {
                "numRows": self._numRows,
                "numColumns": self._numColumns,
            },
            "config": {"size": "full"},
        }

        # Add cells if they exist
        if self._cells:
            self._story._properties["nodes"][self._node]["data"]["cells"] = self._cells

    # ----------------------------------------------------------------------
    def _check_node(self):
        """Check if the content exists in the story or briefing. Some methods and manipulations are dependent on this."""
        return self._story is not None and self._node is not None


###############################################################################################################
class Cover:
    """
    Represents the cover slide of a Briefing or the cover of a Storymap.
    """

    def __init__(self, **kwargs):
        self._story = kwargs.pop("story")
        self._node = kwargs.pop("node_id")
        self._existing = self._check_node()
        if self._existing:
            self._title = self._story._properties["nodes"][self._node]["data"].get(
                "title", None
            )
            self._summary = self._story._properties["nodes"][self._node]["data"].get(
                "summary", None
            )
            self._byline = self._story._properties["nodes"][self._node]["data"].get(
                "byline", None
            )

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "Cover()"

    # ----------------------------------------------------------------------
    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    @deprecated(
        deprecated_in="2.4.2",
    )
    def node(self) -> str:
        """
        Get the node id of the cover. This is the unique identifier for the cover in the story.
        """
        return self._node

    # ----------------------------------------------------------------------
    @property
    def title(self) -> str | None:
        """
        Get/Set the title of the cover slide.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        title               Text instance or string depicting the title of the cover slide.
        ===============     ====================================================================
        """
        return self._title if self._title else None

    # ----------------------------------------------------------------------
    @title.setter
    def title(self, title: Text | str):
        if self._existing is True:
            # If string then need to create text node and add to story
            if isinstance(title, Text):
                title = title.text
            # Set the title node id in data of slide
            self._story._properties["nodes"][self._node]["data"]["title"] = title
        self._title = title

    # ----------------------------------------------------------------------
    @property
    def summary(self) -> str | None:
        """
        Get/Set the summary of the cover slide.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        summary             Text instance or string depicting the summary of the cover slide.
        ===============     ====================================================================
        """
        return self._summary if self._summary else None

    # ----------------------------------------------------------------------
    @summary.setter
    def summary(self, summary: Text | str):
        if self._existing is True:
            # If string then need to create text node and add to story
            if isinstance(summary, Text):
                summary = summary.text
            # Set the title node id in data of slide
            self._story._properties["nodes"][self._node]["data"]["summary"] = summary
        self._summary = summary

    # ----------------------------------------------------------------------
    @property
    def byline(self) -> str | None:
        """
        Get/Set the byline of the cover slide.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        byline              Text instance or string depicting the byline of the cover slide.
        ===============     ====================================================================
        """
        return self._byline if self._byline else None

    # ----------------------------------------------------------------------
    @byline.setter
    def byline(self, byline: Text | str):
        if self._existing is True:
            # If string then need to create text node and add to story
            if isinstance(byline, Text):
                byline = byline.text
            # Set the title node id in data of slide
            self._story._properties["nodes"][self._node]["data"]["byline"] = byline
        self._byline = byline

    # ----------------------------------------------------------------------
    @property
    def type(self) -> str:
        """
        Get the type of the cover.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        type                Optional string or :class:`~arcgis.apps.storymap.story_content.CoverType`
                            enumeration. The type of story cover to be used in the story.

                            * Values for :class:`~arcgis.apps.storymap.story.StoryMap`
                              and :class:`~arcgis.apps.storymap.briefing.Briefing`:
                             * *full*
                             * *sidebyside*
                             * *minimal*
                             * *card*
                             * *split*
                             * *top*

                            * Values for :class:`~arcgis.apps.storymap.collection.Collection`:

                             * *grid*
                             * *magazine*
                             * *journal*

                            .. note::
                                As of Enterprise 11.4 only "full", "sidebyside", and "minimal" are
                                supported for Storymap and Briefing.
        ===============     ====================================================================

        :return:
            A string of the cover type.
        """
        if self._existing:
            return self._story._properties["nodes"][self._node]["data"]["type"]
        return None

    # ----------------------------------------------------------------------
    @type.setter
    def type(self, cover_type: str | CoverType):
        # get value
        if isinstance(cover_type, CoverType):
            cover_type = cover_type.value

        # check value
        if (
            isinstance(self._story, sm_module.Briefing)
            or isinstance(self._story, sm_module.StoryMap)
            and cover_type
            not in [
                "full",
                "sidebyside",
                "minimal",
                "card",
                "split",
                "top",
            ]
        ):
            raise ValueError(
                "Invalid cover type. Please provide 'full', 'sidebyside', 'minimal', 'card', 'split', or 'top'."
            )
        elif isinstance(self._story, sm_module.Collection) and cover_type not in [
            "grid",
            "magazine",
            "journal",
        ]:
            raise ValueError(
                "Invalid cover type. Please provide 'grid', 'magazine', or 'journal'."
            )
        if self._existing:
            self._story._properties["nodes"][self._node]["data"]["type"] = cover_type

    # ----------------------------------------------------------------------
    @property
    def media(self) -> str | None:
        """
        Get/Set the media of the cover slide.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        media               The media of the cover slide. This can be an instance of
                            Image or Video.
        ===============     ====================================================================
        """
        if self._existing:
            if "children" in self._story._properties["nodes"][self._node]:
                media_node = self._story._properties["nodes"][self._node]["children"][0]
                return utils.assign_node_class(self._story, media_node)
        return None

    # ----------------------------------------------------------------------
    @media.setter
    def media(self, media: Image | Video | None):
        if (
            not isinstance(media, Image)
            and not isinstance(media, Video)
            or media is None
        ):
            raise ValueError(
                "Media must be an Image or video object or None to remove the media."
            )
        if media is None:
            # remove media
            self._story._properties["nodes"][self._node]["children"] = []
            return
        if media._node not in self._story._properties["nodes"]:
            # must be added to story resources
            media._add_to_story(story=self._story)
        self._story._properties["nodes"][self._node]["children"] = [media._node]

    # ----------------------------------------------------------------------
    @property
    def date(self) -> str:
        """
        Get/Set the date of the cover slide.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        date                Optional string. How the date should be shown on the cover.

                            ``Values: "first-published" | "last-published" | "current-date" | "none"``
        ===============     ====================================================================
        """
        # date info found in root node
        if (
            "config"
            in self._story._properties["nodes"][self._story._properties["root"]]
        ):
            return self._story._properties["nodes"][self._story._properties["root"]][
                "config"
            ]["coverDate"]
        else:
            return "first-published"

    # ----------------------------------------------------------------------
    @date.setter
    def date(self, date: str):
        if date not in ["first-published", "last-published", "current-date", "none"]:
            raise ValueError(
                "Invalid date value. Please provide 'first-published', 'last-published', 'current-date', or 'none'."
            )
        self._story._properties["nodes"][self._story._properties["root"]]["config"][
            "coverDate"
        ] = date

    # ----------------------------------------------------------------------
    @property
    def vertical_position(self) -> str:
        """
        Get/Set the vertical position of the cover panel.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        vertical_position   Optional string or instance of VerticalPosition Enum. The vertical position of the cover slide.
                            This is available when the cover type is 'full'.

                            ``Values: "top" | "middle" | "bottom"``
        ===============     ====================================================================
        """
        return (
            self._story._properties["nodes"][self._node]["data"][
                "titlePanelVerticalPosition"
            ]
            if "titlePanelVerticalPosition"
            in self._story._properties["nodes"][self._node]["data"]
            else None
        )

    # ----------------------------------------------------------------------
    @vertical_position.setter
    def vertical_position(self, position: str):
        if self.type != "full":
            raise Exception(
                "This property is only available when the cover type is 'full'."
            )
        position = (
            position.value if isinstance(position, VerticalPosition) else position
        )
        if position not in ["top", "middle", "bottom"]:
            raise ValueError(
                "Invalid vertical position value. Please provide 'top', 'middle', or 'bottom'."
            )
        self._story._properties["nodes"][self._node]["data"][
            "titlePanelVerticalPosition"
        ] = position

    # ----------------------------------------------------------------------
    @property
    def horizontal_position(self) -> str:
        """
        Get/Set the horizontal position of the cover panel.

        ===================     ====================================================================
        **Parameter**           **Description**
        -------------------     --------------------------------------------------------------------
        horizontal_position     Optional string or instance of HorizontalPosition Enum. The horizontal position of the cover slide.
                                This is available when the cover type is "minimal", "top", or "full".

                                ``Values: "start" | "center" | "end"``
        ===================     ====================================================================
        """
        return (
            self._story._properties["nodes"][self._node]["data"][
                "titlePanelHorizontalPosition"
            ]
            if "titlePanelHorizontalPosition"
            in self._story._properties["nodes"][self._node]["data"]
            else None
        )

    # ----------------------------------------------------------------------
    @horizontal_position.setter
    def horizontal_position(self, position: str):
        if self.type not in ["minimal", "top", "full"]:
            raise Exception(
                "This property is only available when the cover type is 'minimal', 'top', or 'full'."
            )
        position = (
            position.value if isinstance(position, HorizontalPosition) else position
        )
        if position not in ["start", "center", "end"]:
            raise ValueError(
                "Invalid horizontal position value. Please provide 'start', 'center', or 'end'."
            )
        self._story._properties["nodes"][self._node]["data"][
            "titlePanelHorizontalPosition"
        ] = position

    # ----------------------------------------------------------------------
    @property
    def style(self) -> str:
        """
        Get/Set the style of the cover panel.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        style               Optional string or instance of CoverStyle Enum. The style of the cover slide.
                            This is available when the type is 'full'.

                            ``Values: "gradient" | "themed" | "transparent-with-light-color" | "transparent-with-dark-color"``
        ===============     ====================================================================
        """
        return (
            self._story._properties["nodes"][self._node]["data"]["titlePanelStyle"]
            if "titlePanelStyle" in self._story._properties["nodes"][self._node]["data"]
            else None
        )

    # ----------------------------------------------------------------------
    @style.setter
    def style(self, style: str):
        if self.type != "full":
            raise Exception(
                "This property is only available when the cover type is 'full'."
            )
        style = style.value if isinstance(style, CoverStyle) else style
        if style not in [
            "gradient",
            "themed",
            "transparent-with-light-color",
            "transparent-with-dark-color",
        ]:
            raise ValueError(
                "Invalid style value. Please provide 'gradient', 'themed', 'transparent-with-light-color' or 'transparent-with-dark-color'."
            )
        self._story._properties["nodes"][self._node]["data"]["titlePanelStyle"] = style

    # ----------------------------------------------------------------------
    @property
    def size(self) -> str:
        """
        Get/Set the size of the cover panel.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        size                Optional string. The size of the cover slide.
                            This is available when the type is 'full', "card", or "sidebyside".

                            ``Values: "small" | "medium" | "large"``
        ===============     ====================================================================
        """
        return (
            self._story._properties["nodes"][self._node]["data"]["titlePanelSize"]
            if "titlePanelSize" in self._story._properties["nodes"][self._node]["data"]
            else None
        )

    # ----------------------------------------------------------------------
    @size.setter
    def size(self, size: str):
        if self.type not in ["full", "card", "sidebyside"]:
            raise Exception(
                "This property is only available when the cover type is 'full', 'card', or 'sidebyside'."
            )
        size = size.value if isinstance(size, CoverSize) else size
        if size not in ["small", "medium", "large"]:
            raise ValueError(
                "Invalid size value. Please provide 'small', 'medium', or 'large'."
            )
        self._story._properties["nodes"][self._node]["data"]["titlePanelSize"] = size

    # ----------------------------------------------------------------------
    def _check_node(self):
        if self._story is None or self._node is None:
            return False
        return True


###############################################################################################################
class Navigation:
    """
    A class to represent the Storymap's Navigation.
    """

    def __init__(self, **kwargs) -> None:
        self._story = kwargs.pop("story")
        self._node = kwargs.pop("node_id")

        self._hidden = self._story._properties["nodes"][self._node]["config"][
            "isHidden"
        ]
        self._links = self._story._properties["nodes"][self._node]["data"]["links"]

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "Navigation()"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def links(self):
        """
        Get/Set the links in the navigation.

        To add, remove, or reorder the navigation link list, use the setter.
        Pass in the list of story content you want in the navigation. The content
        can only be Text with style of "h2", "h3", or "h4".
        """
        links = []
        for link in self._links:
            links.append(utils.assign_node_class(self._story, link))
        return links

    # ----------------------------------------------------------------------
    @links.setter
    def links(self, link_list: list):
        if not isinstance(link_list, list):
            raise ValueError(
                "Links must be a list of Storymap Text classes that are in your story."
            )

        # update the links
        self._links = [
            link._node
            for link in link_list
            if isinstance(link, Text) and link._style in ["h2", "h3", "h4"]
        ]
        self._story._properties["nodes"][self._node]["data"]["links"] = self._links

    # ----------------------------------------------------------------------
    @property
    def hidden(self):
        """
        Get/Set the hidden property of the navigation.
        """
        return self._hidden

    # ----------------------------------------------------------------------
    @hidden.setter
    def hidden(self, hidden: bool):
        if not isinstance(hidden, bool):
            raise ValueError("Hidden must be a boolean.")

        # update the hidden property
        self._hidden = hidden
        self._story._properties["nodes"][self._node]["config"][
            "isHidden"
        ] = self._hidden


###############################################################################################################
class CollectionNavigation:
    """
    A class to represent the Storymap's Collection Navigation.
    """

    def __init__(self, **kwargs) -> None:
        self._story = kwargs.pop("story")
        self._node = kwargs.pop("node_id")

    # ----------------------------------------------------------------------
    def __str__(self) -> str:
        return "CollectionNavigation()"

    def __repr__(self) -> str:
        return self.__str__()

    # ----------------------------------------------------------------------
    @property
    def type(self):
        """
        Get/Set the type of the navigations.

        ===============     ====================================================================
        **Parameter**        **Description**
        ---------------     --------------------------------------------------------------------
        type                Optional string. The type of collection navigation to be used in the story.

                            ``Values: "compact" | "tab" | "bullet"``
        ===============     ====================================================================

        :return:
            A string of the navigation type.
        """
        return self._story._properties["nodes"][self._node]["data"]["type"]

    @type.setter
    def type(self, nav_type: str):
        if nav_type not in ["compact", "tab", "bullet"]:
            raise ValueError(
                "Invalid navigation type. Please provide 'compact', 'tab', or 'bullet'."
            )
        self._story._properties["nodes"][self._node]["data"]["type"] = nav_type
